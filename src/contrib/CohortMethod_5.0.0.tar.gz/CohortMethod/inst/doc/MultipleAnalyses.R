## ---- echo = FALSE, message = FALSE, warning = FALSE--------------------------
library(CohortMethod)
outputFolder <- "d:/temp/cohortMethodVignette2_arrow"
folderExists <- dir.exists(outputFolder)

## ----eval=FALSE---------------------------------------------------------------
#  connectionDetails <- createConnectionDetails(dbms = "postgresql",
#                                               server = "localhost/ohdsi",
#                                               user = "joe",
#                                               password = "supersecret")
#  
#  cdmDatabaseSchema <- "my_cdm_data"
#  resultsDatabaseSchema <- "my_results"
#  options(sqlRenderTempEmulationSchema = NULL)
#  outputFolder <- "./CohortMethodOutput"

## ----eval=FALSE---------------------------------------------------------------
#  library(SqlRender)
#  sql <- readSql("VignetteOutcomes.sql")
#  sql <- render(sql,
#                cdmDatabaseSchema = cdmDatabaseSchema,
#                resultsDatabaseSchema = resultsDatabaseSchema)
#  sql <- translate(sql, targetDialect = connectionDetails$dbms)
#  
#  connection <- connect(connectionDetails)
#  executeSql(connection, sql)

## ----eval=FALSE---------------------------------------------------------------
#  outcomeOfInterest <- createOutcome(outcomeId = 192671,
#                                     outcomeOfInterest = TRUE)
#  
#  negativeControlIds <- c(192671, 29735, 140673, 197494,
#                          198185, 198199, 200528, 257315,
#                          314658, 317376, 321319, 380731,
#                          432661, 432867, 433516, 433701,
#                          433753, 435140, 435459, 435524,
#                          435783, 436665, 436676, 442619,
#                          444252, 444429, 4131756, 4134120,
#                          4134454, 4152280, 4165112, 4174262,
#                          4182210, 4270490, 4286201, 4289933)
#  
#  negativeControlOutcomes <- lapply(
#    negativeControlIds,
#    function(outcomeId) createOutcome(outcomeId = outcomeId,
#                                      outcomeOfInterest = FALSE,
#                                      trueEffectSize = 1)
#  )
#  
#  
#  
#  tcos <- createTargetComparatorOutcomes(
#    targetId = 1118084,
#    comparatorId = 1124300,
#    outcomes = append(list(outcomeOfInterest),
#                      negativeControlOutcomes)
#  )
#  
#  targetComparatorOutcomesList <- list(tcos)

## ----eval=TRUE----------------------------------------------------------------
nsaids <- 21603933

covarSettings <- createDefaultCovariateSettings(
  excludedCovariateConceptIds = nsaids,
  addDescendantsToExclude = TRUE
)

getDbCmDataArgs <- createGetDbCohortMethodDataArgs(
  washoutPeriod = 183,
  restrictToCommonPeriod = FALSE,
  firstExposureOnly = TRUE,
  removeDuplicateSubjects = "remove all",
  studyStartDate = "",
  studyEndDate = "",
  covariateSettings = covarSettings
)

createStudyPopArgs <- createCreateStudyPopulationArgs(
  removeSubjectsWithPriorOutcome = TRUE,
  minDaysAtRisk = 1,
  riskWindowStart = 0,
  startAnchor = "cohort start",
  riskWindowEnd = 30,
  endAnchor = "cohort end"
)

fitOutcomeModelArgs1 <- createFitOutcomeModelArgs(modelType = "cox")

## ----eval=TRUE----------------------------------------------------------------
cmAnalysis1 <- createCmAnalysis(
  analysisId = 1,
  description = "No matching, simple outcome model",
  getDbCohortMethodDataArgs = getDbCmDataArgs,
  createStudyPopArgs = createStudyPopArgs,
  fitOutcomeModelArgs = fitOutcomeModelArgs1
)

## ----eval=TRUE----------------------------------------------------------------
createPsArgs <- createCreatePsArgs() # Use default settings only

matchOnPsArgs <- createMatchOnPsArgs(maxRatio = 100)

computeSharedCovBalArgs <- createComputeCovariateBalanceArgs()

computeCovBalArgs <- createComputeCovariateBalanceArgs(
  covariateFilter = getDefaultCmTable1Specifications()
)

fitOutcomeModelArgs2 <- createFitOutcomeModelArgs(
  modelType = "cox",
  stratified = TRUE
)

cmAnalysis2 <- createCmAnalysis(
  analysisId = 2,
  description = "Matching",
  getDbCohortMethodDataArgs = getDbCmDataArgs,
  createStudyPopArgs = createStudyPopArgs,
  createPsArgs = createPsArgs,
  matchOnPsArgs = matchOnPsArgs,
  computeSharedCovariateBalanceArgs = computeSharedCovBalArgs,
  computeCovariateBalanceArgs = computeCovBalArgs,
  fitOutcomeModelArgs = fitOutcomeModelArgs2
)

stratifyByPsArgs <- createStratifyByPsArgs(numberOfStrata = 5)

cmAnalysis3 <- createCmAnalysis(
  analysisId = 3,
  description = "Stratification",
  getDbCohortMethodDataArgs = getDbCmDataArgs,
  createStudyPopArgs = createStudyPopArgs,
  createPsArgs = createPsArgs,
  stratifyByPsArgs = stratifyByPsArgs,
  computeSharedCovariateBalanceArgs = computeSharedCovBalArgs,
  computeCovariateBalanceArgs = computeCovBalArgs,
  fitOutcomeModelArgs = fitOutcomeModelArgs2
)

fitOutcomeModelArgs3 <- createFitOutcomeModelArgs(
  modelType = "cox",
  inversePtWeighting = TRUE
)

cmAnalysis4 <- createCmAnalysis(
  analysisId = 4,
  description = "Inverse probability weighting",
  getDbCohortMethodDataArgs = getDbCmDataArgs,
  createStudyPopArgs = createStudyPopArgs,
  createPsArgs = createPsArgs,
  fitOutcomeModelArgs = fitOutcomeModelArgs3
)

fitOutcomeModelArgs4 <- createFitOutcomeModelArgs(
  useCovariates = TRUE,
  modelType = "cox",
  stratified = TRUE
)

cmAnalysis5 <- createCmAnalysis(
  analysisId = 5,
  description = "Matching plus full outcome model",
  getDbCohortMethodDataArgs = getDbCmDataArgs,
  createStudyPopArgs = createStudyPopArgs,
  createPsArgs = createPsArgs,
  matchOnPsArgs = matchOnPsArgs,
  fitOutcomeModelArgs = fitOutcomeModelArgs4
)

interactionCovariateIds <- c(8532001, 201826210, 21600960413) # Female, T2DM, concurent use of antithrombotic agents

fitOutcomeModelArgs5 <- createFitOutcomeModelArgs(
  modelType = "cox",
  stratified = TRUE,
  interactionCovariateIds = interactionCovariateIds
)

cmAnalysis6 <- createCmAnalysis(
  analysisId = 6,
  description = "Stratification plus interaction terms",
  getDbCohortMethodDataArgs = getDbCmDataArgs,
  createStudyPopArgs = createStudyPopArgs,
  createPsArgs = createPsArgs,
  stratifyByPsArgs = stratifyByPsArgs,
  fitOutcomeModelArgs = fitOutcomeModelArgs5
)

## ----eval=TRUE----------------------------------------------------------------
cmAnalysisList <- list(cmAnalysis1, 
                       cmAnalysis2, 
                       cmAnalysis3, 
                       cmAnalysis4, 
                       cmAnalysis5, 
                       cmAnalysis6)

## ----eval=FALSE---------------------------------------------------------------
#  multiThreadingSettings <- createDefaultMultiThreadingSettings(parallel::detectCores())
#  
#  result <- runCmAnalyses(
#    connectionDetails = connectionDetails,
#    cdmDatabaseSchema = cdmDatabaseSchema,
#    exposureDatabaseSchema = cdmDatabaseSchema,
#    exposureTable = "drug_era",
#    outcomeDatabaseSchema = resultsDatabaseSchema,
#    outcomeTable = "outcomes",
#    outputFolder = folder,
#    cdmVersion = cdmVersion,
#    cmAnalysisList = cmAnalysisList,
#    targetComparatorOutcomesList = targetComparatorOutcomesList,
#    multiThreadingSettings = multiThreadingSettings
#  )

## ----eval=FALSE---------------------------------------------------------------
#  psFile <- result$psFile[result$targetId == 1118084 &
#                          result$comparatorId == 1124300 &
#                          result$outcomeId == 192671 &
#                          result$analysisId == 5]
#  ps <- readRDS(file.path(outputFolder, psFile))
#  plotPs(ps)

## ----echo=FALSE,message=FALSE-------------------------------------------------
if (folderExists) {
  result <- readRDS(file.path(outputFolder, "outcomeModelReference.rds"))
  psFile <- result$psFile[result$targetId == 1118084 & 
                            result$comparatorId == 1124300 & 
                            result$outcomeId == 192671 &
                            result$analysisId == 5]
  ps <- readRDS(file.path(outputFolder, psFile))
  plotPs(ps)
}

## ----eval=FALSE---------------------------------------------------------------
#  result <- getFileReference(folder)

## ----eval=FALSE---------------------------------------------------------------
#  resultsSum <- getResultsSummary(outputFolder)
#  head(resultsSum)

## ----echo=FALSE,message=FALSE-------------------------------------------------
if (folderExists) {
  resultsSum <- readRDS(file.path(outputFolder, "resultsSummary.rds"))
  head(resultsSum)
}

## ----eval=FALSE---------------------------------------------------------------
#  install.packages("EmpiricalCalibration")
#  library(EmpiricalCalibration)
#  
#  # Analysis 1: No matching, simple outcome model
#  negCons <- resultsSum[resultsSum$analysisId == 1 & resultsSum$outcomeId != 192671, ]
#  hoi <-  resultsSum[resultsSum$analysisId == 1 & resultsSum$outcomeId == 192671, ]
#  null <- fitNull(negCons$logRr, negCons$seLogRr)
#  plotCalibrationEffect(negCons$logRr, negCons$seLogRr, hoi$logRr, hoi$seLogRr, null)

## ----echo=FALSE,message=FALSE,warning=FALSE,eval=TRUE-------------------------
if (folderExists) {
  library(EmpiricalCalibration)
  negCons <- resultsSum[resultsSum$analysisId == 1 & resultsSum$outcomeId != 192671, ]
  hoi <-  resultsSum[resultsSum$analysisId == 1 & resultsSum$outcomeId == 192671, ]
  null <- fitNull(negCons$logRr, negCons$seLogRr)
  plotCalibrationEffect(negCons$logRr, negCons$seLogRr, hoi$logRr, hoi$seLogRr, null)
}

## ----eval=FALSE---------------------------------------------------------------
#  # Analysis 2: Matching
#  negCons <- resultsSum[resultsSum$analysisId == 2 & resultsSum$outcomeId != 192671, ]
#  hoi <-  resultsSum[resultsSum$analysisId == 2 & resultsSum$outcomeId == 192671, ]
#  null <- fitNull(negCons$logRr, negCons$seLogRr)
#  plotCalibrationEffect(negCons$logRr, negCons$seLogRr, hoi$logRr, hoi$seLogRr, null)

## ----echo=FALSE,message=FALSE,warning=FALSE,eval=TRUE-------------------------
if (folderExists) {
  negCons <- resultsSum[resultsSum$analysisId == 2 & resultsSum$outcomeId != 192671, ]
  hoi <-  resultsSum[resultsSum$analysisId == 2 & resultsSum$outcomeId == 192671, ]
  null <- fitNull(negCons$logRr, negCons$seLogRr)
  plotCalibrationEffect(negCons$logRr, negCons$seLogRr, hoi$logRr, hoi$seLogRr, null)
}

## ----eval=FALSE---------------------------------------------------------------
#  # Analysis 3: Stratification
#  negCons <- resultsSum[resultsSum$analysisId == 3 & resultsSum$outcomeId != 192671, ]
#  hoi <-  resultsSum[resultsSum$analysisId == 3 & resultsSum$outcomeId == 192671, ]
#  null <- fitNull(negCons$logRr, negCons$seLogRr)
#  plotCalibrationEffect(negCons$logRr, negCons$seLogRr, hoi$logRr, hoi$seLogRr, null)

## ----echo=FALSE,message=FALSE,warning=FALSE,eval=TRUE-------------------------
if (folderExists) {
  negCons <- resultsSum[resultsSum$analysisId == 3 & resultsSum$outcomeId != 192671, ]
  hoi <-  resultsSum[resultsSum$analysisId == 3 & resultsSum$outcomeId == 192671, ]
  null <- fitNull(negCons$logRr, negCons$seLogRr)
  plotCalibrationEffect(negCons$logRr, negCons$seLogRr, hoi$logRr, hoi$seLogRr, null)
}

## ----eval=FALSE---------------------------------------------------------------
#  # Analysis 4: Inverse probability of treatment weighting
#  negCons <- resultsSum[resultsSum$analysisId == 4 & resultsSum$outcomeId != 192671, ]
#  hoi <-  resultsSum[resultsSum$analysisId == 4 & resultsSum$outcomeId == 192671, ]
#  null <- fitNull(negCons$logRr, negCons$seLogRr)
#  plotCalibrationEffect(negCons$logRr, negCons$seLogRr, hoi$logRr, hoi$seLogRr, null)

## ----echo=FALSE,message=FALSE,warning=FALSE,eval=TRUE-------------------------
if (folderExists) {
  negCons <- resultsSum[resultsSum$analysisId == 4 & resultsSum$outcomeId != 192671, ]
  hoi <-  resultsSum[resultsSum$analysisId == 4 & resultsSum$outcomeId == 192671, ]
  null <- fitNull(negCons$logRr, negCons$seLogRr)
  plotCalibrationEffect(negCons$logRr, negCons$seLogRr, hoi$logRr, hoi$seLogRr, null)
}

## ----eval=FALSE---------------------------------------------------------------
#  # Analysis 5: Stratification plus full outcome model
#  negCons <- resultsSum[resultsSum$analysisId == 5 & resultsSum$outcomeId != 192671, ]
#  hoi <-  resultsSum[resultsSum$analysisId == 5 & resultsSum$outcomeId == 192671, ]
#  null <- fitNull(negCons$logRr, negCons$seLogRr)
#  plotCalibrationEffect(negCons$logRr, negCons$seLogRr, hoi$logRr, hoi$seLogRr, null)

## ----echo=FALSE,message=FALSE,warning=FALSE,eval=TRUE-------------------------
if (folderExists) {
  negCons <- resultsSum[resultsSum$analysisId == 5 & resultsSum$outcomeId != 192671, ]
  hoi <-  resultsSum[resultsSum$analysisId == 5 & resultsSum$outcomeId == 192671, ]
  null <- fitNull(negCons$logRr, negCons$seLogRr)
  plotCalibrationEffect(negCons$logRr, negCons$seLogRr, hoi$logRr, hoi$seLogRr, null)
}

## ----eval=FALSE---------------------------------------------------------------
#  interactionResultsSum <- getInteractionResultsSummary(outputFolder)
#  
#  
#  # Analysis 6: Stratification plus interaction terms
#  negCons <- interactionResultsSum[interactionResultsSum$analysisId == 6 & interactionResultsSum$outcomeId != 192671, ]
#  hoi <-  interactionResultsSum[interactionResultsSum$analysisId == 6 & interactionResultsSum$outcomeId == 192671, ]
#  null <- fitNull(negCons$logRr, negCons$seLogRr)
#  plotCalibrationEffect(logRrNegatives = negCons$logRr,
#                        seLogRrNegatives = negCons$seLogRr,
#                        logRrPositives = hoi$logRr,
#                        seLogRrPositives = hoi$seLogRr, null)

## ----echo=FALSE,message=FALSE,eval=TRUE---------------------------------------
if (folderExists) {
  interactionResultsSum <- getInteractionResultsSummary(outputFolder)
  negCons <- interactionResultsSum[interactionResultsSum$analysisId == 6 & interactionResultsSum$outcomeId != 192671, ]
  hoi <-  interactionResultsSum[interactionResultsSum$analysisId == 6 & interactionResultsSum$outcomeId == 192671, ]
  null <- fitNull(negCons$logRr, negCons$seLogRr)
  plotCalibrationEffect(logRrNegatives = negCons$logRr, 
                        seLogRrNegatives = negCons$seLogRr, 
                        logRrPositives = hoi$logRr, 
                        seLogRrPositives = hoi$seLogRr, null)
}

## ----eval=FALSE---------------------------------------------------------------
#  exportToCsv(
#    outputFolder,
#    exportFolder = file.path(folder, "export"),
#    databaseId = "My CDM",
#    minCellCount = 5,
#    maxCores = parallel::detectCores()
#  )

## -----------------------------------------------------------------------------
getResultsDataModel()

## ----eval=FALSE---------------------------------------------------------------
#  cohorts <- data.frame(
#    cohortId = c(
#      1118084,
#      1124300,
#      192671),
#    cohortName = c(
#      "Celecoxib",
#      "Diclofenac",
#      "GI Bleed"
#    )
#  )
#  
#  insertExportedResultsInSqlite(
#    sqliteFileName = file.path(folder, "myResults.sqlite"),
#    exportFolder = file.path(folder, "export"),
#    cohorts = cohorts
#  )
#  

## ----eval=FALSE---------------------------------------------------------------
#  launchResultsViewerUsingSqlite(
#    sqliteFileName = file.path(folder, "myResults.sqlite")
#  )

## ----echo=FALSE, fig.cap="CohortMethod Shiny app", out.width = '80%'----------
knitr::include_graphics("shinyApp.png")

## ----eval=TRUE----------------------------------------------------------------
citation("CohortMethod")

## ----eval=TRUE----------------------------------------------------------------
citation("Cyclops")

