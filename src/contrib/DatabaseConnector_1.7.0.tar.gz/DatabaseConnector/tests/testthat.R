library(testthat)
library(DatabaseConnector)

test_check("DatabaseConnector")
