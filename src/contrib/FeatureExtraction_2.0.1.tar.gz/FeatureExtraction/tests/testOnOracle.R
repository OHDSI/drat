library(testthat)
library(FeatureExtraction)
options(dbms = "oracle")
test_check("FeatureExtraction")
