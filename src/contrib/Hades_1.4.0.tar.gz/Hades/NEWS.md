HADES 1.4.0
===========

Changes

- Adding PhenotypeLibrary to HADES

HADES 1.3.0
===========

Changes

- Adding EnsemblePatientLevelPrediction to HADES

HADES 1.2.0
===========

Changes

- Adding Capr to HADES

HADES 1.1.0
===========

Changes

- Adding CohortGenerator to HADES

HADES 1.0.1
===========

Changes

- Moving Eunomia from CRAN to GitHub


Hades 1.0.0
===========

Initial release