OhdsiShinyModules v1.0.1
========================
- Preparing for HADES

OhdsiShinyModules v1.0.0
========================
- Version ready for release


OhdsiShinyModules v0.2.4
========================
- Test coverage > 80%
- Updated website
- Modules included for HADES pacakges: PatientLevelPrediction, DescriptiveStudies, CohortGenerator and CohortMethod
