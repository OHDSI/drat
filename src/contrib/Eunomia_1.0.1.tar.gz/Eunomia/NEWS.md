Eunomia 1.0.1
=============

Changes

- Using xz compression to further reduce package size.


Eunomia 1.0.0
=============

Initial release
