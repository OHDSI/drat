PheValuator 2.2.8
=================

Changes:
1. Add capability to supply custom visit occurrence table to increase speed of processing for extremely large visit occurrence tables
2. Bug fix in sql files needed in sql server

PheValuator 2.2.7
=================

Changes:
1. Add capability to use exisitng model for a run
2. Bug fix for getPopnPrev.sql needed in sql server

PheValuator 2.2.6
=================

Changes:
1. add in additional parameters for output csv models
2. add default value for xSens cohort as prevalence cohort

PheValuator 2.2.3
=================

Changes:

1. Added capability to supply designated model cohort instead of using xSpec
2. Added parameters to ensure correct offset from start and end of observation period
3. Created output csv files to be used in shiny applications as well as for easier access to results

PheValuator 2.2.2
=================

Changes:

1. Eliminate evaluation population as an input parameter
2. Add capability to input special inclusion rules for evaluation cohort
3. Add capability to input special exclusion rules for evaluation cohort
4. Add parameter to set the number of false positive and negative examples saved for analysis



PheValuator 2.2.0
=================

Changes:

1. Add capability to create simpler xSpec cohorts not based on visit dates
2. Add capability to have PheValuator generate the evaluation cohort automatically
3. Use a faster method to develop predicted probabilities for evaluation cohort
4. Include a set of subjects designated as true and false positives and negatives in output

PheValuator 2.1.13
=================

Changes:

1. Put unit in testing in place for inclusion in HADES.

PheValuator 2.0.0
=================

Changes:

1. Major overhaul of the code base and functions, aimed at improving stability, consistency with other OHSDI packages, and usability.
