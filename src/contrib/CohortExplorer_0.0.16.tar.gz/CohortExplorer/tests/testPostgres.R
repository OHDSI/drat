library(testthat)
options(dbms = "postgresql")
test_check("CohortExplorer")
