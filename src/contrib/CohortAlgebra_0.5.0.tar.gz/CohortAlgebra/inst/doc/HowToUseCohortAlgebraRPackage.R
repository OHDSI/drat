## ---- echo = FALSE, message = FALSE-------------------------------------------
knitr::opts_chunk$set(
  cache = FALSE,
  comment = "#>",
  error = FALSE,
  tidy = FALSE
)

## ----tidy=FALSE,eval=FALSE----------------------------------------------------
#  remotes::install_github("OHDSI/CohortAlgebra")

## ----tidy=FALSE,eval=TRUE, echo=FALSE-----------------------------------------
library(dplyr)

jdbcDriverFolder <- tempfile("jdbcDrivers")
dir.create(jdbcDriverFolder, showWarnings = FALSE)
DatabaseConnector::downloadJdbcDrivers("postgresql", pathToDriver = jdbcDriverFolder)

connectionDetails <- DatabaseConnector::createConnectionDetails(
  dbms = "postgresql",
  user = Sys.getenv("CDM5_POSTGRESQL_USER"),
  password = Sys.getenv("CDM5_POSTGRESQL_PASSWORD"),
  server = Sys.getenv("CDM5_POSTGRESQL_SERVER"),
  pathToDriver = jdbcDriverFolder
)
cohortDatabaseSchema <- Sys.getenv("CDM5_POSTGRESQL_OHDSI_SCHEMA")

# generate unique name for a cohort table
sysTime <- as.numeric(Sys.time()) * 100000
tableName <- paste0("cr", sysTime)
tempTableName <- paste0("#", tableName, "_1")

## ----tidy=FALSE,eval=TRUE, echo=FALSE-----------------------------------------
cohort <- dplyr::tibble(
  cohortDefinitionId = c(1, 2, 2),
  subjectId = c(1, 1, 1),
  cohortStartDate = c(
    as.Date("2022-01-01"),
    as.Date("2022-02-10"),
    as.Date("2022-08-15")
  ),
  cohortEndDate = c(
    as.Date("2022-03-01"),
    as.Date("2022-05-10"),
    as.Date("2022-12-30")
  )
)

## ----tidy=FALSE,eval=TRUE, echo=TRUE------------------------------------------
cohort

## ----tidy=FALSE,eval=TRUE, echo=FALSE-----------------------------------------
# upload table
connection <-
  DatabaseConnector::connect(connectionDetails = connectionDetails)
DatabaseConnector::insertTable(
  connection = connection,
  databaseSchema = cohortDatabaseSchema,
  tableName = tableName,
  data = cohort,
  dropTableIfExists = TRUE,
  createTable = TRUE,
  tempTable = FALSE,
  camelCaseToSnakeCase = TRUE,
  progressBar = FALSE
)

## ----tidy=FALSE,eval=TRUE, echo=FALSE-----------------------------------------
cohortExpected <- dplyr::tibble(
  cohortDefinitionId = c(3, 3),
  subjectId = c(1, 1),
  cohortStartDate = c(as.Date("2022-01-01"), as.Date("2022-08-15")),
  cohortEndDate = c(as.Date("2022-05-10"), as.Date("2022-12-30"))
)

## ----tidy=FALSE, eval=TRUE, echo=TRUE-----------------------------------------

cohortExpected

## ----tidy=FALSE,eval=TRUE-----------------------------------------------------
oldToNewCohortId <-
  dplyr::tibble(
    oldCohortId = c(1, 2, 2),
    newCohortId = c(3, 3, 3)
  )

CohortAlgebra::unionCohorts(
  connection = connection,
  sourceCohortDatabaseSchema = cohortDatabaseSchema,
  sourceCohortTable = tableName,
  targetCohortDatabaseSchema = cohortDatabaseSchema,
  targetCohortTable = tableName,
  oldToNewCohortId = oldToNewCohortId
)

## ----tidy=FALSE,eval=TRUE, echo=FALSE-----------------------------------------
data <-
  DatabaseConnector::renderTranslateQuerySql(
    connection = connection,
    sql = paste0(
      "SELECT * FROM @cohort_database_schema.@table_name
        where cohort_definition_id = 3
        order by cohort_definition_id, subject_id, cohort_start_date;"
    ),
    cohort_database_schema = cohortDatabaseSchema,
    table_name = tableName,
    snakeCaseToCamelCase = TRUE
  ) %>%
  dplyr::tibble()

## ----tidy=FALSE,eval=TRUE, echo=TRUE------------------------------------------

data

## ----tidy=FALSE,eval=TRUE, echo=FALSE-----------------------------------------
cohort <- dplyr::tibble(
  cohortDefinitionId = c(1, 2),
  subjectId = c(1, 1),
  cohortStartDate = c(
    as.Date("2022-01-01"),
    as.Date("2021-12-15")
  ),
  cohortEndDate = c(
    as.Date("2022-01-15"),
    as.Date("2022-01-30")
  )
)

## ----tidy=FALSE,eval=TRUE, echo=TRUE------------------------------------------
cohort

## ----tidy=FALSE,eval=TRUE, echo=FALSE-----------------------------------------

DatabaseConnector::insertTable(
  connection = connection,
  databaseSchema = cohortDatabaseSchema,
  tableName = tableName,
  data = cohort,
  dropTableIfExists = TRUE,
  createTable = TRUE,
  tempTable = FALSE,
  camelCaseToSnakeCase = TRUE,
  progressBar = FALSE
)

## ----tidy=FALSE,eval=TRUE, echo=TRUE------------------------------------------
CohortAlgebra::intersectCohorts(
  connection = connection,
  sourceCohortDatabaseSchema = cohortDatabaseSchema,
  sourceCohortTable = tableName,
  targetCohortDatabaseSchema = cohortDatabaseSchema,
  targetCohortTable = tableName,
  cohortIds = c(1, 2),
  newCohortId = 3
)

## ----tidy=FALSE,eval=TRUE, echo=FALSE-----------------------------------------

data <-
  DatabaseConnector::renderTranslateQuerySql(
    connection = connection,
    sql = paste0(
      "SELECT * FROM @cohort_database_schema.@table_name
        where cohort_definition_id = 3
        order by cohort_definition_id, subject_id, cohort_start_date;"
    ),
    cohort_database_schema = cohortDatabaseSchema,
    table_name = tableName,
    snakeCaseToCamelCase = TRUE
  ) %>%
  dplyr::tibble()

## ----tidy=FALSE,eval=TRUE, echo=FALSE-----------------------------------------

data

## ----tidy=FALSE,eval=TRUE, echo=FALSE-----------------------------------------
cohort <- dplyr::tibble(
  cohortDefinitionId = c(1, 2, 2),
  subjectId = c(1, 1, 1),
  cohortStartDate = c(
    as.Date("2022-01-01"),
    as.Date("2021-12-15"),
    as.Date("2022-01-10")
  ),
  cohortEndDate = c(
    as.Date("2022-01-15"),
    as.Date("2022-01-05"),
    as.Date("2022-01-30")
  )
)

## ----tidy=FALSE,eval=TRUE, echo=TRUE------------------------------------------
cohort

## ----tidy=FALSE,eval=TRUE, echo=FALSE-----------------------------------------

DatabaseConnector::insertTable(
  connection = connection,
  databaseSchema = cohortDatabaseSchema,
  tableName = tableName,
  data = cohort,
  dropTableIfExists = TRUE,
  createTable = TRUE,
  tempTable = FALSE,
  camelCaseToSnakeCase = TRUE,
  progressBar = FALSE
)

## ----tidy=FALSE,eval=TRUE, echo=TRUE------------------------------------------
CohortAlgebra::intersectCohorts(
  connection = connection,
  sourceCohortDatabaseSchema = cohortDatabaseSchema,
  sourceCohortTable = tableName,
  targetCohortDatabaseSchema = cohortDatabaseSchema,
  targetCohortTable = tableName,
  cohortIds = c(1, 2),
  newCohortId = 3
)

## ----tidy=FALSE,eval=TRUE, echo=FALSE-----------------------------------------

data <-
  DatabaseConnector::renderTranslateQuerySql(
    connection = connection,
    sql = paste0(
      "SELECT * FROM @cohort_database_schema.@table_name
        where cohort_definition_id = 3
        order by cohort_definition_id, subject_id, cohort_start_date;"
    ),
    cohort_database_schema = cohortDatabaseSchema,
    table_name = tableName,
    snakeCaseToCamelCase = TRUE
  ) %>%
  dplyr::tibble()

## ----tidy=FALSE,eval=TRUE, echo=FALSE-----------------------------------------
data

## ----tidy=FALSE,eval=TRUE, echo=FALSE-----------------------------------------
cohort <- dplyr::tibble(
  cohortDefinitionId = c(1, 2, 3),
  subjectId = c(1, 1, 1),
  cohortStartDate = c(
    as.Date("2022-01-01"),
    as.Date("2021-12-15"),
    as.Date("2022-03-01")
  ),
  cohortEndDate = c(
    as.Date("2022-01-15"),
    as.Date("2022-01-30"),
    as.Date("2022-03-15")
  )
)

## ----tidy=FALSE,eval=TRUE, echo=TRUE------------------------------------------
cohort

## ----tidy=FALSE,eval=TRUE, echo=FALSE-----------------------------------------

DatabaseConnector::insertTable(
  connection = connection,
  databaseSchema = cohortDatabaseSchema,
  tableName = tableName,
  data = cohort,
  dropTableIfExists = TRUE,
  createTable = TRUE,
  tempTable = FALSE,
  camelCaseToSnakeCase = TRUE,
  progressBar = FALSE
)

## ----tidy=FALSE,eval=TRUE, echo=TRUE------------------------------------------
CohortAlgebra::intersectCohorts(
  connection = connection,
  sourceCohortDatabaseSchema = cohortDatabaseSchema,
  sourceCohortTable = tableName,
  targetCohortDatabaseSchema = cohortDatabaseSchema,
  targetCohortTable = tableName,
  cohortIds = c(1, 2, 3),
  newCohortId = 4
)

## ----tidy=FALSE,eval=TRUE, echo=FALSE-----------------------------------------

data <-
  DatabaseConnector::renderTranslateQuerySql(
    connection = connection,
    sql = paste0(
      "SELECT * FROM @cohort_database_schema.@table_name
        where cohort_definition_id = 4
        order by cohort_definition_id, subject_id, cohort_start_date;"
    ),
    cohort_database_schema = cohortDatabaseSchema,
    table_name = tableName,
    snakeCaseToCamelCase = TRUE
  ) %>%
  dplyr::tibble()

## ----tidy=FALSE,eval=TRUE, echo=FALSE, echo=TRUE------------------------------

data

## ----tidy=FALSE,eval=TRUE, echo=FALSE-----------------------------------------
cohort <- dplyr::tibble(
  cohortDefinitionId = c(1, 2),
  subjectId = c(1, 1),
  cohortStartDate = c(
    as.Date("2022-01-01"),
    as.Date("2021-12-15")
  ),
  cohortEndDate = c(
    as.Date("2022-01-15"),
    as.Date("2022-01-30")
  )
)

## ----tidy=FALSE,eval=TRUE, echo=TRUE------------------------------------------
cohort

## ----tidy=FALSE,eval=TRUE, echo=FALSE-----------------------------------------

DatabaseConnector::insertTable(
  connection = connection,
  databaseSchema = cohortDatabaseSchema,
  tableName = tableName,
  data = cohort,
  dropTableIfExists = TRUE,
  createTable = TRUE,
  tempTable = FALSE,
  camelCaseToSnakeCase = TRUE,
  progressBar = FALSE
)

## ----tidy=FALSE,eval=TRUE, echo=TRUE------------------------------------------
CohortAlgebra::intersectCohorts(
  connection = connection,
  sourceCohortDatabaseSchema = cohortDatabaseSchema,
  sourceCohortTable = tableName,
  targetCohortDatabaseSchema = cohortDatabaseSchema,
  targetCohortTable = tableName,
  cohortIds = c(1, 2, 3),
  newCohortId = 4
)

## ----tidy=FALSE,eval=TRUE, echo=FALSE-----------------------------------------

data <-
  DatabaseConnector::renderTranslateQuerySql(
    connection = connection,
    sql = paste0(
      "SELECT * FROM @cohort_database_schema.@table_name
        where cohort_definition_id = 4
        order by cohort_definition_id, subject_id, cohort_start_date;"
    ),
    cohort_database_schema = cohortDatabaseSchema,
    table_name = tableName,
    snakeCaseToCamelCase = TRUE
  ) %>%
  dplyr::tibble()

## ----tidy=FALSE,eval=TRUE, echo=TRUE------------------------------------------

data

## ----tidy=FALSE,eval=TRUE,echo=FALSE------------------------------------------
cohort <- dplyr::tibble(
  cohortDefinitionId = c(1, 2),
  subjectId = c(1, 1),
  cohortStartDate = c(
    as.Date("2022-01-01"),
    as.Date("2022-01-01")
  ),
  cohortEndDate = c(
    as.Date("2022-01-01"),
    as.Date("2022-01-02")
  )
)

## ----tidy=FALSE,eval=TRUE, echo=TRUE------------------------------------------
cohort

## ----tidy=FALSE,eval=TRUE, echo=FALSE-----------------------------------------

DatabaseConnector::insertTable(
  connection = connection,
  databaseSchema = cohortDatabaseSchema,
  tableName = tableName,
  data = cohort,
  dropTableIfExists = TRUE,
  createTable = TRUE,
  tempTable = FALSE,
  camelCaseToSnakeCase = TRUE,
  progressBar = FALSE
)

## ----tidy=FALSE,eval=TRUE, echo=TRUE------------------------------------------
CohortAlgebra::intersectCohorts(
  connection = connection,
  sourceCohortDatabaseSchema = cohortDatabaseSchema,
  sourceCohortTable = tableName,
  targetCohortDatabaseSchema = cohortDatabaseSchema,
  targetCohortTable = tableName,
  cohortIds = c(1, 2),
  newCohortId = 3
)

## ----tidy=FALSE,eval=TRUE, echo=FALSE-----------------------------------------

data <-
  DatabaseConnector::renderTranslateQuerySql(
    connection = connection,
    sql = paste0(
      "SELECT * FROM @cohort_database_schema.@table_name
        where cohort_definition_id = 3
        order by cohort_definition_id, subject_id, cohort_start_date;"
    ),
    cohort_database_schema = cohortDatabaseSchema,
    table_name = tableName,
    snakeCaseToCamelCase = TRUE
  ) %>%
  dplyr::tibble()

## ----tidy=FALSE,eval=TRUE, echo=TRUE------------------------------------------

data

## ----tidy=FALSE,eval=TRUE, echo=FALSE-----------------------------------------
cohort <- dplyr::tibble(
  cohortDefinitionId = c(1, 2),
  subjectId = c(1, 1),
  cohortStartDate = c(
    as.Date("2022-01-01"),
    as.Date("2022-02-10")
  ),
  cohortEndDate = c(
    as.Date("2022-03-01"),
    as.Date("2022-05-10")
  )
)

## ----tidy=FALSE,eval=TRUE, echo=TRUE------------------------------------------
cohort

## ----tidy=FALSE,eval=TRUE, echo=FALSE-----------------------------------------

DatabaseConnector::insertTable(
  connection = connection,
  databaseSchema = cohortDatabaseSchema,
  tableName = tableName,
  data = cohort,
  dropTableIfExists = TRUE,
  createTable = TRUE,
  tempTable = FALSE,
  camelCaseToSnakeCase = TRUE,
  progressBar = FALSE
)

## ----tidy=FALSE,eval=TRUE, echo=TRUE------------------------------------------
CohortAlgebra::minusCohorts(
  connection = connection,
  sourceCohortDatabaseSchema = cohortDatabaseSchema,
  sourceCohortTable = tableName,
  targetCohortDatabaseSchema = cohortDatabaseSchema,
  targetCohortTable = tableName,
  firstCohortId = 1,
  secondCohortId = 2,
  newCohortId = 3
)

## ----tidy=FALSE,eval=TRUE, echo=FALSE-----------------------------------------

data <-
  DatabaseConnector::renderTranslateQuerySql(
    connection = connection,
    sql = paste0(
      "SELECT * FROM @cohort_database_schema.@table_name
        where cohort_definition_id = 3
        order by cohort_definition_id, subject_id, cohort_start_date;"
    ),
    cohort_database_schema = cohortDatabaseSchema,
    table_name = tableName,
    snakeCaseToCamelCase = TRUE
  ) %>%
  dplyr::tibble()

## ----tidy=FALSE,eval=TRUE, echo=TRUE------------------------------------------
data

## ----tidy=FALSE,eval=TRUE, echo=TRUE------------------------------------------
CohortAlgebra::minusCohorts(
  connection = connection,
  sourceCohortDatabaseSchema = cohortDatabaseSchema,
  sourceCohortTable = tableName,
  targetCohortDatabaseSchema = cohortDatabaseSchema,
  targetCohortTable = tableName,
  firstCohortId = 2,
  secondCohortId = 1,
  newCohortId = 4
)

## ----tidy=FALSE,eval=TRUE, echo=FALSE-----------------------------------------

data <-
  DatabaseConnector::renderTranslateQuerySql(
    connection = connection,
    sql = paste0(
      "SELECT * FROM @cohort_database_schema.@table_name
        where cohort_definition_id = 4
        order by cohort_definition_id, subject_id, cohort_start_date;"
    ),
    cohort_database_schema = cohortDatabaseSchema,
    table_name = tableName,
    snakeCaseToCamelCase = TRUE
  ) %>%
  dplyr::tibble()

## ----tidy=FALSE,eval=TRUE, echo=TRUE------------------------------------------
data

## ----tidy=FALSE,eval=TRUE, echo=FALSE-----------------------------------------
unlink(jdbcDriverFolder)
DatabaseConnector::renderTranslateExecuteSql(
  connection = connection,
  sql = "DROP TABLE IF EXISTS @cohort_table;",
  cohort_table = tableName,
  progressBar = FALSE,
  reportOverallTime = FALSE
)

## ----tidy=FALSE,eval=TRUE, echo=FALSE-----------------------------------------

# generate unique name for a cohort table
sysTime <- as.numeric(Sys.time()) * 100000
tableName <- paste0("cr", sysTime)
tempTableName <- paste0("#", tableName, "_1")

# make up date for a cohort table
# this cohort table will have two subjects * two cohorts, within the same cohort
cohort <- dplyr::tibble(
  cohortDefinitionId = c(1, 3, 3),
  subjectId = c(1, 3, 3),
  cohortStartDate = c(
    as.Date("1999-01-01"),
    as.Date("2010-01-01"),
    as.Date("1999-01-15")
  ),
  cohortEndDate = c(
    as.Date("1999-01-31"),
    as.Date("2010-01-05"),
    as.Date("1999-01-25")
  )
)

observationPeriod <- dplyr::tibble(
  personId = c(3),
  observation_period_start_date = as.Date("1979-01-01"),
  observation_period_end_date = as.Date("2020-12-31")
)

# upload table
connection <-
  DatabaseConnector::connect(connectionDetails = connectionDetails)
DatabaseConnector::insertTable(
  connection = connection,
  databaseSchema = cohortDatabaseSchema,
  tableName = tableName,
  data = cohort,
  dropTableIfExists = TRUE,
  createTable = TRUE,
  tempTable = FALSE,
  camelCaseToSnakeCase = TRUE,
  progressBar = FALSE
)

DatabaseConnector::insertTable(
  connection = connection,
  databaseSchema = cohortDatabaseSchema,
  tableName = "observation_period",
  data = observationPeriod,
  dropTableIfExists = TRUE,
  createTable = TRUE,
  tempTable = FALSE,
  camelCaseToSnakeCase = TRUE,
  progressBar = FALSE
)

## ----tidy=FALSE,eval=TRUE, echo=FALSE-----------------------------------------
cohort %>%
  dplyr::filter(.data$cohortDefinitionId == 1)

## ----tidy=FALSE,eval=TRUE, echo=TRUE------------------------------------------
CohortAlgebra::modifyCohort(
  connection = connection,
  cohortDatabaseSchema = cohortDatabaseSchema,
  cohortTable = tableName,
  oldCohortId = 1,
  newCohortId = 2,
  cohortStartCensorDate = as.Date("1999-01-05"), # for left censor
  cohortEndCensorDate = as.Date("1999-01-25") # for right censor
)

## ----tidy=FALSE,eval=TRUE, echo=FALSE-----------------------------------------
cohortObserved <-
  DatabaseConnector::renderTranslateQuerySql(
    connection = connection,
    sql = paste0(
      "SELECT * FROM @cohort_database_schema.@table_name
        WHERE cohort_definition_id = 2
        order by cohort_definition_id, subject_id, cohort_start_date;"
    ),
    cohort_database_schema = cohortDatabaseSchema,
    table_name = tableName,
    snakeCaseToCamelCase = TRUE
  ) %>%
  dplyr::tibble()

## ----tidy=FALSE,eval=TRUE, echo=FALSE-----------------------------------------
cohortObserved

## ----tidy=FALSE,eval=TRUE, echo=FALSE-----------------------------------------
cohort %>%
  dplyr::filter(.data$cohortDefinitionId == 3)

## ----tidy=FALSE,eval=TRUE, echo=TRUE------------------------------------------
CohortAlgebra::modifyCohort(
  connection = connection,
  cohortDatabaseSchema = cohortDatabaseSchema,
  cohortTable = tableName,
  oldCohortId = 3,
  newCohortId = 2,
  cohortStartFilterRange = c(as.Date("1998-01-01"), as.Date("1999-12-31")),
  purgeConflicts = TRUE
)

## ----tidy=FALSE,eval=TRUE, echo=FALSE-----------------------------------------
cohortObserved <-
  DatabaseConnector::renderTranslateQuerySql(
    connection = connection,
    sql = paste0(
      "SELECT * FROM @cohort_database_schema.@table_name
        WHERE cohort_definition_id = 2
        order by cohort_definition_id, subject_id, cohort_start_date;"
    ),
    cohort_database_schema = cohortDatabaseSchema,
    table_name = tableName,
    snakeCaseToCamelCase = TRUE
  ) %>%
  dplyr::tibble()

## ----tidy=FALSE,eval=TRUE, echo=FALSE-----------------------------------------
cohortObserved

## ----tidy=FALSE,eval=TRUE, echo=FALSE-----------------------------------------
cohort %>%
  dplyr::filter(.data$cohortDefinitionId == 1)

## ----tidy=FALSE,eval=FALSE, echo=TRUE-----------------------------------------
#  CohortAlgebra::modifyCohort(
#    connection = connection,
#    cohortDatabaseSchema = cohortDatabaseSchema,
#    cdmDatabaseSchema = cohortDatabaseSchema,
#    cohortTable = tableName,
#    oldCohortId = 1,
#    newCohortId = 2,
#    purgeConflicts = TRUE,
#    cohortStartPadDays = -10,
#    cohortEndPadDays = 5
#  )

## ----tidy=FALSE,eval=TRUE, echo=FALSE-----------------------------------------
# generate unique name for a cohort table
sysTime <- as.numeric(Sys.time()) * 100000
tableName <- paste0("cr", sysTime)
tempTableName <- paste0("#", tableName, "_1")

# make up date for a cohort table
cohort <- dplyr::tibble(
  cohortDefinitionId = c(1, 1, 3, 5),
  subjectId = c(1, 2, 2, 2),
  cohortStartDate = c(
    as.Date("1999-01-01"),
    as.Date("2010-01-01"),
    as.Date("1999-01-15"),
    as.Date("1999-01-01")
  ),
  cohortEndDate = c(
    as.Date("1999-01-31"),
    as.Date("2010-01-05"),
    as.Date("1999-01-25"),
    as.Date("1999-01-31")
  )
)

# upload table
connection <-
  DatabaseConnector::connect(connectionDetails = connectionDetails)
DatabaseConnector::insertTable(
  connection = connection,
  databaseSchema = cohortDatabaseSchema,
  tableName = tableName,
  data = cohort,
  dropTableIfExists = TRUE,
  createTable = TRUE,
  tempTable = FALSE,
  camelCaseToSnakeCase = TRUE,
  progressBar = FALSE
)

## ----tidy=FALSE,eval=TRUE, echo=FALSE-----------------------------------------
cohort %>%
  dplyr::filter(.data$cohortDefinitionId %in% c(1, 3))

## ----tidy=FALSE,eval=TRUE, echo=TRUE------------------------------------------
CohortAlgebra::removeOverlappingSubjects(
  connection = connection,
  cohortDatabaseSchema = cohortDatabaseSchema,
  cohortId = 1,
  newCohortId = 6,
  cohortsWithSubjectsToRemove = c(3),
  purgeConflicts = FALSE,
  cohortTable = tableName
)

## ----tidy=FALSE,eval=TRUE, echo=FALSE-----------------------------------------
cohortObserved <-
  DatabaseConnector::renderTranslateQuerySql(
    connection = connection,
    sql = paste0(
      "SELECT * FROM @cohort_database_schema.@table_name
        WHERE cohort_definition_id = 6
        order by cohort_definition_id, subject_id, cohort_start_date;"
    ),
    cohort_database_schema = cohortDatabaseSchema,
    table_name = tableName,
    snakeCaseToCamelCase = TRUE
  ) %>%
  dplyr::tibble()

cohortObserved

