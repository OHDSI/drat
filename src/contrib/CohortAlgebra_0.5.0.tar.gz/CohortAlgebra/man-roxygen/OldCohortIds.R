#' @param oldCohortIds   An array of 1 or more integer id representing the cohort id of the cohort 
#'                       on which the function will be applied.
