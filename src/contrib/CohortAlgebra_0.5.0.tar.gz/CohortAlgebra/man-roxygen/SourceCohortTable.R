#' @param sourceCohortTable            The name of the source cohort table.
