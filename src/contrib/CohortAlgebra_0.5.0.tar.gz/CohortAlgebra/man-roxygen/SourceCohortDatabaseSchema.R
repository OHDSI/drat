#' @param sourceCohortDatabaseSchema   Schema name where your source cohort tables reside. Note that for SQL Server,
#'                               this should include both the database and schema name, for example
#'                               'scratch.dbo'.
