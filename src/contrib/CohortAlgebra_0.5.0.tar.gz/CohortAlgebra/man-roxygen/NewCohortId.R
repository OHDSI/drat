#' @param newCohortId   The cohort id of the output cohort.
