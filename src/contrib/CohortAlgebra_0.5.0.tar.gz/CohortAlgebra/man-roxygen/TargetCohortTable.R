#' @param targetCohortTable            The name of the target cohort table.
