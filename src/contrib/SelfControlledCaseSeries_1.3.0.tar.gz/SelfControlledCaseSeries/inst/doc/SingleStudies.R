## ---- echo = FALSE, message = FALSE, warning = FALSE---------------------
library(SelfControlledCaseSeries)
knitr::opts_chunk$set(
  cache=FALSE,
  comment = "#>",
  error = FALSE,
  tidy = FALSE)

## ----tidy=TRUE,eval=FALSE------------------------------------------------
#  install.packages("devtools")
#  library(devtools)
#  install_github("ohdsi/OhdsiRTools")
#  install_github("ohdsi/SqlRender")
#  install_github("ohdsi/DatabaseConnector")
#  install_github("ohdsi/Cyclops")
#  install_github("ohdsi/SelfControlledCaseSeries")

## ----tidy=FALSE,eval=FALSE-----------------------------------------------
#  connectionDetails <- createConnectionDetails(dbms = "postgresql",
#                                               server = "localhost/ohdsi",
#                                               user = "joe",
#                                               password = "supersecret")
#  
#  cdmDatabaseSchema <- "my_cdm_data"
#  cohortDatabaseSchema <- "my_results"
#  cdmVersion <- "5"

## ----tidy=FALSE,eval=FALSE-----------------------------------------------
#  library(SqlRender)
#  sql <- readSql("vignette.sql")
#  sql <- renderSql(sql,
#                   cdmDatabaseSchema = cdmDatabaseSchema,
#                   cohortDatabaseSchema = cohortDatabaseSchema
#                   outcomeTable = "my_outcomes")$sql
#  sql <- translateSql(sql, targetDialect = connectionDetails$dbms)$sql
#  
#  connection <- connect(connectionDetails)
#  executeSql(connection, sql)

## ----tidy=FALSE,eval=FALSE-----------------------------------------------
#  sql <- paste("SELECT cohort_definition_id, COUNT(*) AS count",
#               "FROM @cohortDatabaseSchema.@outcomeTable",
#               "GROUP BY cohort_definition_id")
#  sql <- renderSql(sql,
#                   cohortDatabaseSchema = cohortDatabaseSchema,
#                   outcomeTable = "my_outcomes")$sql
#  sql <- translateSql(sql, targetDialect = connectionDetails$dbms)$sql
#  
#  querySql(connection, sql)

## ----echo=FALSE,message=FALSE--------------------------------------------
data.frame(cohort_concept_id = c(1),count=c(635684))

## ----tidy=FALSE,eval=FALSE-----------------------------------------------
#  diclofenac <- 1124300
#  
#  sccsData <- getDbSccsData(connectionDetails = connectionDetails,
#                            cdmDatabaseSchema = cdmDatabaseSchema,
#                            oracleTempSchema = oracleTempSchema,
#                            outcomeDatabaseSchema = cohortDatabaseSchema,
#                            outcomeTable = outcomeTable,
#                            outcomeIds = 1,
#                            exposureDatabaseSchema = cdmDatabaseSchema,
#                            exposureTable = "drug_era",
#                            exposureIds = diclofenac,
#                            cdmVersion = cdmVersion)
#  sccsData

## ----echo=FALSE,message=FALSE,eval=TRUE----------------------------------
diclofenac <- 1124300
if (file.exists("s:/temp/vignetteSccs")){
  sccsData <- loadSccsData("s:/temp/vignetteSccs/data1")
} 

## ----echo=FALSE,message=FALSE--------------------------------------------
if (file.exists("s:/temp/vignetteSccs")){
  sccsData
}

## ----tidy=TRUE,eval=FALSE------------------------------------------------
#  summary(sccsData)

## ----echo=FALSE,message=FALSE--------------------------------------------
if (file.exists("s:/temp/vignetteSccs")){
  summary(sccsData)
}

## ----tidy=TRUE,eval=FALSE------------------------------------------------
#  saveSccsData(sccsData, "diclofenacAndGiBleed")

## ----tidy=FALSE,eval=FALSE-----------------------------------------------
#  covarDiclofenac = createCovariateSettings(label = "Exposure of interest",
#                                            includeCovariateIds = diclofenac,
#                                            start = 0,
#                                            end = 0,
#                                            addExposedDaysToEnd = TRUE)
#  
#  sccsEraData <- createSccsEraData(sccsData,
#                                   naivePeriod = 180,
#                                   firstOutcomeOnly = FALSE,
#                                   covariateSettings = covarDiclofenac)
#  
#  summary(sccsEraData)

## ----echo=FALSE,message=FALSE--------------------------------------------
if (file.exists("s:/temp/vignetteSccs")){
  sccsEraData <- loadSccsEraData("s:/temp/vignetteSccs/eraData1")
  summary(sccsEraData)
}

## ----tidy=TRUE,eval=FALSE------------------------------------------------
#  computeMdrr(sccsEraData,
#              exposureCovariateId = 1000,
#              alpha = 0.05,
#              power = 0.8,
#              twoSided = TRUE,
#              method = "binomial")

## ----echo=FALSE,message=FALSE--------------------------------------------
if (file.exists("s:/temp/vignetteSccs")){
  computeMdrr(sccsEraData,
              exposureCovariateId = 1000,
              alpha = 0.05,
              power = 0.8,
              twoSided = TRUE,
              method = "binomial")
}

## ----tidy=FALSE,eval=FALSE-----------------------------------------------
#  model <- fitSccsModel(sccsEraData)

## ----tidy=TRUE,eval=FALSE------------------------------------------------
#  summary(model)

## ----echo=FALSE,message=FALSE--------------------------------------------
if (file.exists("s:/temp/vignetteSccs")){
  model <- readRDS("s:/temp/vignetteSccs/simpleModel.rds")
  summary(model)
}

## ----tidy=FALSE,eval=FALSE-----------------------------------------------
#    covarPreDiclofenac = createCovariateSettings(label = "Pre-exposure",
#                                                 includeCovariateIds = diclofenac,
#                                                 start = -60,
#                                                 end = -1)
#  
#    sccsEraData <- createSccsEraData(sccsData,
#                                     naivePeriod = 180,
#                                     firstOutcomeOnly = FALSE,
#                                     covariateSettings = list(covarDiclofenac,
#                                                              covarPreDiclofenac))
#  
#    model <- fitSccsModel(sccsEraData)

## ----tidy=TRUE,eval=FALSE------------------------------------------------
#  summary(model)

## ----echo=FALSE,message=FALSE--------------------------------------------
if (file.exists("s:/temp/vignetteSccs")){
  model <- readRDS("s:/temp/vignetteSccs/preExposureModel.rds")
  summary(model)
}

## ----tidy=FALSE,eval=FALSE-----------------------------------------------
#    covarDiclofenacSplit = createCovariateSettings(label = "Exposure of interest",
#                                                   includeCovariateIds = diclofenac,
#                                                   start = 0,
#                                                   end = 0,
#                                                   addExposedDaysToEnd = TRUE,
#                                                   splitPoints = c(7,14))
#  
#    covarPreDiclofenacSplit = createCovariateSettings(label = "Pre-exposure",
#                                                      includeCovariateIds = diclofenac,
#                                                      start = -60,
#                                                      end = -1,
#                                                      splitPoints = c(-30))
#  
#    sccsEraData <- createSccsEraData(sccsData,
#                                     naivePeriod = 180,
#                                     firstOutcomeOnly = FALSE,
#                                     covariateSettings = list(covarDiclofenacSplit,
#                                                              covarPreDiclofenacSplit))

## ----tidy=TRUE,eval=FALSE------------------------------------------------
#  summary(model)

## ----echo=FALSE,message=FALSE--------------------------------------------
if (file.exists("s:/temp/vignetteSccs")){
  model <- readRDS("s:/temp/vignetteSccs/splitModel.rds")
  summary(model)
}

## ----tidy=FALSE,eval=FALSE-----------------------------------------------
#  ageSettings <- createAgeSettings(includeAge = TRUE,
#                                   ageKnots = 5)
#  
#  seasonalitySettings <- createSeasonalitySettings(includeSeasonality = TRUE,
#                                                   seasonKnots = 5)
#  
#  sccsEraData <- createSccsEraData(sccsData,
#                                   naivePeriod = 180,
#                                   firstOutcomeOnly = FALSE,
#                                   covariateSettings = list(covarDiclofenacSplit,
#                                                            covarPreDiclofenacSplit),
#                                   ageSettings = ageSettings,
#                                   seasonalitySettings = seasonalitySettings)
#  
#  model <- fitSccsModel(sccsEraData)

## ----tidy=TRUE,eval=FALSE------------------------------------------------
#  summary(model)

## ----echo=FALSE,message=FALSE--------------------------------------------
if (file.exists("s:/temp/vignetteSccs/ageAndSeasonModel.rds")){
  model <- readRDS("s:/temp/vignetteSccs/ageAndSeasonModel.rds")
  summary(model)
}

## ----tidy=TRUE,eval=FALSE------------------------------------------------
#  plotAgeEffect(model)

## ----echo=FALSE,message=FALSE--------------------------------------------
if (file.exists("s:/temp/vignetteSccs/ageAndSeasonModel.rds")){
  plotAgeEffect(model)
}

## ----tidy=TRUE,eval=FALSE------------------------------------------------
#  plotSeasonality(model)

## ----echo=FALSE,message=FALSE--------------------------------------------
if (file.exists("s:/temp/vignetteSccs/ageAndSeasonModel.rds")){
  plotSeasonality(model)
}

## ----tidy=FALSE,eval=FALSE-----------------------------------------------
#  sccsEraData <- createSccsEraData(sccsData,
#                                   naivePeriod = 180,
#                                   firstOutcomeOnly = FALSE,
#                                   covariateSettings = list(covarDiclofenacSplit,
#                                                            covarPreDiclofenacSplit),
#                                   ageSettings = ageSettings,
#                                   seasonalitySettings = seasonalitySettings,
#                                   eventDependentObservation = TRUE)
#  
#  model <- fitSccsModel(sccsEraData)

## ----tidy=TRUE,eval=FALSE------------------------------------------------
#  summary(model)

## ----echo=FALSE,message=FALSE--------------------------------------------
if (file.exists("s:/temp/vignetteSccs/eventDepModel.rds")){
  model <- readRDS("s:/temp/vignetteSccs/eventDepModel.rds")
  summary(model)
}

## ----tidy=FALSE,eval=FALSE-----------------------------------------------
#  diclofenac <- 1124300
#  ppis <- c(911735, 929887, 923645, 904453, 948078, 19039926)
#  
#  sccsData <- getDbSccsData(connectionDetails = connectionDetails,
#                            cdmDatabaseSchema = cdmDatabaseSchema,
#                            oracleTempSchema = oracleTempSchema,
#                            outcomeDatabaseSchema = cohortDatabaseSchema,
#                            outcomeTable = outcomeTable,
#                            outcomeIds = 1,
#                            exposureDatabaseSchema = cdmDatabaseSchema,
#                            exposureTable = "drug_era",
#                            exposureIds = c(diclofenac, ppis),
#                            cdmVersion = cdmVersion)
#  sccsData

## ----echo=FALSE,message=FALSE,eval=TRUE----------------------------------
ppis <- c(911735, 929887, 923645, 904453, 948078, 19039926)
if (file.exists("s:/temp/vignetteSccs")){
  sccsData <- loadSccsData("s:/temp/vignetteSccs/data2")
} 

## ----echo=FALSE,message=FALSE--------------------------------------------
if (file.exists("s:/temp/vignetteSccs")){
  sccsData
}

## ----tidy=FALSE,eval=FALSE-----------------------------------------------
#  covarPpis = createCovariateSettings(label = "PPIs",
#                                      includeCovariateIds = ppis,
#                                      stratifyById = FALSE,
#                                      start = 1,
#                                      end = 0,
#                                      addExposedDaysToEnd = TRUE)
#  
#  sccsEraData <- createSccsEraData(sccsData,
#                                   naivePeriod = 180,
#                                   firstOutcomeOnly = FALSE,
#                                   covariateSettings = list(covarDiclofenacSplit,
#                                                            covarPreDiclofenacSplit,
#                                                            covarPpis),
#                                   ageSettings = ageSettings,
#                                   seasonalitySettings = seasonalitySettings,
#                                   eventDependentObservation = TRUE)
#  
#  model <- fitSccsModel(sccsEraData)

## ----tidy=TRUE,eval=FALSE------------------------------------------------
#  summary(model)

## ----echo=FALSE,message=FALSE--------------------------------------------
if (file.exists("s:/temp/vignetteSccs/ppiModel.rds")){
  model <- readRDS("s:/temp/vignetteSccs/ppiModel.rds")
  summary(model)
}

## ----tidy=FALSE,eval=FALSE-----------------------------------------------
#  sccsData <- getDbSccsData(connectionDetails = connectionDetails,
#                            cdmDatabaseSchema = cdmDatabaseSchema,
#                            oracleTempSchema = oracleTempSchema,
#                            outcomeDatabaseSchema = cohortDatabaseSchema,
#                            outcomeTable = outcomeTable,
#                            outcomeIds = 1,
#                            exposureDatabaseSchema = cdmDatabaseSchema,
#                            exposureTable = "drug_era",
#                            exposureIds = c(),
#                            cdmVersion = cdmVersion)

## ----tidy=FALSE,eval=FALSE-----------------------------------------------
#  covarAllDrugs = createCovariateSettings(label = "All other exposures",
#                                          excludeCovariateIds = diclofenac,
#                                          stratifyById = TRUE,
#                                          start = 1,
#                                          end = 0,
#                                          addExposedDaysToEnd = TRUE,
#                                          allowRegularization = TRUE)
#  
#  sccsEraData <- createSccsEraData(sccsData,
#                                   naivePeriod = 180,
#                                   firstOutcomeOnly = FALSE,
#                                   covariateSettings = list(covarDiclofenacSplit,
#                                                            covarPreDiclofenacSplit,
#                                                            covarAllDrugs),
#                                   ageSettings = ageSettings,
#                                   seasonalitySettings = seasonalitySettings,
#                                   eventDependentObservation = TRUE)
#  
#  model <- fitSccsModel(sccsEraData)

## ----tidy=TRUE,eval=FALSE------------------------------------------------
#    estimates <- getModel(model)
#    estimates[estimates$originalCovariateId == diclofenac,]

## ----echo=FALSE,message=FALSE--------------------------------------------
if (file.exists("s:/temp/vignetteSccs/allDrugsModel.rds")){
  model <- readRDS("s:/temp/vignetteSccs/allDrugsModel.rds")
  estimates <- getModel(model)
  estimates[estimates$originalCovariateId == diclofenac,]
}

## ----tidy=TRUE,eval=FALSE------------------------------------------------
#    estimates[estimates$originalCovariateId %in% ppis,]

## ----echo=FALSE,message=FALSE--------------------------------------------
if (file.exists("s:/temp/vignetteSccs/allDrugsModel.rds")){
  estimates[estimates$originalCovariateId %in% ppis,]
}

## ----tidy=TRUE,eval=FALSE------------------------------------------------
#  plotExposureCentered(sccsData, exposureId = diclofenac, naivePeriod = 180)

## ----echo=FALSE,message=FALSE,fig.width=6.5, fig.height=5----------------
if (file.exists("s:/temp/vignetteSccs")){
  plotExposureCentered(sccsData, exposureId = diclofenac, naivePeriod = 180)
}

## ----tidy=TRUE,eval=FALSE------------------------------------------------
#  plotAgeSpans(sccsData, naivePeriod = 180)

## ----echo=FALSE,message=FALSE--------------------------------------------
if (file.exists("s:/temp/vignetteSccs")){
  plotAgeSpans(sccsData, naivePeriod = 180)
}

## ----tidy=TRUE,eval=FALSE------------------------------------------------
#  plotEventObservationDependence(sccsData, naivePeriod = 180)

## ----echo=FALSE,message=FALSE--------------------------------------------
if (file.exists("s:/temp/vignetteSccs")){
  sccsData <- loadSccsData("s:/temp/vignetteSccs/data1")
  plotEventObservationDependence(sccsData, naivePeriod = 180)
}

## ----tidy=TRUE,eval=TRUE-------------------------------------------------
citation("SelfControlledCaseSeries")

## ----tidy=TRUE,eval=TRUE-------------------------------------------------
citation("Cyclops")

