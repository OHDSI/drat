OhdsiSharing 0.2.0
==================

Changes:

1. Dropping S3 support.

2. Adding SFTP support.
