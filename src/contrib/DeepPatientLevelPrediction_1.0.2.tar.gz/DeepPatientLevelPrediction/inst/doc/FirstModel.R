## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)

## ---- echo = TRUE, message = FALSE, warning = FALSE,tidy=FALSE,eval=FALSE-----
#  install.packages('Eunomia')

## ---- echo = TRUE, message = FALSE, warning = FALSE,tidy=FALSE,eval=FALSE-----
#  connectionDetails <- Eunomia::getEunomiaConnectionDetails()
#  Eunomia::createCohorts(connectionDetails)

## ---- echo = TRUE, message = FALSE, warning = FALSE,tidy=FALSE,eval=FALSE-----
#  covariateSettings <- FeatureExtraction::createCovariateSettings(
#    useDemographicsGender = TRUE,
#    useDemographicsAge = TRUE,
#    useConditionOccurrenceLongTerm = TRUE
#  )

## ---- echo = TRUE, message = FALSE, warning = FALSE,tidy=FALSE,eval=FALSE-----
#  databaseDetails <- PatientLevelPrediction::createDatabaseDetails(
#    connectionDetails = connectionDetails,
#    cdmDatabaseSchema = "main",
#    cdmDatabaseId = 1,
#    cohortDatabaseSchema = "main",
#    cohortTable = "cohort",
#    targetId= 4,
#    outcomeIds = 3,
#    outcomeDatabaseSchema = "main",
#    outcomeTable =  "cohort",
#    cdmDatabaseName = 'eunomia'
#  )

## ---- echo = TRUE, message = FALSE, warning = FALSE,tidy=FALSE,eval=FALSE-----
#  populationSettings <- PatientLevelPrediction::createStudyPopulationSettings(
#                                                            requireTimeAtRisk = F,
#                                                            riskWindowStart = 1,
#                                                            riskWindowEnd = 365)
#  plpData <- PatientLevelPrediction::getPlpData(
#    databaseDetails = databaseDetails,
#    covariateSettings = covariateSettings,
#    restrictPlpDataSettings = PatientLevelPrediction::createRestrictPlpDataSettings())

## ---- echo = TRUE, message = FALSE, warning = FALSE,tidy=FALSE,eval=FALSE-----
#  library(DeepPatientLevelPrediction)
#  modelSettings <- setDefaultResNet(
#    device = 'cpu',
#    batchSize = 256,
#    epochs=3
#  )
#  

## ---- echo = TRUE, message = FALSE, warning = FALSE,tidy=FALSE,eval=FALSE-----
#  plpResults <- PatientLevelPrediction::runPlp(plpData = plpData,
#                 outcomeId = 3,
#                 modelSettings = modelSettings,
#                 analysisId = 'ResNet',
#                 analysisName = 'Testing DeepPlp',
#                 populationSettings = populationSettings
#                                                        )

## ----tidy=TRUE,eval=TRUE------------------------------------------------------
citation("DeepPatientLevelPrediction")

