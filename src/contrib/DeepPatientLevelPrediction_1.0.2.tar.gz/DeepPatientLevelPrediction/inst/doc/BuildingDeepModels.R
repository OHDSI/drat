## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)

## ---- eval=FALSE--------------------------------------------------------------
#  
#  # load the data
#  plpData <- PatientLevelPrediction::loadPlpData('locationOfData')
#  
#  # pick the set<Model> from  DeepPatientLevelPrediction
#  deepLearningModel <- DeepPatientLevelPrediction::setResNet()
#  
#  # use PatientLevelPrediction to fit model
#  deepLearningResult <- PatientLevelPrediction::runPlp(
#      plpData = plpData,
#      outcomeId = 1230,
#      modelSettings = deepLearningModel,
#      analysisId = 'resNetTorch',
#      ...
#    )
#  

## ---- eval=FALSE--------------------------------------------------------------
#  
#  modelSettings <- setMultiLayerPerceptron(
#                                  numLayers = c(3, 5),
#                                  numHidden = c(64, 128),
#                                  dropout = c(0.2),
#                                  sizeEmbedding = c(32, 64),
#                                  learningRate = c(1e-3, 1e-4),
#                                  weightDecay = c(1e-5),
#                                  randomSample=10,
#                                  batchSize = c(100),
#                                  epochs = c(5),
#                                  seed = 12
#                                  )
#  
#  mlpResult <- PatientLevelPrediction::runPlp(
#      plpData = plpData,
#      outcomeId = 3,
#      modelSettings = modelSettings,
#      analysisId = 'MLP',
#      analysisName = 'Testing Deep Learning',
#      populationSettings = populationSet,
#      splitSettings = PatientLevelPrediction::createDefaultSplitSetting(),
#      sampleSettings = PatientLevelPrediction::createSampleSettings(),  # none
#      featureEngineeringSettings = PatientLevelPrediction::createFeatureEngineeringSettings(), # none
#      preprocessSettings = PatientLevelPrediction::createPreprocessSettings(),
#      executeSettings = PatientLevelPrediction::createExecuteSettings(
#        runSplitData = T,
#        runSampleData = F,
#        runfeatureEngineering = F,
#        runPreprocessData = T,
#        runModelDevelopment = T,
#        runCovariateSummary = F
#      ),
#      saveDirectory = file.path(testLoc, 'DeepNNTorch')
#    )
#  

## ---- eval=FALSE--------------------------------------------------------------
#  
#  resset <- setResNet(
#    numLayers = c(2),
#    sizeHidden = c(32),
#    hiddenFactor = c(2),
#    residualDropout = c(0.1),
#    hiddenDropout = c(0.1),
#    sizeEmbedding = c(32),
#    weightDecay = c(1e-6),
#    learningRate = c(3e-4),
#    seed = 42,
#    hyperParamSearch = 'random',
#    randomSample = 1,
#    #device='cuda:0', # uncomment to use GPU
#    batchSize = 128,
#    epochs = 3
#  )
#  
#  resResult <- PatientLevelPrediction::runPlp(
#      plpData = plpData,
#      outcomeId = 3,
#      modelSettings = resset,
#      analysisId = 'ResNet',
#      analysisName = 'Testing ResNet',
#      populationSettings = populationSet,
#      splitSettings = PatientLevelPrediction::createDefaultSplitSetting(),
#      sampleSettings = PatientLevelPrediction::createSampleSettings(),
#      featureEngineeringSettings = PatientLevelPrediction::createFeatureEngineeringSettings(),
#      preprocessSettings = PatientLevelPrediction::createPreprocessSettings(),
#      executeSettings = PatientLevelPrediction::createExecuteSettings(
#        runSplitData = T,
#        runSampleData = F,
#        runfeatureEngineering = F,
#        runPreprocessData = T,
#        runModelDevelopment = T,
#        runCovariateSummary = F
#      ),
#      saveDirectory = file.path(getwd(), 'ResNet') # change to save elsewhere
#    )
#  

## ---- eval=FALSE--------------------------------------------------------------
#  
#  modelSettings <- setTransformer(numBlocks = 3,
#                                  dimToken = 32,
#                                  dimOut = 1,
#                                  numHeads = 4,
#                                  attDropout = 0.25,
#                                  ffnDropout = 0.25,
#                                  resDropout = 0,
#                                  dimHidden = 128,
#                                  weightDecay = 1e-06,
#                                  learningRate = 3e-04
#                                  batchSize = 128,
#                                  epochs = 10,
#                                  device = 'cpu',  # or 'cuda' for GPU
#                                  randomSample = 1)
#  
#  
#  TransformerResult <- PatientLevelPrediction::runPlp(
#      plpData = plpData,
#      outcomeId = 3,
#      modelSettings = modelSettings,
#      analysisId = 'Transformer',
#      analysisName = 'Testing transformer',
#      populationSettings = populationSet,
#      splitSettings = PatientLevelPrediction::createDefaultSplitSetting(),
#      sampleSettings = PatientLevelPrediction::createSampleSettings(),  # none
#      featureEngineeringSettings = PatientLevelPrediction::createFeatureEngineeringSettings(), # none
#      preprocessSettings = PatientLevelPrediction::createPreprocessSettings(),
#      executeSettings = PatientLevelPrediction::createExecuteSettings(
#        runSplitData = T,
#        runSampleData = F,
#        runfeatureEngineering = F,
#        runPreprocessData = T,
#        runModelDevelopment = T,
#        runCovariateSummary = F
#      ),
#      saveDirectory = file.path(getwd(), 'Transformer') # change to save elsewhere
#    )

## ----tidy=TRUE,eval=TRUE------------------------------------------------------
citation("DeepPatientLevelPrediction")

