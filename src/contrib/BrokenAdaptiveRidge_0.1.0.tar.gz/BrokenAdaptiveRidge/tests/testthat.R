library(testthat)
library(BrokenAdaptiveRidge)

test_check("BrokenAdaptiveRidge")
