library(testthat)
test_check("EmpiricalCalibration")
