library(testthat)
library(ROhdsiWebApi)
options(ohdsiWebApiAuthType = "windows")
test_check("ROhdsiWebApi")
