library(testthat)
library(ROhdsiWebApi)
options(ohdsiWebApiAuthType = "ad")
test_check("ROhdsiWebApi")
