library(testthat)
library(ROhdsiWebApi)
options(ohdsiWebApiAuthType = "db")
test_check("ROhdsiWebApi")
