## ---- echo = FALSE, message = FALSE, warning = FALSE---------------------
library(CaseControl)
knitr::opts_chunk$set(
  cache=FALSE,
  comment = "#>",
  error = FALSE,
  tidy = FALSE)

## ----tidy=TRUE,eval=FALSE------------------------------------------------
#  install.packages("drat")
#  drat::addRepo("OHDSI")
#  install.packages("CaseControl")

## ----tidy=FALSE,eval=FALSE-----------------------------------------------
#  connectionDetails <- createConnectionDetails(dbms = "postgresql",
#                                               server = "localhost/ohdsi",
#                                               user = "joe",
#                                               password = "supersecret")
#  
#  cdmDatabaseSchema <- "my_cdm_data"
#  cohortDatabaseSchema <- "my_results"
#  cohortTable <- "my_cohorts"
#  cdmVersion <- "5"

## ----tidy=FALSE,eval=FALSE-----------------------------------------------
#  library(SqlRender)
#  sql <- readSql("vignette.sql")
#  sql <- render(sql,
#                cdmDatabaseSchema = cdmDatabaseSchema,
#                cohortDatabaseSchema = cohortDatabaseSchema
#                cohortTable = cohortTable)
#  sql <- translate(sql, targetDialect = connectionDetails$dbms)
#  
#  connection <- connect(connectionDetails)
#  executeSql(connection, sql)

## ----tidy=FALSE,eval=FALSE-----------------------------------------------
#  sql <- paste("SELECT cohort_definition_id, COUNT(*) AS count",
#               "FROM @cohortDatabaseSchema.@cohortTable",
#               "GROUP BY cohort_definition_id")
#  sql <- render(sql,
#                cohortDatabaseSchema = cohortDatabaseSchema,
#                cohortTable = cohortTable)
#  sql <- translate(sql, targetDialect = connectionDetails$dbms)
#  
#  querySql(connection, sql)

## ----echo=FALSE,message=FALSE--------------------------------------------
data.frame(cohort_definition_id = c(1,2),count=c(422274, 118430))

## ----tidy=FALSE,eval=FALSE-----------------------------------------------
#  caseData <- getDbCaseData(connectionDetails = connectionDetails,
#                            cdmDatabaseSchema = cdmDatabaseSchema,
#                            oracleTempSchema = oracleTempSchema,
#                            outcomeDatabaseSchema = cohortDatabaseSchema,
#                            cohortTable = cohortTable,
#                            outcomeIds = 1,
#                            useNestingCohort = TRUE,
#                            nestingCohortDatabaseSchema = cohortDatabaseSchema,
#                            nestingCohortTable = cohortTable,
#                            nestingCohortId = 2,
#                            useObservationEndAsNestingEndDate = TRUE,
#                            getVisits = TRUE)
#  caseData

## ----echo=FALSE,message=FALSE,eval=TRUE----------------------------------
if (file.exists("s:/temp/vignetteCaseControl")){
  caseData <- loadCaseData("s:/temp/vignetteCaseControl/caseData")
} 

## ----echo=FALSE,message=FALSE--------------------------------------------
if (file.exists("s:/temp/vignetteCaseControl")){
  caseData
}

## ----tidy=TRUE,eval=FALSE------------------------------------------------
#  summary(caseData)

## ----echo=FALSE,message=FALSE--------------------------------------------
if (file.exists("s:/temp/vignetteCaseControl")){
  summary(caseData)
}

## ----tidy=TRUE,eval=FALSE------------------------------------------------
#  saveCaseData(caseData, "GiBleed")

## ----tidy=FALSE,eval=FALSE-----------------------------------------------
#  caseControls <- selectControls(caseData = caseData,
#                                 outcomeId = 1,
#                                 firstOutcomeOnly = TRUE,
#                                 washoutPeriod = 180,
#                                 controlsPerCase = 2,
#                                 matchOnAge = TRUE,
#                                 ageCaliper = 2,
#                                 matchOnGender = TRUE,
#                                 matchOnProvider = FALSE,
#                                 matchOnVisitDate = TRUE,
#                                 visitDateCaliper = 30,
#                                 removedUnmatchedCases = TRUE)

## ----echo=TRUE,message=FALSE,eval=FALSE----------------------------------
#  head(caseControls)

## ----echo=FALSE,message=FALSE--------------------------------------------
data.frame(personId = c(3,123,345,6,234,567),
           indexDate = c("2009-10-10", "2009-10-11", "2009-10-09", "2010-05-04", "2010-05-04", "2010-05-05"), 
           isCase = c(TRUE, FALSE, FALSE, TRUE, FALSE, FALSE), 
           stratumId = c(1,1,1,2,2,2))

## ----tidy=FALSE,eval=FALSE-----------------------------------------------
#  getAttritionTable(caseControls)

## ----echo=FALSE,message=FALSE,eval=TRUE----------------------------------
if (file.exists("s:/temp/vignetteCaseControl")){
  caseControls <- readRDS("s:/temp/vignetteCaseControl/caseControls.rds")
} 

## ----echo=FALSE,message=FALSE--------------------------------------------
if (file.exists("s:/temp/vignetteCaseControl")){
  getAttritionTable(caseControls)
}

## ----tidy=FALSE,eval=FALSE-----------------------------------------------
#  covarSettings <- createCovariateSettings(useCharlsonIndex = TRUE,
#                                           useChads2 = TRUE,
#                                           useDcsi = TRUE)
#  
#  caseControlsExposure <- getDbExposureData(connectionDetails = connectionDetails,
#                                            caseControls = caseControls,
#                                            oracleTempSchema = oracleTempSchema,
#                                            exposureDatabaseSchema = cdmDatabaseSchema,
#                                            exposureTable = "drug_era",
#                                            exposureIds = 1124300,
#                                            covariateSettings = covarSettings)

## ----tidy=TRUE,eval=FALSE------------------------------------------------
#  saveCaseControlsExposure(caseControlsExposure, "caseControlsExposure")

## ----tidy=FALSE,eval=FALSE-----------------------------------------------
#  caseControlData <- createCaseControlData(caseControlsExposure = caseControlsExposure,
#                                           exposureId = 1124300,
#                                           firstExposureOnly = FALSE,
#                                           riskWindowStart = 0,
#                                           riskWindowEnd = 0)

## ----echo=TRUE,message=FALSE,eval=FALSE----------------------------------
#  head(caseControlData)

## ----echo=FALSE,message=FALSE--------------------------------------------
data.frame(personId = c(3,123,345,6,234,567),
           indexDate = c("2009-10-10", "2009-10-11", "2009-10-09", "2010-05-04", "2010-05-04", "2010-05-05"), 
           isCase = c(TRUE, FALSE, FALSE, TRUE, FALSE, FALSE), 
           stratumId = c(1,1,1,2,2,2), 
           rowId = c(1,2,3,4,5,6),
           exposed = c(1,0,0,0,0,0))

## ----tidy=FALSE,eval=FALSE-----------------------------------------------
#  fit <- fitCaseControlModel(caseControlData,
#                             useCovariates = TRUE,
#                             caseControlsExposure = caseControlsExposure,
#                             prior = createPrior("none"))
#  
#  fit

## ----echo=FALSE,message=FALSE--------------------------------------------
if (file.exists("s:/temp/vignetteCaseControl")){
  fit <- readRDS("s:/temp/vignetteCaseControl/fit.rds")
  fit
}

## ----tidy=FALSE,eval=FALSE-----------------------------------------------
#  summary(fit)

## ----echo=FALSE,message=FALSE--------------------------------------------
if (file.exists("s:/temp/vignetteCaseControl")){
  summary(fit)
}

## ----tidy=FALSE,eval=FALSE-----------------------------------------------
#  coef(fit)

## ----echo=FALSE,message=FALSE--------------------------------------------
if (file.exists("s:/temp/vignetteCaseControl")){
  coef(fit)
}

## ----tidy=FALSE,eval=FALSE-----------------------------------------------
#  confint(fit)

## ----echo=FALSE,message=FALSE--------------------------------------------
if (file.exists("s:/temp/vignetteCaseControl")){
  confint(fit)
}

## ----tidy=TRUE,eval=TRUE-------------------------------------------------
citation("CaseControl")

## ----tidy=TRUE,eval=TRUE-------------------------------------------------
citation("Cyclops")

