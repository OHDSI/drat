# Ulysses 0.0.2

* Add keyring functions and update SetupKeyring.R template
* Update repository request email template
* Add git function to publish repo to remote
* Fix bugs in HowToRun and KeyringSetup template

# Ulysses 0.0.1

* Add initial functionality
    * file templates for:
        - Analysis script
        - Cohort Details
        - Contribution Guidelines
        - Example Script
        - How to run
        - Internal function file
        - Meeting minutes
        - News
        - Email templates
        - Readme
        - Results report
        - Study Protocol
        - Study SAP
        - Config.yml
    * initialize ohdsi study in R
* Added a `NEWS.md` file to track changes to the package.
