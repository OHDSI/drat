## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(Ulysses)

## ----initStudy, echo=TRUE, eval=FALSE-----------------------------------------
#  Ulysses::newOhdsiStudy(
#    path = here::here("my_ohdsi_study"),
#    author = "Ulysses S. Grant",
#    type = "Characterization",
#    directory = "[my_directory]",
#    open = TRUE
#  )

## ----readMeStart, echo=TRUE, eval=FALSE---------------------------------------
#  Ulysses::makeReadMe()

## ----newsStart, echo=TRUE, eval=FALSE-----------------------------------------
#  Ulysses::makeNews()

## ----configSetup, echo=TRUE, eval=FALSE---------------------------------------
#  Ulysses::makeConfig(block = "example", database = "synpuf_110k")

## ----keyringSetup, echo=TRUE, eval=FALSE--------------------------------------
#  Ulysses::makeKeyringSetup(configBlock = "example", database = "synpuf_110k")

## ----analysisScript, echo=TRUE, eval=FALSE------------------------------------
#  Ulysses::makeAnalysisScript(scriptName = "buildCohorts")

## ----internalScript, echo=TRUE, eval=FALSE------------------------------------
#  Ulysses::makeInternals(internalsName = "buildCohorts")

## ----doc1, echo=TRUE, eval=FALSE----------------------------------------------
#  Ulysses::makeOhdsiProtocol()
#  Ulysses::makePassProtocol()
#  Ulysses::makeStudySAP()

## ----doc2, echo=TRUE, eval=FALSE----------------------------------------------
#  Ulysses::makeHowToRun(org = "Ohdsi", repo = "my_ohdsi_study")

## ----doc3, echo=TRUE, eval=FALSE----------------------------------------------
#  Ulysses::makeContributionGuidelines()

