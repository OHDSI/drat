# {{{ Project }}} v0.0.1

* Initialize OHDSI study
* Add `NEWS.md` to track changes to OHDSI study
