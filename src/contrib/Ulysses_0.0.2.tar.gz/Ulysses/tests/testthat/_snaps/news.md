# make news works

    Code
      writeLines(read_utf8(proj_path("NEWS.md")))
    Output
      # test v0.0.1
      
      * Initialize OHDSI study
      * Add `NEWS.md` to track changes to OHDSI study

