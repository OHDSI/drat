EnsemblePatientLevelPrediction 1.0.1
======================
- Fixed Demo  

EnsemblePatientLevelPrediction 1.0.0
======================
- Updated for PatientLevelPrediction 6.0.0 

EnsemblePatientLevelPrediction 0.1.0
======================
- Updated for PatientLevelPrediction 5.4.0 that has splitSettings in ModelDesign

EnsemblePatientLevelPrediction 0.0.2
======================
- Added stacker ensemble code (currently only for logistic regression)
  
EnsemblePatientLevelPrediction 0.0.1
======================
- A new package that wraps around PatientLevelPrediction to create and evaluate ensemble models