CaseCrossover 2.0.0
===================

Changes:

1. Adhering to new CaseControl interface, supporting sampling of controls without matching.
