## ---- echo = FALSE, message = FALSE, warning = FALSE--------------------------
library(CaseCrossover)
knitr::opts_chunk$set(
  cache=FALSE,
  comment = "#>",
  error = FALSE,
  tidy = FALSE)

## ----tidy=TRUE,eval=FALSE-----------------------------------------------------
#  install.packages("drat")
#  drat::addRepo("OHDSI")
#  install.packages("CaseCrossover")

## ----tidy=FALSE,eval=FALSE----------------------------------------------------
#  connectionDetails <- createConnectionDetails(dbms = "postgresql",
#                                               server = "localhost/ohdsi",
#                                               user = "joe",
#                                               password = "supersecret")
#  
#  cdmDatabaseSchema <- "my_cdm_data"
#  cohortDatabaseSchema <- "my_results"
#  cohortTable <- "my_cohorts"
#  cdmVersion <- "5"

## ----tidy=FALSE,eval=FALSE----------------------------------------------------
#  library(SqlRender)
#  sql <- readSql("vignette.sql")
#  sql <- renderSql(sql,
#                   cdmDatabaseSchema = cdmDatabaseSchema,
#                   cohortDatabaseSchema = cohortDatabaseSchema
#                   cohortTable = cohortTable)$sql
#  sql <- translateSql(sql, targetDialect = connectionDetails$dbms)$sql
#  
#  connection <- connect(connectionDetails)
#  executeSql(connection, sql)

## ----tidy=FALSE,eval=FALSE----------------------------------------------------
#  sql <- paste("SELECT cohort_definition_id, COUNT(*) AS count",
#               "FROM @cohortDatabaseSchema.@cohortTable",
#               "GROUP BY cohort_definition_id")
#  sql <- renderSql(sql,
#                   cohortDatabaseSchema = cohortDatabaseSchema,
#                   cohortTable = cohortTable)$sql
#  sql <- translateSql(sql, targetDialect = connectionDetails$dbms)$sql
#  
#  querySql(connection, sql)

## ----echo=FALSE,message=FALSE-------------------------------------------------
data.frame(cohort_definition_id = c(1,2),count=c(422274, 118430))

## ----tidy=FALSE,eval=FALSE----------------------------------------------------
#  caseCrossoverData <- getDbCaseCrossoverData(connectionDetails = connectionDetails,
#                                              cdmDatabaseSchema = cdmDatabaseSchema,
#                                              oracleTempSchema = oracleTempSchema,
#                                              outcomeDatabaseSchema = cohortDatabaseSchema,
#                                              outcomeTable = cohortTable,
#                                              outcomeId = 1,
#                                              exposureDatabaseSchema = cdmDatabaseSchema,
#                                              exposureTable = "drug_era",
#                                              exposureIds = 1124300,
#                                              useNestingCohort = TRUE,
#                                              nestingCohortDatabaseSchema = cohortDatabaseSchema,
#                                              nestingCohortTable = cohortTable,
#                                              nestingCohortId = 2,
#                                              useObservationEndAsNestingEndDate = TRUE,
#                                              getTimeControlData = TRUE)
#  
#  
#  caseCrossoverData

## ----echo=FALSE,message=FALSE,eval=TRUE---------------------------------------
if (file.exists("s:/temp/vignetteCaseCrossover")){
  caseCrossoverData <- loadCaseCrossoverData("s:/temp/vignetteCaseCrossover/caseCrossoverData")
} 

## ----echo=FALSE,message=FALSE-------------------------------------------------
if (file.exists("s:/temp/vignetteCaseCrossover")){
  caseCrossoverData
}

## ----tidy=TRUE,eval=FALSE-----------------------------------------------------
#  summary(caseCrossoverData)

## ----echo=FALSE,message=FALSE-------------------------------------------------
if (file.exists("s:/temp/vignetteCaseCrossover")){
  summary(caseCrossoverData)
}

## ----tidy=TRUE,eval=FALSE-----------------------------------------------------
#  saveCaseCrossoverData(caseCrossoverData, "GiBleed")

## ----tidy=FALSE,eval=FALSE----------------------------------------------------
#  subjects <- selectSubjectsToInclude(caseCrossoverData = caseCrossoverData,
#                                      outcomeId = 1,
#                                      firstOutcomeOnly = TRUE,
#                                      washoutPeriod = 183)

## ----echo=TRUE,message=FALSE,eval=FALSE---------------------------------------
#  head(subjects)

## ----echo=FALSE,message=FALSE-------------------------------------------------
data.frame(personId = c(3,123,345,6,234,567),
           indexDate = c("2009-10-10", "2009-10-11", "2009-10-09", "2010-05-04", "2010-05-04", "2010-05-05"), 
           isCase = c(TRUE, TRUE, TRUE, TRUE, TRUE, TRUE), 
           stratumId = c(1,2,3,4,5,6),
           observationPeriodStartDate = c("2001-10-12", "2002-01-11", "2001-05-03", "2003-02-01", "2007-01-01", "2006-03-01"))

## ----tidy=FALSE,eval=FALSE----------------------------------------------------
#  getAttritionTable(subjects)

## ----echo=FALSE,message=FALSE,eval=TRUE---------------------------------------
if (file.exists("s:/temp/vignetteCaseCrossover")){
  subjects <- readRDS("s:/temp/vignetteCaseCrossover/subjects.rds")
} 

## ----echo=FALSE,message=FALSE-------------------------------------------------
if (file.exists("s:/temp/vignetteCaseCrossover")){
  getAttritionTable(subjects)
}

## ----tidy=FALSE,eval=FALSE----------------------------------------------------
#  exposureStatus <- getExposureStatus(subjects = subjects,
#                                      caseCrossoverData = caseCrossoverData,
#                                      exposureId = 1124300,
#                                      firstExposureOnly = FALSE,
#                                      riskWindowStart = -30,
#                                      riskWindowEnd = 0,
#                                      controlWindowOffsets = c(-60))

## ----echo=TRUE,message=FALSE,eval=FALSE---------------------------------------
#  head(exposureStatus)

## ----echo=FALSE,message=FALSE-------------------------------------------------
data.frame(personId = c(3,123,345,6,234,567),
           indexDate = c("2009-10-10", "2009-10-11", "2009-10-09", "2010-05-04", "2010-05-04", "2010-05-05"), 
           isCase = c(TRUE, TRUE, TRUE, TRUE, TRUE, TRUE), 
           stratumId = c(1,2,3,4,5,6),
           isCaseWindow = c(TRUE, TRUE, TRUE, TRUE, TRUE, TRUE), 
           exposed = c(0, 0, 0, 0, 0, 0))

## ----tidy=FALSE,eval=FALSE----------------------------------------------------
#  fit <- fitCaseCrossoverModel(exposureStatus)
#  
#  fit

## ----echo=FALSE,message=FALSE-------------------------------------------------
if (file.exists("s:/temp/vignetteCaseCrossover")){
  fit <- readRDS("s:/temp/vignetteCaseCrossover/fit.rds")
  fit
}

## ----tidy=FALSE,eval=FALSE----------------------------------------------------
#  summary(fit)

## ----echo=FALSE,message=FALSE-------------------------------------------------
if (file.exists("s:/temp/vignetteCaseCrossover")){
  fit <- readRDS("s:/temp/vignetteCaseCrossover/fit.rds")
  summary(fit)
}

## ----tidy=FALSE,eval=FALSE----------------------------------------------------
#  coef(fit)

## ----echo=FALSE,message=FALSE-------------------------------------------------
if (file.exists("s:/temp/vignetteCaseCrossover")){
  coef(fit)
}

## ----tidy=FALSE,eval=FALSE----------------------------------------------------
#  confint(fit)

## ----echo=FALSE,message=FALSE-------------------------------------------------
if (file.exists("s:/temp/vignetteCaseCrossover")){
  confint(fit)
}

## ----tidy=FALSE,eval=FALSE----------------------------------------------------
#  matchingCriteria <- createMatchingCriteria(controlsPerCase = 1,
#                                             matchOnAge = TRUE,
#                                             ageCaliper = 2,
#                                             matchOnGender = TRUE)
#  
#  subjectsCtc <- selectSubjectsToInclude(caseCrossoverData = caseCrossoverData,
#                                         outcomeId = 1,
#                                         firstOutcomeOnly = TRUE,
#                                         washoutPeriod = 183,
#                                         matchingCriteria = matchingCriteria)

## ----tidy=FALSE,eval=FALSE----------------------------------------------------
#  exposureStatusCtc <- getExposureStatus(subjects = subjectsCtc,
#                                         caseCrossoverData = caseCrossoverData,
#                                         exposureId = 1124300,
#                                         firstExposureOnly = FALSE,
#                                         riskWindowStart = -30,
#                                         riskWindowEnd = 0,
#                                         controlWindowOffsets = c(-60))
#  
#  fitCtc <- fitCaseCrossoverModel(exposureStatusCtc)
#  
#  summary(fitCtc)

## ----echo=FALSE,message=FALSE-------------------------------------------------
if (file.exists("s:/temp/vignetteCaseCrossover")){
  fitCtc <- readRDS("s:/temp/vignetteCaseCrossover/fitCtc.rds")
  summary(fitCtc)
}

## ----tidy=TRUE,eval=TRUE------------------------------------------------------
citation("CaseCrossover")

## ----tidy=TRUE,eval=TRUE------------------------------------------------------
citation("Cyclops")

