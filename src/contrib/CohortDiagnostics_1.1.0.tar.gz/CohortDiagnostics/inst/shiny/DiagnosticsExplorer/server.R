library(magrittr)

source("R/Plots.R")
source("R/Tables.R")

truncateStringDef <- function(columns, maxChars) {
  list(
    targets = columns,
    render = DT::JS(sprintf("function(data, type, row, meta) {\n
      return type === 'display' && data != null && data.length > %s ?\n
        '<span title=\"' + data + '\">' + data.substr(0, %s) + '...</span>' : data;\n
     }", maxChars, maxChars))
  )
}

minCellCountDef <- function(columns) {
  list(
    targets = columns,
    render = DT::JS("function(data, type) {
    if (type !== 'display' || isNaN(parseFloat(data))) return data;
    if (data >= 0) return data.toString().replace(/(\\d)(?=(\\d{3})+(?!\\d))/g, '$1,');
    return '<' + Math.abs(data).toString().replace(/(\\d)(?=(\\d{3})+(?!\\d))/g, '$1,');
  }")
  )
}

minCellPercentDef <- function(columns) {
  list(
    targets = columns,
    render = DT::JS("function(data, type) {
    if (type !== 'display' || isNaN(parseFloat(data))) return data;
    if (data >= 0) return (100 * data).toFixed(1).replace(/(\\d)(?=(\\d{3})+(?!\\d))/g, '$1,') + '%';
    return '<' + Math.abs(100 * data).toFixed(1).replace(/(\\d)(?=(\\d{3})+(?!\\d))/g, '$1,') + '%';
  }")
  )
}

minCellRealDef <- function(columns, digits = 1) {
  list(
    targets = columns,
    render = DT::JS(sprintf("function(data, type) {
    if (type !== 'display' || isNaN(parseFloat(data))) return data;
    if (data >= 0) return data.toFixed(%s).replace(/(\\d)(?=(\\d{3})+(?!\\d))/g, '$1,');
    return '<' + Math.abs(data).toFixed(%s).replace(/(\\d)(?=(\\d{3})+(?!\\d))/g, '$1,');
  }", digits, digits))
  )
}

styleAbsColorBar <- function(maxValue, colorPositive, colorNegative, angle = 90) {
  DT::JS(sprintf("isNaN(parseFloat(value))? '' : 'linear-gradient(%fdeg, transparent ' + (%f - Math.abs(value))/%f * 100 + '%%, ' + (value > 0 ? '%s ' : '%s ') + (%f - Math.abs(value))/%f * 100 + '%%)'", 
                 angle, maxValue, maxValue, colorPositive, colorNegative, maxValue, maxValue))
}

shiny::shinyServer(function(input, output, session) {
  
  cohortId <- shiny::reactive({
    return(cohort$cohortId[cohort$cohortFullName == input$cohort])
  })
  
  comparatorCohortId <- shiny::reactive({
    return(cohort$cohortId[cohort$cohortFullName == input$comparator])
  })
  
  timeId <- shiny::reactive({
    return(temporalCovariateChoices %>%
             dplyr::filter(choices %in% input$timeIdChoices) %>%
             dplyr::pull(timeId))
  })
  
  atlasBaseUrl <- shiny::reactive({
    return(input$atlasBaseUrl)
  })
  
  shiny::observe({
    subset <- unique(conceptSets$conceptSetName[conceptSets$cohortId == cohortId()])
    shinyWidgets::updatePickerInput(session = session,
                                    inputId = "conceptSet",
                                    choices = subset)
  })
  
  output$cohortCountsTable <- DT::renderDataTable({
    data <- cohortCount[cohortCount$databaseId %in% input$databases, ]
    if (nrow(data) == 0) {
      return(NULL)
    }
    databaseIds <- unique(data$databaseId)
    table <- data[data$databaseId == databaseIds[1], c("cohortId", "cohortEntries", "cohortSubjects")]
    colnames(table)[2:3] <- paste(colnames(table)[2:3], databaseIds[1], sep = "_")
    if (length(databaseIds) > 1) {
      for (i in 2:length(databaseIds)) {
        temp <- data[data$databaseId == databaseIds[i], c("cohortId", "cohortEntries", "cohortSubjects")]
        colnames(temp)[2:3] <- paste(colnames(temp)[2:3], databaseIds[i], sep = "_")
        table <- merge(table, temp, all = TRUE)
      }
    }
    table <- merge(cohort, table, all.x = TRUE)
    table$url <- paste0(atlasBaseUrl(), table$cohortId)
    table$cohortFullName <- paste0("<a href='", table$url, "' target='_blank'>", table$cohortFullName, "</a>")
    table$cohortId <- NULL
    table$cohortName <- NULL
    table$url <- NULL
    
    sketch <- htmltools::withTags(table(
      class = 'display',
      thead(
        tr(
          th(rowspan = 2, 'Cohort'),
          lapply(databaseIds, th, colspan = 2, class = "dt-center")
        ),
        tr(
          lapply(rep(c("Entries", "Subjects"), length(databaseIds)), th)
        )
      )
    ))
    
    options = list(pageLength = 20,
                   searching = TRUE,
                   lengthChange = TRUE,
                   ordering = TRUE,
                   paging = TRUE,
                   info = TRUE,
                   searchHighlight = TRUE,
                   scrollX = TRUE,
                   columnDefs = list(minCellCountDef(1:(2*length(databaseIds)))))
    
    dataTable <- DT::datatable(table,
                               options = options,
                               rownames = FALSE,
                               container = sketch, 
                               escape = FALSE,
                               filter = c("bottom"),
                               class = "stripe nowrap compact")
    for (i in 1:length(databaseIds)) {
      dataTable <- DT::formatStyle(table = dataTable,
                                   columns = i*2,
                                   background = DT::styleColorBar(c(0, max(table[, i*2], na.rm = TRUE)), "lightblue"),
                                   backgroundSize = "98% 88%",
                                   backgroundRepeat = "no-repeat",
                                   backgroundPosition = "center")
      dataTable <- DT::formatStyle(table = dataTable,
                                   columns = i*2 + 1,
                                   background = DT::styleColorBar(c(0, max(table[, i*2 + 1], na.rm = TRUE)), "#ffd699"),
                                   backgroundSize = "98% 88%",
                                   backgroundRepeat = "no-repeat",
                                   backgroundPosition = "center")
    }
    return(dataTable)
  })
  
  filteredIncidenceRates <- shiny::reactive({
    data <- incidenceRate[incidenceRate$cohortId == cohortId() & 
                            incidenceRate$databaseId %in% input$databases, ]
    data <- data[data$incidenceRate > 0, ]
    if (nrow(data) == 0) {
      return(NULL)
    }
    stratifyByAge <- "Age" %in% input$irStratification
    stratifyByGender <- "Gender" %in% input$irStratification
    stratifyByCalendarYear <- "Calendar Year" %in% input$irStratification
    minPersonYears = 1000
    
    idx <- rep(TRUE, nrow(data))
    if (stratifyByAge) {
      idx <- idx & !is.na(data$ageGroup)
    } else {
      idx <- idx & is.na(data$ageGroup)
    }
    if (stratifyByGender) {
      idx <- idx & !is.na(data$gender)
    } else {
      idx <- idx & is.na(data$gender)
    }
    if (stratifyByCalendarYear) {
      idx <- idx & !is.na(data$calendarYear)
    } else {
      idx <- idx & is.na(data$calendarYear)
    }
    data <- data[idx, ]
    data <- data[data$cohortCount > 0, ]
    data <- data[data$personYears > minPersonYears, ]
    data$gender <- as.factor(data$gender)
    data$calendarYear <- as.numeric(as.character(data$calendarYear))
    ageGroups <- unique(data$ageGroup)
    ageGroups <- ageGroups[order(as.numeric(gsub("-.*", "", ageGroups)))]
    data$ageGroup <- factor(data$ageGroup, levels = ageGroups)
    data <- data[data$incidenceRate > 0, ]
    data$dummy <- 0
    if (nrow(data) == 0) {
      return(NULL)
    } else {
      return(data)
    }
  })
  
  incidentRatePlotDownload <- shiny::reactive({
    data <- filteredIncidenceRates()
    if (is.null(data)) {
      return(NULL)
    }
    plot <- plotincidenceRate(data = data,
                              stratifyByAge = "Age" %in% input$irStratification,
                              stratifyByGender = "Gender" %in% input$irStratification,
                              stratifyByCalendarYear = "Calendar Year" %in% input$irStratification,
                              yscaleFixed = input$irYscaleFixed)
    return(plot)
  })
  
  output$incidenceRatePlot <- shiny::renderPlot({
    
    return(incidentRatePlotDownload())
  }, res = 100)
  
  output$hoverInfoIr <- shiny::renderUI({
    data <- filteredIncidenceRates()
    if (is.null(data)) {
      return(NULL)
    }else {
      hover <- input$plotHoverIr
      point <- nearPoints(data, hover, threshold = 5, maxpoints = 1, addDist = TRUE)
      if (nrow(point) == 0) {
        return(NULL)
      }
      left_px <- hover$coords_css$x
      top_px <- hover$coords_css$y
      
      text <- gsub("-", "<", sprintf("<b>Incidence rate: </b> %0.3f per 1,000 patient years", point$incidenceRate))
      text <- paste(text, sprintf("<b>Cohort count (numerator): </b> %s",  format(point$cohortCount, scientific = FALSE, big.mark = ",")), sep = "<br/>")
      text <- paste(text, sprintf("<b>Person time (denominator): </b> %s years", format(round(point$personYears), scientific = FALSE, big.mark = ",")), sep = "<br/>")
      text <- paste(text, "", sep = "<br/>")
      
      if (!is.na(point$ageGroup)) {
        text <- paste(text, sprintf("<b>Age group: </b> %s years", point$ageGroup), sep = "<br/>")
        top_px <- top_px - 15
      }
      if (!is.na(point$gender)) {
        text <- paste(text, sprintf("<b>Gender: </b> %s", point$gender), sep = "<br/>")
        top_px <- top_px - 15
      }
      if (!is.na(point$calendarYear)) {
        text <- paste(text, sprintf("<b>Calendar year: </b> %s", point$calendarYear), sep = "<br/>")
        top_px <- top_px - 15
      }
      text <- paste(text, sprintf("<b>Database: </b> %s", point$databaseId), sep = "<br/>")
      style <- paste0("position:absolute; z-index:100; background-color: rgba(245, 245, 245, 0.85); ",
                      "left:",
                      left_px - 200,
                      "px; top:",
                      top_px - 170,
                      "px; width:400px;")
      div(
        style = "position: relative; width: 0; height: 0",
        wellPanel(
          style = style,
          p(HTML(text))
        )
      )
    }
  }) 
  
  timeDisPlotDownload <- shiny::reactive({
    data <- timeDistribution[timeDistribution$cohortId == cohortId() & 
                               timeDistribution$databaseId %in% input$databases, ]
    if (nrow(data) == 0) {
      return(NULL)
    }
    data$x <- 1
    plot <- ggplot2::ggplot(data, ggplot2::aes(x = x,
                                               ymin = minValue,
                                               lower = p25Value,
                                               middle = medianValue,
                                               upper = p75Value,
                                               ymax = maxValue)) +
      ggplot2::geom_errorbar(ggplot2::aes(ymin = minValue, ymax = minValue), size = 1) +
      ggplot2::geom_errorbar(ggplot2::aes(ymin = maxValue, ymax = maxValue), size = 1) +
      ggplot2::geom_boxplot(stat = "identity", fill = rgb(0, 0, 0.8, alpha = 0.25), size = 1) +
      ggplot2::facet_grid(databaseId~timeMetric, scale = "free") +
      ggplot2::coord_flip() +
      ggplot2::theme(panel.grid.major.y = ggplot2::element_blank(),
                     panel.grid.minor.y = ggplot2::element_blank(),
                     axis.title.y = ggplot2::element_blank(),
                     axis.ticks.y = ggplot2::element_blank(),
                     axis.text.y = ggplot2::element_blank())
    return(plot)
    
  })
  
  output$timeDisPlot <- shiny::renderPlot({
    return(timeDisPlotDownload())
    
  }, res = 100)
  
  output$timeDistTable <- DT::renderDataTable({
    data <- timeDistribution[timeDistribution$cohortId == cohortId() & 
                               timeDistribution$databaseId %in% input$databases, ]
    if (nrow(data) == 0) {
      return(NULL)
    }
    columns <- c("timeMetric", "averageValue", "standardDeviation", "minValue", "p10Value", "p25Value", "medianValue", "p75Value", "p90Value", "maxValue")
    headers <- c("Time Measure", "Average", "SD", "Min", "P10", "P25", "Median", "P75", "P90", "Max")
    if (length(unique(data$databaseId)) > 1) {
      columns <- c("databaseId", columns)
      headers <- c("Database", headers)
    }
    table <- data[, columns]
    options = list(pageLength = 20,
                   searching = TRUE,
                   searchHighlight = TRUE,
                   scrollX = TRUE,
                   lengthChange = TRUE,
                   ordering = TRUE,
                   paging = TRUE,
                   info = TRUE)
    table <- DT::datatable(table,
                           options = options,
                           rownames = FALSE,
                           colnames = headers,
                           filter = c('bottom'),
                           class = "stripe nowrap compact")
    table <- DT::formatRound(table, c("averageValue", "standardDeviation"), digits = 2)
    table <- DT::formatRound(table, c("minValue", "p10Value", "p25Value", "medianValue", "p75Value", "p90Value", "maxValue"), digits = 0)
    return(table)
  })
  
  output$includedConceptsTable <- DT::renderDataTable({
    table <- includedSourceConcept[includedSourceConcept$cohortId == cohortId() &
                                     includedSourceConcept$conceptSetName == input$conceptSet & 
                                     includedSourceConcept$databaseId == input$database, ]
    if (input$includedType == "Source Concepts") {
      table <- table[, c("conceptSubjects", "sourceConceptId", "sourceVocabularyId", "conceptCode", "sourceConceptName")]
      table <- table[!is.na(table$sourceConceptName), ]
      table <- table[order(-table$conceptSubjects), ]
      colnames(table) <- c("Subjects", "Concept ID", "Vocabulary", "Code", "Name")
    } else {
      table$absConceptSubjects <- abs(table$conceptSubjects)
      table <- aggregate(absConceptSubjects ~ conceptId + conceptName, data = table, sum)
      table <- table[order(-table$absConceptSubjects), ]
      table <- table[, c("absConceptSubjects", "conceptId", "conceptName")]
      colnames(table) <- c("Subjects", "Concept ID", "Concept Name")
    }
    lims <- c(0, max(table$Subjects))
    options = list(pageLength = 20,
                   searching = TRUE,
                   searchHighlight = TRUE,
                   scrollX = TRUE,
                   lengthChange = TRUE,
                   ordering = TRUE,
                   paging = TRUE,
                   columnDefs = list(minCellCountDef(0)))
    table <- DT::datatable(table,
                           options = options,
                           rownames = FALSE,
                           escape = FALSE,
                           filter = c('bottom'),
                           class = "stripe nowrap compact")
    table <- DT::formatStyle(table = table,
                             columns = 1,
                             background = DT::styleColorBar(lims, "lightblue"),
                             backgroundSize = "98% 88%",
                             backgroundRepeat = "no-repeat",
                             backgroundPosition = "center")
    return(table)
  })
  
  output$orphanConceptsTable <- DT::renderDataTable({
    table <- orphanConcept[orphanConcept$cohortId == cohortId() &
                             orphanConcept$conceptSetName == input$conceptSet & 
                             orphanConcept$databaseId == input$database, ]
    if (nrow(table) == 0) {
      return(NULL)
    }
    table <- table[, c("conceptCount", "conceptId", "standardConcept", "vocabularyId", "conceptCode", "conceptName")]
    table <- table[order(-table$conceptCount), ]
    colnames(table) <- c("Count", "Concept ID", "Standard", "Vocabulary", "Code", "Name")
    lims <- c(0, max(table$Count))
    options = list(pageLength = 20,
                   searching = TRUE,
                   searchHighlight = TRUE,
                   scrollX = TRUE,
                   lengthChange = TRUE,
                   ordering = TRUE,
                   paging = TRUE,
                   columnDefs = list(minCellCountDef(0)))
    table <- DT::datatable(table,
                           options = options,
                           rownames = FALSE,
                           escape = FALSE,
                           filter = c('bottom'),
                           class = "stripe nowrap compact")
    table <- DT::formatStyle(table = table,
                             columns = 1,
                             background = DT::styleColorBar(lims, "lightblue"),
                             backgroundSize = "98% 88%",
                             backgroundRepeat = "no-repeat",
                             backgroundPosition = "center")
    return(table)
  })
  
  output$inclusionRuleTable <- DT::renderDataTable({
    table <- inclusionRuleStats[inclusionRuleStats$cohortId == cohortId() & inclusionRuleStats$databaseId == input$database, ]
    if (nrow(table) == 0) {
      return(NULL)
    }
    table <- table[order(table$ruleSequenceId), ]
    table$cohortId <- NULL
    table$databaseId <- NULL
    lims <- c(0, max(table$remainSubjects))
    table <- table[, c("ruleSequenceId", "ruleName", "meetSubjects", "gainSubjects", "totalSubjects", "remainSubjects")]
    colnames(table) <- c("Sequence", "Name", "Meet", "Gain", "Total", "Remain")
    options = list(pageLength = 20,
                   searching = TRUE,
                   searchHighlight = TRUE,
                   scrollX = TRUE,
                   lengthChange = TRUE,
                   ordering = TRUE,
                   paging = TRUE,
                   columnDefs = list(minCellCountDef(2:5)))
    table <- DT::datatable(table,
                           options = options,
                           rownames = FALSE,
                           escape = FALSE,
                           filter = c('bottom'),
                           class = "stripe nowrap compact")
    table <- DT::formatStyle(table = table,
                             columns = 6,
                             background = DT::styleColorBar(lims, "lightblue"),
                             backgroundSize = "98% 88%",
                             backgroundRepeat = "no-repeat",
                             backgroundPosition = "center")
    return(table)
  })
  
  output$breakdownTable <- DT::renderDataTable({
    data <- indexEventBreakdown[indexEventBreakdown$cohortId == cohortId() & 
                                  indexEventBreakdown$databaseId %in% input$databases, ]
    if (nrow(data) == 0) {
      return(NULL)
    }
    data <- data[, c("conceptId", "conceptName", "conceptCount", "databaseId" )]
    databaseIds <- unique(data$databaseId)
    table <- data[data$databaseId == databaseIds[1], ]
    table$databaseId <- NULL
    colnames(table)[3] <- paste(databaseIds[1], "Count")
    if (length(databaseIds) > 1) {
      for (i in 2:length(databaseIds)) {
        temp <- data[data$databaseId == databaseIds[i],]
        temp$databaseId <- NULL        
        colnames(temp)[3] <- paste(databaseIds[i], "Count")
        table <- merge(table, temp, all = TRUE)
      }
    }
    table <- table[order(-table[,3]), ]
    colnames(table)[1:2] <- c("Concept ID", "Name")
    options = list(pageLength = 20,
                   searching = TRUE,
                   searchHighlight = TRUE,
                   scrollX = TRUE,
                   lengthChange = TRUE,
                   ordering = TRUE,
                   paging = TRUE,
                   columnDefs = list(minCellCountDef(3:ncol(table) - 1)))
    dataTable <- DT::datatable(table,
                               options = options,
                               rownames = FALSE,
                               escape = FALSE,
                               filter = c('bottom'),
                               class = "stripe nowrap compact")
    for (col in 3:ncol(table)) {
      dataTable <- DT::formatStyle(table = dataTable,
                                   columns = col,
                                   background = DT::styleColorBar(c(0, max(table[, col], na.rm = TRUE)), "lightblue"),
                                   backgroundSize = "98% 88%",
                                   backgroundRepeat = "no-repeat",
                                   backgroundPosition = "center")
    }
    return(dataTable)
  })
  
  output$characterizationTable <- DT::renderDataTable({
    data <- covariateValue %>% 
      dplyr::filter(.data$cohortId == cohortId() & 
                      .data$databaseId %in% input$databases) %>% 
      dplyr::select(-cohortId)
    databaseIds <- data %>% 
      dplyr::select(databaseId) %>% 
      dplyr::distinct() %>% 
      dplyr::arrange(databaseId) %>% 
      dplyr::pull(databaseId)
    
    if (input$charType == "Pretty") {
      data <- data %>% 
        dplyr::left_join(y = covariate, by = c('covariateId')) %>% 
        dplyr::distinct()
      table <- list()
      for (j in (1:length(databaseIds))) {
        temp <- data %>% 
          dplyr::filter(.data$databaseId == databaseIds[[j]]) %>% 
          prepareTable1() %>% 
          dplyr::mutate(databaseId = databaseIds[[j]])
        table[[j]] <- temp
      }
      table <- dplyr::bind_rows(table) %>% 
        tidyr::pivot_wider(id_cols = 'characteristic', 
                           names_from = "databaseId",
                           values_from = "value" ,
                           names_sep = "_",
                           values_fill = 0,
                           names_prefix = "Value_"
        )
      options = list(pageLength = 999,
                     searching = FALSE,
                     scrollX = TRUE,
                     lengthChange = FALSE,
                     ordering = FALSE,
                     paging = FALSE,
                     columnDefs = list(
                       truncateStringDef(0, 150),
                       minCellPercentDef(1:length(databaseIds))
                     ))
      sketch <- htmltools::withTags(table(
        class = 'display',
        thead(
          tr(
            th(rowspan = 2, 'Covariate Name'),
            lapply(databaseIds, th, colspan = 1, class = "dt-center")
          ),
          tr(
            lapply(rep(c("Proportion"), length(databaseIds)), th)
          )
        )
      ))
      table <- DT::datatable(table,
                             options = options,
                             rownames = FALSE,
                             container = sketch, 
                             escape = FALSE,
                             filter = c('bottom'),
                             class = "stripe nowrap compact")
      
      table <- DT::formatStyle(table = table,
                               columns = 1 + (1:length(databaseIds)),
                               background = DT::styleColorBar(c(0,1), "lightblue"),
                               backgroundSize = "98% 88%",
                               backgroundRepeat = "no-repeat",
                               backgroundPosition = "center")
    } else {
      table <- data %>% 
        dplyr::select(.data$covariateId) %>% 
        dplyr::distinct()
      for (i in (1:length(databaseIds))) {
        temp <- data %>% 
          dplyr::filter(databaseId == databaseIds[[i]]) %>% 
          dplyr::select(.data$covariateId, .data$mean, .data$sd)
        table <- table %>%
          dplyr::left_join(temp, by = "covariateId") %>% 
          dplyr::mutate(dplyr::across(tidyr::everything(), ~tidyr::replace_na(data = .x, replace = 0)))
      }
      table <- covariate %>% 
        dplyr::distinct() %>% 
        dplyr::left_join(y = table, by = c("covariateId")) %>%
        dplyr::select(-.data$covariateAnalysisId, 
                      -.data$covariateId) %>% 
        dplyr::arrange(.data$covariateName) %>% 
        dplyr::distinct()
      
      options = list(pageLength = 20,
                     searching = TRUE,
                     searchHighlight = TRUE,
                     scrollX = TRUE,
                     lengthChange = TRUE,
                     ordering = TRUE,
                     paging = TRUE,
                     columnDefs = list(
                       truncateStringDef(0, 150),
                       minCellRealDef((1:(2*length(databaseIds))) + 1)
                     )
      )
      sketch <- htmltools::withTags(table(
        class = 'display',
        thead(
          tr(
            th(rowspan = 2, 'Covariate Name'),
            th(rowspan = 2, 'Concept Id'),
            lapply(databaseIds, th, colspan = 2, class = "dt-center")
          ),
          tr(
            lapply(rep(c("Mean", "SD"), length(databaseIds)), th)
          )
        )
      ))
      table <- DT::datatable(table,
                             options = options,
                             rownames = FALSE,
                             container = sketch, 
                             escape = FALSE,
                             filter = c('bottom'),
                             class = "stripe nowrap compact")
      table <- DT::formatStyle(table = table,
                               columns = (2*(1:length(databaseIds))) + 1,
                               background = DT::styleColorBar(c(0,1), "lightblue"),
                               backgroundSize = "98% 88%",
                               backgroundRepeat = "no-repeat",
                               backgroundPosition = "center")
    }
    return(table)
  })
  
  output$temporalCharacterizationTable <- DT::renderDataTable({
    data <- temporalCovariateValue %>% 
      dplyr::filter(.data$cohortId == cohortId(),
                    .data$databaseId == input$database,
                    .data$timeId %in% c(timeId())) %>% 
      dplyr::select(-cohortId)
    
    temporalCovariateChoicesSelected <- temporalCovariateChoices %>% 
                                        dplyr::filter(.data$timeId %in% c(timeId()))
    
    data <- data %>% 
      dplyr::left_join(y = temporalCovariate %>% dplyr::distinct(), by = c("covariateId", "timeId")) %>% 
      dplyr::mutate(conceptId = (.data$covariateId - .data$covariateAnalysisId)/1000) %>% 
      dplyr::select(.data$covariateId, .data$covariateName,.data$conceptId, .data$timeId, .data$mean, .data$sd) %>% 
      dplyr::distinct()
    
    table <- data %>% 
              dplyr::select(.data$covariateName,.data$conceptId, .data$covariateId) %>% 
              dplyr::distinct()
    
    for (timeId in temporalCovariateChoicesSelected$timeId) {
      temp <- data %>% 
              dplyr::filter(timeId == !!timeId) %>% 
              dplyr::select(.data$covariateId, .data$mean, .data$sd)
      table <- table %>% 
                dplyr::left_join(temp, by = c("covariateId")) %>% 
                dplyr::mutate(dplyr::across(tidyr::everything(), ~tidyr::replace_na(data = .x, replace = 0)))
    }
    table <- table %>% 
            dplyr::select(-.data$covariateId) %>% 
            dplyr::arrange(.data$covariateName)
    
    options = list(pageLength = 20,
                   searching = TRUE,
                   searchHighlight = TRUE,
                   scrollX = TRUE,
                   lengthChange = TRUE,
                   ordering = TRUE,
                   paging = TRUE,
                   columnDefs = list(
                     truncateStringDef(0, 150),
                     minCellRealDef((1:(2*length(temporalCovariateChoicesSelected$choices))) + 1)
                   )
    )
    sketch <- htmltools::withTags(table(
      class = 'display',
      thead(
        tr(
          th(rowspan = 2, 'Covariate Name'),
          th(rowspan = 2, 'Concept Id'),
          lapply(temporalCovariateChoicesSelected$choices, th, colspan = 2, class = "dt-center")
        ),
        tr(
          lapply(rep(c("Mean", "SD"), length(temporalCovariateChoicesSelected$choices)), th)
        )
      )
    ))
    table <- DT::datatable(table,
                           options = options,
                           rownames = FALSE,
                           container = sketch,
                           escape = FALSE,
                           filter = c('bottom'),
                           class = "stripe nowrap compact")
    table <- DT::formatStyle(table = table,
                             columns = (2*(1:length(temporalCovariateChoicesSelected$choices)) + 1), #0 index
                             background = DT::styleColorBar(c(0,1), "lightblue"),
                             backgroundSize = "98% 88%",
                             backgroundRepeat = "no-repeat",
                             backgroundPosition = "center")
    return(table)
  })
  
  output$overlapTable <- DT::renderDataTable({
    data <- cohortOverlap[cohortOverlap$targetCohortId == cohortId() & 
                            cohortOverlap$comparatorCohortId == comparatorCohortId() &
                            cohortOverlap$databaseId == input$database, ]
    if (nrow(data) == 0) {
      return(NULL)
    }
    
    table <- data.frame(row.names = c("Subject in either cohort",
                                      "Subject in both cohort",
                                      "Subject in target not in comparator",
                                      "Subject in comparator not in target",
                                      "Subject in target before comparator",
                                      "Subject in comparator before target",
                                      "Subject in target and comparator on same day"),
                        Value = c(data$eitherSubjects,
                                  data$bothSubjects,
                                  data$tOnlySubjects,
                                  data$cOnlySubjects,
                                  data$tBeforeCSubjects,
                                  data$cBeforeTSubjects,
                                  data$sameDaySubjects))
    if (!is.null(data$tInCSubjects)) {
      table <- rbind(table,
                     data.frame(row.names = c("Subject having target start during comparator",
                                              "Subject having comparator start during target"),
                                Value = c(data$tInCSubjects,
                                          data$cInTSubjects)))
    }
    table$Value[is.na(table$Value)] <- 0
    options = list(pageLength = 7,
                   searching = FALSE,
                   scrollX = TRUE,
                   lengthChange = FALSE,
                   ordering = FALSE,
                   paging = FALSE,
                   info = FALSE,
                   columnDefs = list(minCellCountDef(1)))
    table <- DT::datatable(table,
                           options = options,
                           rownames = TRUE,
                           filter = c('bottom'),
                           class = "stripe nowrap compact")
    return(table)
  })
  
  overLapPlot <- shiny::reactive({
    data <- cohortOverlap[cohortOverlap$targetCohortId == cohortId() & 
                            cohortOverlap$comparatorCohortId == comparatorCohortId() &
                            cohortOverlap$databaseId == input$database, ]
    if (nrow(data) == 0) {
      return(NULL)
    }
    plot <- VennDiagram::draw.pairwise.venn(area1 = abs(data$eitherSubjects) - abs(data$cOnlySubjects),
                                            area2 = abs(data$eitherSubjects) - abs(data$tOnlySubjects),
                                            cross.area = abs(data$bothSubjects),
                                            category = c("Target", "Comparator"), 
                                            col = c(rgb(0.8, 0, 0), rgb(0, 0, 0.8)),
                                            fill = c(rgb(0.8, 0, 0), rgb(0, 0, 0.8)),
                                            alpha = 0.2,
                                            fontfamily = rep("sans", 3),
                                            cat.fontfamily = rep("sans", 2),
                                            margin = 0.01,
                                            ind = FALSE)
    # Borrowed from https://stackoverflow.com/questions/37239128/how-to-put-comma-in-large-number-of-venndiagram
    idx <- sapply(plot, function(i) grepl("text", i$name))
    for (i in 1:3) {
      plot[idx][[i]]$label <- format(as.numeric(plot[idx][[i]]$label), big.mark = ",", scientific = FALSE)
    }
    grid::grid.draw(plot)
    
    return(plot)
  })
  
  output$overlapPlot <- shiny::renderPlot({
    return(overLapPlot())
  }, res = 100)
  
  computeBalance <- shiny::reactive({
    if (cohortId() == comparatorCohortId()) {
      return(tidyr::tibble())
    }
    covs1 <- covariateValue %>% 
      dplyr::filter(.data$cohortId == cohortId(),
                    .data$databaseId == input$database)
    covs2 <- covariateValue %>% 
      dplyr::filter(.data$cohortId == comparatorCohortId(),
                    .data$databaseId == input$database)
    covs1 <- dplyr::left_join(x = covs1, y = covariate)
    covs2 <- dplyr::left_join(x = covs2, y = covariate)
    balance <- compareCohortCharacteristics(covs1, covs2) %>%
      dplyr::mutate(absStdDiff = abs(.data$stdDiff))
    return(balance)
  })
  
  output$charCompareTable <- DT::renderDataTable({
    balance <- computeBalance()
    if (nrow(balance) == 0) {
      return(NULL)
    }
    
    if (input$charCompareType == "Pretty table") {
      table <- prepareTable1Comp(balance) %>% 
        dplyr::arrange(sortOrder) %>% 
        dplyr::select(-.data$sortOrder)
      
      options = list(pageLength = 999,
                     searching = FALSE,
                     scrollX = TRUE,
                     lengthChange = FALSE,
                     ordering = FALSE,
                     paging = FALSE,
                     columnDefs = list(minCellPercentDef(1:2))
      )
      table <- DT::datatable(table,
                             options = options,
                             rownames = FALSE,
                             escape = FALSE,
                             filter = c('bottom'),
                             class = "stripe nowrap compact")
      table <- DT::formatStyle(table = table,
                               columns = 2:3,
                               background = DT::styleColorBar(c(0,1), "lightblue"),
                               backgroundSize = "98% 88%",
                               backgroundRepeat = "no-repeat",
                               backgroundPosition = "center")
      table <- DT::formatStyle(table = table,
                               columns = 4,
                               background = styleAbsColorBar(1, "lightblue", "pink"),
                               backgroundSize = "98% 88%",
                               backgroundRepeat = "no-repeat",
                               backgroundPosition = "center")
      table <- DT::formatRound(table, 4, digits = 2)
    } else {
      table <- balance %>% 
        dplyr::arrange(.data$covariateName) %>% 
        dplyr::select(.data$covariateName, .data$conceptId, .data$mean1, .data$sd1, .data$mean2, .data$sd2, .data$stdDiff) %>% 
        dplyr::mutate(stdDiff = round(x = .data$stdDiff, digits = 3)) %>% 
        dplyr::rename_with(.fn = ~ stringr::str_replace(string = ., pattern = '1', replacement = 'Target')) %>% 
        dplyr::rename_with(.fn = ~ stringr::str_replace(string = ., pattern = '2', replacement = 'Comparator')) %>% 
        dplyr::rename_with(.fn = SqlRender::camelCaseToTitleCase)
      
      options = list(pageLength = 20,
                     searching = TRUE,
                     searchHighlight = TRUE,
                     scrollX = TRUE,
                     lengthChange = TRUE,
                     ordering = TRUE,
                     paging = TRUE,
                     columnDefs = list(
                       truncateStringDef(0, 150),
                       minCellRealDef(c(1,3), 2)
                     )
      )
      table <- DT::datatable(table,
                             options = options,
                             rownames = FALSE,
                             escape = FALSE,
                             filter = c('bottom'),
                             class = "stripe nowrap compact")
      table <- DT::formatStyle(table = table,
                               columns = c(2,4),
                               background = DT::styleColorBar(c(0,1), "lightblue"),
                               backgroundSize = "98% 88%",
                               backgroundRepeat = "no-repeat",
                               backgroundPosition = "center")
      table <- DT::formatStyle(table = table,
                               columns = 6,
                               background = styleAbsColorBar(1, "lightblue", "pink"),
                               backgroundSize = "98% 88%",
                               backgroundRepeat = "no-repeat",
                               backgroundPosition = "center")
      table <- DT::formatRound(table, c(3, 5, 6), digits = 2)
    }
    return(table)
  })
  
  downloadCohortComparePlot <- shiny::reactive({
    balance <- computeBalance()
    if (nrow(balance) == 0) {
      return(NULL)
    }
    balance$mean1[is.na(balance$mean1)] <- 0
    balance$mean2[is.na(balance$mean2)] <- 0
    plot <- ggplot2::ggplot(balance, ggplot2::aes(x = mean1, y = mean2, color = absStdDiff)) +
      ggplot2::geom_point(alpha = 0.3, shape = 16, size = 2) +
      ggplot2::geom_abline(slope = 1, intercept = 0, linetype = "dashed") +
      ggplot2::geom_hline(yintercept = 0) +
      ggplot2::geom_vline(xintercept = 0) +             
      ggplot2::scale_x_continuous("Mean Target", limits = c(0, 1)) +
      ggplot2::scale_y_continuous("Mean Comparator", limits = c(0, 1)) +
      ggplot2::scale_color_gradient("Absolute\nStd. Diff.", low = "blue", high = "red", space = "Lab", na.value = "red")
    return(plot)
  })
  
  output$charComparePlot <- shiny::renderPlot({
    return(downloadCohortComparePlot())
  }, res = 100)
  
  output$hoverInfoCharComparePlot <- shiny::renderUI({
    balance <- computeBalance()
    balance$mean1[is.na(balance$mean1)] <- 0
    balance$mean2[is.na(balance$mean2)] <- 0
    if (nrow(balance) == 0) {
      return(NULL)
    } else {
      hover <- input$plotHoverCharCompare
      point <- nearPoints(balance, hover, threshold = 5, maxpoints = 1, addDist = TRUE)
      if (nrow(point) == 0) {
        return(NULL)
      }
      text <- paste(point$covariateName, 
                    "",
                    sprintf("<b>Mean Target: </b> %0.2f", point$mean1),
                    sprintf("<b>Mean Comparator: </b> %0.2f", point$mean2), 
                    sprintf("<b>Std diff.: </b> %0.2f", point$stdDiff), 
                    sep = "<br/>")
      left_px <- hover$coords_css$x
      top_px <- hover$coords_css$y
      if (hover$x > 0.5) {
        xOffset <- -505
      } else {
        xOffset <- 5
      }
      style <- paste0("position:absolute; z-index:100; background-color: rgba(245, 245, 245, 0.85); ",
                      "left:",
                      left_px + xOffset,
                      "px; top:",
                      top_px - 150,
                      "px; width:500px;")
      div(
        style = "position: relative; width: 0; height: 0",
        wellPanel(
          style = style,
          p(HTML(text))
        )
      )
    }
  }) 
  
  # output$databaseInformationPanel <- renderUI({
  #   row <- database[database$databaseId == input$database, ]
  #   text <- div(tags$p(tags$h3("ID"), wellPanel(row$databaseId)),
  #               tags$p(tags$h3("Name"), wellPanel(row$databaseName)),
  #               tags$p(tags$h3("Description"), wellPanel(row$description)))
  #   return(text)
  # })
  
  output$databaseInformationTable <- DT::renderDataTable({
    
    table <- database[, c("databaseId", "databaseName", "description")]
    options = list(pageLength = 20,
                   searching = TRUE,
                   lengthChange = FALSE,
                   ordering = TRUE,
                   paging = FALSE,
                   columnDefs = list(list(width = '30%', targets = 1),
                                     list(width = '60%', targets = 2))
    )
    table <- DT::datatable(table,
                           options = options,
                           colnames = c("ID", "Name", "Description"),
                           rownames = FALSE,
                           class = "stripe compact")
    return(table)
  })
  
  showInfoBox <- function(title, htmlFileName) {
    shiny::showModal(shiny::modalDialog(
      title = title,
      easyClose = TRUE,
      footer = NULL,
      size = "l",
      HTML(readChar(htmlFileName, file.info(htmlFileName)$size) )
    ))
  }
  
  shiny::observeEvent(input$cohortCountsInfo, {
    showInfoBox("Cohort Counts", "html/cohortCounts.html")
  })
  
  shiny::observeEvent(input$incidenceRateInfo, {
    showInfoBox("Incidence Rate", "html/incidenceRate.html")
  })
  
  shiny::observeEvent(input$timeDistributionInfo, {
    showInfoBox("Time Distributions", "html/timeDistribution.html")
  })
  
  shiny::observeEvent(input$includedConceptsInfo, {
    showInfoBox("Included (Source) Concepts", "html/includedConcepts.html")
  })
  
  shiny::observeEvent(input$orphanConceptsInfo, {
    showInfoBox("Orphan (Source) Concepts", "html/orphanConcepts.html")
  })
  
  shiny::observeEvent(input$inclusionRuleStatsInfo, {
    showInfoBox("Inclusion Rule Statistics", "html/inclusionRuleStats.html")
  })
  
  shiny::observeEvent(input$indexEventBreakdownInfo, {
    showInfoBox("Index Event Breakdown", "html/indexEventBreakdown.html")
  })
  
  shiny::observeEvent(input$cohortCharacterizationInfo, {
    showInfoBox("Cohort Characterization", "html/cohortCharacterization.html")
  })
  
  shiny::observeEvent(input$temporalCharacterizationInfo, {
    showInfoBox("Temporal Characterization", "html/temporalCharacterization.html")
  })
  
  shiny::observeEvent(input$cohortOverlapInfo, {
    showInfoBox("Cohort Overlap", "html/cohortOverlap.html")
  })
  
  shiny::observeEvent(input$compareCohortCharacterizationInfo, {
    showInfoBox("Compare Cohort Characteristics", "html/compareCohortCharacterization.html")
  })
  
  output$incidenceRateSelectedCohort <- shiny::renderText(input$cohort)
  output$timeDistributionSelectedCohort <- shiny::renderText(input$cohort)
  output$sourceConceptsSelectedCohort <- shiny::renderText(input$cohort)
  output$orphanConceptsSelectedCohort <- shiny::renderText(input$cohort)
  output$inclusionRuleStatsSelectedCohort <- shiny::renderText(input$cohort)
  output$indexEventBreakdownSelectedCohort <- shiny::renderText(input$cohort)
  output$cohortCharacterizationSelectedCohort <- shiny::renderText(input$cohort)
  output$temporalCharacterizationSelectedCohort <- shiny::renderText(input$cohort)
  output$cohortOverlapSelectedCohort <- shiny::renderText(input$cohort)
  output$cohortOverlapComparatorCohort <- shiny::renderText(input$comparator)
  output$compareCohortCharacterizationSelectedCohort <- shiny::renderText(input$cohort)
  output$compareCohortCharacterizationSelectedComparator <- shiny::renderText(input$comparator)
  output$temporalCharacterizationSelectedDataBase <- shiny::renderText(input$database)
  
  
  #Download
  download_box <- function(exportname, plot){
    downloadHandler(
      filename = function() {
        paste(exportname, Sys.Date(), ".png", sep = "")
      },
      content = function(file) {
        ggplot2::ggsave(file, plot = plot, device = "png", width = 9, height = 7, dpi = 400)
      }
    )
  }
  
  output$downloadIncidentRatePlot <- download_box("IncidentRate", incidentRatePlotDownload())
  output$timeDistributionPlot <- download_box("TimeDistribution", timeDisPlotDownload())
  output$downloadCompareCohortPlot <- download_box("CompareCohort", downloadCohortComparePlot())
  output$downloadOverlapPlot <- download_box("OverlapPlot", overLapPlot())
  
})