Cohort Incidence 1.0.0
===========

Initial Release Including:

1. Java implementation 
2. Standard object model for defining cohort incidence design.
3. Test cases

