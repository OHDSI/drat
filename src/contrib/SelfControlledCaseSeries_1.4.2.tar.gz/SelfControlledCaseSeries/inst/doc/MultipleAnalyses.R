## ---- echo = FALSE, message = FALSE, warning = FALSE--------------------------
library(SelfControlledCaseSeries)
knitr::opts_chunk$set(
  cache = FALSE,
  comment = "#>",
  error = FALSE,
  tidy = FALSE)

## ----tidy=FALSE,eval=TRUE-----------------------------------------------------
connectionDetails <- createConnectionDetails(dbms = "postgresql", 
                                             server = "localhost/ohdsi", 
                                             user = "joe", 
                                             password = "supersecret")

outputFolder <- "s:/temp/sccsVignette2"

cdmDatabaseSchema <- "my_cdm_data"
cohortDatabaseSchema <- "my_cohorts"
cdmVersion <- "5"

## ----tidy=FALSE,eval=FALSE----------------------------------------------------
#  library(SqlRender)
#  sql <- readSql("vignette.sql")
#  sql <- render(sql,
#                cdmDatabaseSchema = cdmDatabaseSchema,
#                cohortDatabaseSchema = cohortDatabaseSchema)
#  sql <- translate(sql, targetDialect = connectionDetails$dbms)
#  
#  connection <- connect(connectionDetails)
#  executeSql(connection, sql)

## ----tidy=FALSE,eval=FALSE----------------------------------------------------
#  negativeControls <- c(705178, 705944, 710650, 714785, 719174, 719311, 735340, 742185,
#                        780369, 781182, 924724, 990760, 1110942, 1111706, 1136601,
#                        1317967, 1501309, 1505346, 1551673, 1560278, 1584910, 19010309,
#                        40163731)
#  diclofenac <- 1124300
#  ppis <- c(911735, 929887, 923645, 904453, 948078, 19039926)
#  
#  exposureOutcomeList <- list()
#  for (exposureId in c(diclofenac, negativeControls)){
#    exposureOutcome <- createExposureOutcome(exposureId = exposureId,
#                                             outcomeId = 1,
#                                             prophylactics = ppis)
#    exposureOutcomeList[[length(exposureOutcomeList) + 1]] <- exposureOutcome
#  }

## ----tidy=FALSE,eval=TRUE-----------------------------------------------------
getDbSccsDataArgs1 <- createGetDbSccsDataArgs(useCustomCovariates = FALSE,
                                              deleteCovariatesSmallCount = 100,
                                              studyStartDate = "",
                                              studyEndDate = "",
                                              exposureIds = c())

covarEoi <- createCovariateSettings(label = "Exposure of interest",
                                              includeCovariateIds = "exposureId",
                                              start = 0,
                                              end = 0,
                                              addExposedDaysToEnd = TRUE)

createEraDataArgs1 <- createCreateSccsEraDataArgs(naivePeriod = 180,
                                                  firstOutcomeOnly = FALSE,
                                                  covariateSettings = covarEoi)

fitSccsModelArgs <- createFitSccsModelArgs()

## ----tidy=FALSE,eval=TRUE-----------------------------------------------------
sccsAnalysis1 <- createSccsAnalysis(analysisId = 1,
                                    description = "Simplest model",
                                    getDbSccsDataArgs = getDbSccsDataArgs1,
                                    createSccsEraDataArgs = createEraDataArgs1,
                                    fitSccsModelArgs = fitSccsModelArgs)

## ----tidy=FALSE,eval=TRUE-----------------------------------------------------
covarProp <- createCovariateSettings(label = "Prophylactics",
                                              includeCovariateIds = "prophylactics",
                                              start = 0,
                                              end = 0,
                                              addExposedDaysToEnd = TRUE)

createSccsEraDataArgs2 <- createCreateSccsEraDataArgs(naivePeriod = 180,
                                                      firstOutcomeOnly = FALSE,
                                                      covariateSettings = list(covarEoi,
                                                                               covarProp))

sccsAnalysis2 <- createSccsAnalysis(analysisId = 2,
                                    description = "Including prophylactics",
                                    getDbSccsDataArgs = getDbSccsDataArgs1,
                                    createSccsEraDataArgs = createSccsEraDataArgs2,
                                    fitSccsModelArgs = fitSccsModelArgs)

ageSettings <- createAgeSettings(includeAge = TRUE, ageKnots = 5)

seasonSettings <- createSeasonalitySettings(includeSeasonality = TRUE, seasonKnots = 5)

covarPreExp <- createCovariateSettings(label = "Pre-exposure",
                                       includeCovariateIds = "exposureId",
                                       start = -30,
                                       end = -1)

createSccsEraDataArgs3 <- createCreateSccsEraDataArgs(naivePeriod = 180,
                                                      firstOutcomeOnly = FALSE,
                                                      covariateSettings = list(covarEoi,
                                                                               covarPreExp,
                                                                               covarProp),
                                                      ageSettings = ageSettings,
                                                      seasonalitySettings = seasonSettings,
                                                      eventDependentObservation = TRUE)

sccsAnalysis3 <- createSccsAnalysis(analysisId = 3,
                                    description = "Inc. prop., age, season, pre-exp., censor.",
                                    getDbSccsDataArgs = getDbSccsDataArgs1,
                                    createSccsEraDataArgs = createSccsEraDataArgs3,
                                    fitSccsModelArgs = fitSccsModelArgs)

covarAllDrugs <- createCovariateSettings(label = "Other exposures",
                                         excludeCovariateIds = "exposureId",
                                         stratifyById = TRUE,
                                         start = 1,
                                         end = 0,
                                         addExposedDaysToEnd = TRUE,
                                         allowRegularization = TRUE)

createSccsEraDataArgs4 <- createCreateSccsEraDataArgs(naivePeriod = 180,
                                                      firstOutcomeOnly = FALSE,
                                                      covariateSettings = list(covarEoi,
                                                                               covarPreExp,
                                                                               covarAllDrugs),
                                                      ageSettings = ageSettings,
                                                      seasonalitySettings = seasonSettings,
                                                      eventDependentObservation = TRUE)

sccsAnalysis4 <- createSccsAnalysis(analysisId = 4,
                                    description = "Including all other drugs",
                                    getDbSccsDataArgs = getDbSccsDataArgs1,
                                    createSccsEraDataArgs = createSccsEraDataArgs4,
                                    fitSccsModelArgs = fitSccsModelArgs)

## ----tidy=FALSE,eval=TRUE-----------------------------------------------------
sccsAnalysisList <- list(sccsAnalysis1, sccsAnalysis2, sccsAnalysis3, sccsAnalysis4)

## ----tidy=FALSE,eval=TRUE-----------------------------------------------------
outcomeIds = list(narrowDefinition = 1,
                  broadDefinition = 2)

exposureOutcome <- createExposureOutcome(exposureId = 1124300,
                                         outcomeId = outcomeIds)

## ----tidy=FALSE,eval=TRUE-----------------------------------------------------
sccsAnalysisA <- createSccsAnalysis(analysisId = 1,
                                    description = "Simplest model, using narrow def.",
                                    outcomeType = "narrowDefinition",
                                    getDbSccsDataArgs = getDbSccsDataArgs1,
                                    createSccsEraDataArgs = createEraDataArgs1,
                                    fitSccsModelArgs = fitSccsModelArgs)

sccsAnalysisB <- createSccsAnalysis(analysisId = 2,
                                    description = "Simplest model, using broad def.",
                                    outcomeType = "broadDefinition",
                                    getDbSccsDataArgs = getDbSccsDataArgs1,
                                    createSccsEraDataArgs = createEraDataArgs1,
                                    fitSccsModelArgs = fitSccsModelArgs)

sccsAnalysisList2 <- list(sccsAnalysisA, sccsAnalysisB)

## ----tidy=FALSE,eval=FALSE----------------------------------------------------
#  result <- runSccsAnalyses(connectionDetails = connectionDetails,
#                            cdmDatabaseSchema = cdmDatabaseSchema,
#                            oracleTempSchema = cdmDatabaseSchema,
#                            exposureDatabaseSchema = cdmDatabaseSchema,
#                            exposureTable = "drug_era",
#                            outcomeDatabaseSchema = cohortDatabaseSchema,
#                            outcomeTable = outcomeTable,
#                            cdmVersion = cdmVersion,
#                            outputFolder = outputFolder,
#                            combineDataFetchAcrossOutcomes = TRUE,
#                            exposureOutcomeList = exposureOutcomeList,
#                            sccsAnalysisList = sccsAnalysisList,
#                            getDbSccsDataThreads = 1,
#                            createSccsEraDataThreads = 5,
#                            fitSccsModelThreads = 3,
#                            cvThreads = 10)

## ----tidy=FALSE,eval=FALSE----------------------------------------------------
#  sccsModelFile <- result$sccsModelFile[result$exposureId == 1124300 &
#                                        result$outcomeId == 1 &
#                                        result$analysisId == 1]
#  sccsModel <- readRDS(file.path(outputFolder, sccsModelFile))
#  summary(sccsModel)

## ----echo=FALSE,message=FALSE-------------------------------------------------
if (file.exists(file.path(outputFolder, "outcomeModelReference.rds"))) {
  result <- readRDS(file.path(outputFolder, "outcomeModelReference.rds"))
  sccsModelFile <- result$sccsModelFile[result$exposureId == 1124300 & 
                                          result$outcomeId == 1 &
                                          result$analysisId == 1]
  sccsModel <- readRDS(file.path(outputFolder, sccsModelFile))
  summary(sccsModel)
}

## ----tidy=FALSE,eval=FALSE----------------------------------------------------
#  analysisSum <- summarizeSccsAnalyses(result, outputFolder)
#  head(analysisSum)

## ----echo=FALSE,message=FALSE-------------------------------------------------
if (file.exists(file.path(outputFolder, "outcomeModelReference.rds"))) {
  analysisSum <- readRDS(file.path(outputFolder, "analysisSummary.rds"))
  head(analysisSum)
}

## ----tidy=FALSE,eval=FALSE----------------------------------------------------
#  install.packages("EmpiricalCalibration")
#  library(EmpiricalCalibration)
#  
#  # Analysis 1: Simplest model
#  negCons <- analysisSum[analysisSum$analysisId == 1 & analysisSum$exposureId != 1124300, ]
#  ei <-  analysisSum[analysisSum$analysisId == 1 & analysisSum$exposureId == 1124300, ]
#  null <- fitNull(negCons$`logRr(Exposure of interest)`,
#                  negCons$`seLogRr(Exposure of interest)`)
#  plotCalibrationEffect(logRrNegatives = negCons$`logRr(Exposure of interest)`,
#                        seLogRrNegatives = negCons$`seLogRr(Exposure of interest)`,
#                        logRrPositives = ei$`logRr(Exposure of interest)`,
#                        seLogRrPositives = ei$`seLogRr(Exposure of interest)`,
#                        null)

## ----echo=FALSE,message=FALSE,eval=TRUE---------------------------------------
if (file.exists(file.path(outputFolder, "outcomeModelReference.rds"))) {
  library(EmpiricalCalibration)
  negCons <- analysisSum[analysisSum$analysisId == 1 & analysisSum$exposureId != 1124300, ]
  ei <-  analysisSum[analysisSum$analysisId == 1 & analysisSum$exposureId == 1124300, ]
  null <- fitNull(negCons$`logRr(Exposure of interest)`, 
                  negCons$`seLogRr(Exposure of interest)`)
  plotCalibrationEffect(logRrNegatives = negCons$`logRr(Exposure of interest)`, 
                        seLogRrNegatives = negCons$`seLogRr(Exposure of interest)`, 
                        logRrPositives = ei$`logRr(Exposure of interest)`, 
                        seLogRrPositives = ei$`seLogRr(Exposure of interest)`, 
                        null)
}

## ----tidy=FALSE,eval=FALSE----------------------------------------------------
#  # Analysis 2: Including prophylactics
#  negCons <- analysisSum[analysisSum$analysisId == 2 & analysisSum$exposureId != 1124300, ]
#  ei <-  analysisSum[analysisSum$analysisId == 2 & analysisSum$exposureId == 1124300, ]
#  null <- fitNull(negCons$`logRr(Exposure of interest)`,
#                  negCons$`seLogRr(Exposure of interest)`)
#  plotCalibrationEffect(logRrNegatives = negCons$`logRr(Exposure of interest)`,
#                        seLogRrNegatives = negCons$`seLogRr(Exposure of interest)`,
#                        logRrPositives = ei$`logRr(Exposure of interest)`,
#                        seLogRrPositives = ei$`seLogRr(Exposure of interest)`,
#                        null)

## ----echo=FALSE,message=FALSE,eval=TRUE---------------------------------------
if (file.exists(file.path(outputFolder, "outcomeModelReference.rds"))) {
  negCons <- analysisSum[analysisSum$analysisId == 2 & analysisSum$exposureId != 1124300, ]
  ei <-  analysisSum[analysisSum$analysisId == 2 & analysisSum$exposureId == 1124300, ]
  null <- fitNull(negCons$`logRr(Exposure of interest)`, 
                  negCons$`seLogRr(Exposure of interest)`)
  plotCalibrationEffect(logRrNegatives = negCons$`logRr(Exposure of interest)`, 
                        seLogRrNegatives = negCons$`seLogRr(Exposure of interest)`, 
                        logRrPositives = ei$`logRr(Exposure of interest)`, 
                        seLogRrPositives = ei$`seLogRr(Exposure of interest)`, 
                        null)
}

## ----tidy=FALSE,eval=FALSE----------------------------------------------------
#  # Analysis 3: Including prophylactics, age, season, pre-exposure, and censoring
#  negCons <- analysisSum[analysisSum$analysisId == 3 & analysisSum$exposureId != 1124300, ]
#  ei <-  analysisSum[analysisSum$analysisId == 3 & analysisSum$exposureId == 1124300, ]
#  null <- fitNull(negCons$`logRr(Exposure of interest)`,
#                  negCons$`seLogRr(Exposure of interest)`)
#  plotCalibrationEffect(logRrNegatives = negCons$`logRr(Exposure of interest)`,
#                        seLogRrNegatives = negCons$`seLogRr(Exposure of interest)`,
#                        logRrPositives = ei$`logRr(Exposure of interest)`,
#                        seLogRrPositives = ei$`seLogRr(Exposure of interest)`,
#                        null)

## ----echo=FALSE,message=FALSE,eval=TRUE---------------------------------------
if (file.exists(file.path(outputFolder, "outcomeModelReference.rds"))) {
  negCons <- analysisSum[analysisSum$analysisId == 3 & analysisSum$exposureId != 1124300, ]
  ei <-  analysisSum[analysisSum$analysisId == 3 & analysisSum$exposureId == 1124300, ]
  null <- fitNull(negCons$`logRr(Exposure of interest)`, 
                  negCons$`seLogRr(Exposure of interest)`)
  plotCalibrationEffect(logRrNegatives = negCons$`logRr(Exposure of interest)`, 
                        seLogRrNegatives = negCons$`seLogRr(Exposure of interest)`, 
                        logRrPositives = ei$`logRr(Exposure of interest)`, 
                        seLogRrPositives = ei$`seLogRr(Exposure of interest)`, 
                        null)
}

## ----tidy=FALSE,eval=FALSE----------------------------------------------------
#  # Analysis 4: Including all other drugs (as well as prophylactics, age, season, pre-
#  # exposure, and censoring)
#  negCons <- analysisSum[analysisSum$analysisId == 4 & analysisSum$exposureId != 1124300, ]
#  ei <-  analysisSum[analysisSum$analysisId == 4 & analysisSum$exposureId == 1124300, ]
#  null <- fitNull(negCons$`logRr(Exposure of interest)`,
#                  negCons$`seLogRr(Exposure of interest)`)
#  plotCalibrationEffect(logRrNegatives = negCons$`logRr(Exposure of interest)`,
#                        seLogRrNegatives = negCons$`seLogRr(Exposure of interest)`,
#                        logRrPositives = ei$`logRr(Exposure of interest)`,
#                        seLogRrPositives = ei$`seLogRr(Exposure of interest)`,
#                        null)

## ----echo=FALSE,message=FALSE,eval=TRUE---------------------------------------
if (file.exists(file.path(outputFolder, "outcomeModelReference.rds"))) {
  negCons <- analysisSum[analysisSum$analysisId == 4 & analysisSum$exposureId != 1124300, ]
  ei <-  analysisSum[analysisSum$analysisId == 4 & analysisSum$exposureId == 1124300, ]
  null <- fitNull(negCons$`logRr(Exposure of interest)`, 
                  negCons$`seLogRr(Exposure of interest)`)
  plotCalibrationEffect(logRrNegatives = negCons$`logRr(Exposure of interest)`, 
                        seLogRrNegatives = negCons$`seLogRr(Exposure of interest)`, 
                        logRrPositives = ei$`logRr(Exposure of interest)`, 
                        seLogRrPositives = ei$`seLogRr(Exposure of interest)`, 
                        null)
}

## ----tidy=TRUE,eval=TRUE------------------------------------------------------
citation("SelfControlledCaseSeries")

## ----tidy=TRUE,eval=TRUE------------------------------------------------------
citation("Cyclops")

