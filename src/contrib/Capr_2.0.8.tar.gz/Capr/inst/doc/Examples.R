## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  eval = FALSE # for now...
)


## ----setup--------------------------------------------------------------------
#  
#  library(Capr)
#  
#  # Function to test that cohort compiles
#  assertCohortCompiles <- function(cohortDefinition) {
#    sql <- CirceR::cohortExpressionFromJson(as.json(ch))
#    sql <- CirceR::buildCohortQuery(sql, options = CirceR::createGenerateOptions(generateStats = TRUE))
#  
#    stopifnot(nchar(sql) > 1)
#    invisible(NULL)
#  }
#  

## ----include=FALSE, eval=FALSE------------------------------------------------
#  
#  # DRAFT version that uses observationPeriod Query type
#  # TODO implement observation period Query type
#  cs1 <- cs(descendants(443238, 201820, 442793),
#            descendants(exclude(195771, 201254, 435216, 761051, 4058243, 40484648)),
#            name = "Type 2 diabetes mellitus (diabetes mellitus excluding T1DM and secondary)")
#  
#  ch <- cohort(
#    entry = conditionOccurrence(cs1),
#    attrition = attrition(
#      withAll(
#            atLeast(1,
#              observationPeriod(), #function not currently in Capr
#              duringInterval(eventStarts(-Inf, -365, "startDate"))
#      )
#      )
#    ),
#    exit = exit(
#      endStrategy = observationExit()
#    )
#  )

## ----eval=FALSE---------------------------------------------------------------
#  library(Capr)
#  
#  cs0 <- cs(descendants(443238, 201820, 442793),
#            descendants(exclude(195771, 201254, 435216, 761051, 4058243, 40484648)),
#            name = "Type 2 diabetes mellitus (diabetes mellitus excluding T1DM and secondary)")
#  
#  ch <- cohort(
#    entry = entry(
#      conditionOccurrence(cs0),
#      observationWindow = continuousObservation(priorDays = 365)
#    ),
#    exit = exit(
#      endStrategy = observationExit()
#    )
#  )
#  

## ----include=FALSE------------------------------------------------------------
#  assertCohortCompiles(ch)

## ----eval=FALSE---------------------------------------------------------------
#  library(Capr)
#  
#  cs0 <- cs(descendants(443238, 201820, 442793),
#            descendants(exclude(195771, 201254, 435216, 761051, 4058243, 40484648)),
#            name = "Type 2 diabetes mellitus (diabetes mellitus excluding T1DM and secondary)")
#  
#  cs1 <- cs(descendants(201254, 435216, 40484648),
#            name = "Type 1 diabetes mellitus")
#  
#  cs2 <- cs(descendants(195771),
#            name = "Secondary diabetes mellitus")
#  
#  ch <- cohort(
#    entry = entry(
#      conditionOccurrence(cs0),
#      observationWindow = continuousObservation(priorDays = 365)
#    ),
#    attrition = attrition(
#      't1d' = withAll(
#      exactly(0, conditionOccurrence(cs1), duringInterval(eventStarts(-Inf, 0)))
#      ),
#      'secondaryDiabetes' = withAll(
#      exactly(0, conditionOccurrence(cs2), duringInterval(eventStarts(-Inf, 0)))
#      )
#    ),
#    exit = exit(
#      endStrategy = observationExit()
#    )
#  )
#  

## ----include=FALSE------------------------------------------------------------
#  assertCohortCompiles(ch)

## ----eval=FALSE---------------------------------------------------------------
#  library(Capr)
#  
#  cs0 <- cs(descendants(443238, 201820, 442793),
#            descendants(exclude(195771, 201254, 435216, 761051, 4058243, 40484648)),
#            name = "Type 2 diabetes mellitus (diabetes mellitus excluding T1DM and secondary)")
#  
#  cs1 <- cs(descendants(201254, 435216, 40484648),
#            name = "Type 1 diabetes mellitus")
#  
#  cs2 <- cs(descendants(195771),
#            name = "Secondary diabetes mellitus")
#  
#  cs3 <- cs(descendants(4184637, 37059902),
#            name = "Hemoglobin A1c (HbA1c) measurements")
#  
#  cs4 <- cs(descendants(21600744),
#            name = "Drugs for diabetes except insulin")
#  
#  
#  ch <- cohort(
#    entry = entry(
#      conditionOccurrence(cs0),
#      drugExposure(cs4),
#      measurement(cs3, valueAsNumber(bt(6.5, 30)), unit("%")),
#      measurement(cs3, valueAsNumber(bt(48, 99)), unit("mmol/mol")),
#      observationWindow = continuousObservation(priorDays = 365)
#    ),
#    attrition = attrition(
#      'no T1D' = withAll(
#        exactly(0, conditionOccurrence(cs1), duringInterval(eventStarts(-Inf, 0)))
#        ),
#      'no secondary diabettes' = withAll(
#        exactly(0, conditionOccurrence(cs2), duringInterval(eventStarts(-Inf, 0)))
#      )
#    ),
#    exit = exit(
#      endStrategy = observationExit()
#    )
#  )
#  

## ----include=FALSE------------------------------------------------------------
#  assertCohortCompiles(ch)

## -----------------------------------------------------------------------------
#  cs0 <- cs(descendants(195771),
#            name = "Type 1 diabetes mellitus")
#  
#  ch <- cohort(
#    entry = entry(
#      conditionOccurrence(cs0),
#      observationWindow = continuousObservation(priorDays = 365)
#    )
#  )
#  

## -----------------------------------------------------------------------------
#  assertCohortCompiles(ch)

## -----------------------------------------------------------------------------
#  
#  cs0 <- cs(descendants(443238, 201820, 442793),
#            descendants(exclude(195771, 201254, 435216, 761051, 4058243, 40484648)),
#            name = "Type 2 diabetes mellitus (diabetes mellitus excluding T1DM and secondary)")
#  
#  cs1 <- cs(descendants(201254, 435216, 40484648),
#            name = "Type 1 diabetes mellitus")
#  
#  cs2 <- cs(descendants(195771),
#            name = "Secondary diabetes mellitus")
#  
#  ch <- cohort(
#    entry = entry(
#      conditionOccurrence(cs1),
#      observationWindow = continuousObservation(priorDays = 365)
#    ),
#    attrition = attrition(
#      "no prior T2DM" = withAll(exactly(0, conditionOccurrence(cs0), duringInterval(eventStarts(-Inf, 0)))),
#      "no prior secondary T1DM" = withAll(exactly(0, conditionOccurrence(cs2), duringInterval(eventStarts(-Inf, 0))))
#    )
#  )
#  

## ----include=FALSE------------------------------------------------------------
#  assertCohortCompiles(ch)

## -----------------------------------------------------------------------------
#  
#  cs0 <- cs(descendants(313217),
#            name = "Atrial fibrillation")
#  
#  ch <- cohort(conditionOccurrence(cs0))
#  

## ----include=FALSE------------------------------------------------------------
#  assertCohortCompiles(ch)

## -----------------------------------------------------------------------------
#  
#  afib <- cs(descendants(313217),
#             name = "Atrial fibrillation")
#  
#  ip <- cs(descendants(262, 9201),
#           name = "Inpatient or inpatient ER visit")
#  
#  op <- cs(descendants(9202, 9203),
#           name = "Outpatient or ER visit")
#  
#  ch <- cohort(
#    entry = entry(
#      conditionOccurrence(afib,
#        nestedWithAny(
#          atLeast(1, visit(ip), duringInterval(eventStarts(-Inf, 0), eventEnds(0, Inf))),
#          nestedWithAll(
#            atLeast(1, visit(op, duringInterval(eventStarts(-Inf, 0), eventEnds(0, Inf)),
#              nestedWithAll(
#                atLeast(1, conditionOccurrence(afib, duringInterval(eventStarts(7, 365)),
#                  nestedWithAll(
#                    atLeast(1, visit(op, duringInterval(eventStarts(-Inf, 0), eventEnds(0, Inf))))
#                  )
#                ))
#              )
#            ))
#          )
#        )
#      )
#    )
#  )
#  

## ----include=FALSE, eval=FALSE------------------------------------------------
#  # not compiling
#  assertCohortCompiles(ch)

