## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  eval = FALSE
)

## ----setup, echo=FALSE--------------------------------------------------------
#  library(Capr)

## ----templateFn---------------------------------------------------------------
#  cvEvents <- function(conceptSet) {
#    cd <- cohort(
#      entry = entry(
#        conditionOccurrence(conceptSet),
#        observationWindow = continuousObservation(365, 0)
#      ),
#      exit = exit(
#        endStrategy = observationExit()
#      )
#    )
#    return(cd)
#  }

## ----conceptSets--------------------------------------------------------------
#  afib <- cs(descendants(313217), name = "Atrial Fibrillation")
#  stroke <- cs(descendants(4310996), name = "Ischemic Stroke")
#  hyp <- cs(descendants(320128), name = "Hypertension")
#  mi <- cs(descendants(4329847), name = "Myocardial Infarction")
#  hf <- cs(descendants(316139), name = "Heart Failure")

## ----listOfCohorts------------------------------------------------------------
#  cvSet <- list(afib, stroke, hyp, mi, hf)
#  cvCohorts <- purrr::map(cvSet, ~cvEvents(.x))

## ----templateFn2, eval=FALSE--------------------------------------------------
#  cvEvents2 <- function(conceptSet) {
#  
#    #Capr template logic
#    cd <- cohort(
#      entry = entry(
#        conditionOccurrence(conceptSet),
#        observationWindow = continuousObservation(365, 0)
#      ),
#      exit = exit(
#        endStrategy = observationExit()
#      )
#    )
#  
#    #coerce cohort to json
#    cohortJson <- cd %>%
#      toCirce() %>%
#      jsonlite::toJSON(pretty = TRUE, auto_unbox = TRUE) %>%
#      as.character()
#  
#    return(cohortJson)
#  }

## ----templateFn3--------------------------------------------------------------
#  cvEvents3 <- function(file) {
#  
#    # get file name
#    name <- tools::file_path_sans_ext(basename(file))
#  
#    #retreive concept set
#    conceptSet <- Capr::readConceptSet(path = file, name = name)
#  
#    #Capr template logic
#    cd <- cohort(
#      entry = entry(
#        conditionOccurrence(conceptSet),
#        observationWindow = continuousObservation(365, 0)
#      ),
#      exit = exit(
#        endStrategy = observationExit()
#      )
#    )
#  
#    #coerce cohort to json
#    cohortJson <- cd %>%
#      toCirce() %>%
#      jsonlite::toJSON(pretty = TRUE, auto_unbox = TRUE) %>%
#      as.character()
#  
#    return(cohortJson)
#  }

## ----importCs-----------------------------------------------------------------
#  miPath <- fs::path_package("Capr", "extdata/acuteMI.csv")
#  miCohort <- cvEvents3(miPath)
#  cat(miCohort)

## ----saveSingleCohort, eval=FALSE---------------------------------------------
#  
#  outputPath <- fs::path(here::here("cohorts"), "miCohort", ext = "json")
#  readr::write_file(miCohort, file = outputPath)
#  

