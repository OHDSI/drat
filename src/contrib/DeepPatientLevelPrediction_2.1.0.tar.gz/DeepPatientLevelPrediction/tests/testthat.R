library(testthat)
library(DeepPatientLevelPrediction)

test_check("DeepPatientLevelPrediction")
