## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)

## ----message=FALSE, eval=FALSE------------------------------------------------
#  library(DeepPatientLevelPrediction)
#  
#  # Get connection details for the Eunomia dataset and create the cohorts
#  connectionDetails <- Eunomia::getEunomiaConnectionDetails()
#  Eunomia::createCohorts(connectionDetails)

## ----message=FALSE, eval=FALSE------------------------------------------------
#  # create some simple covariate settings using Sex, Age and Long-term conditions and drug use in the last year.
#  covariateSettings <- FeatureExtraction::createCovariateSettings(
#    useDemographicsGender = TRUE,
#    useDemographicsAge = TRUE,
#    useConditionOccurrenceLongTerm = TRUE,
#    useDrugEraLongTerm = TRUE,
#    endDays = 0
#  )
#  
#  # Information about the database. In Eunomia sqlite there is only one schema, main and the cohorts are in a table named `cohort` which is the default.
#  databaseDetails <- PatientLevelPrediction::createDatabaseDetails(
#    connectionDetails = connectionDetails,
#    cdmDatabaseId = "2", # Eunomia version used
#    cdmDatabaseSchema = "main",
#    targetId = 4,
#    outcomeIds = 3,
#    cdmDatabaseName = "eunomia"
#  )
#  
#  # Let's now extract the plpData object from the database
#  plpData <- PatientLevelPrediction::getPlpData(
#    databaseDetails = databaseDetails,
#    covariateSettings = covariateSettings,
#    restrictPlpDataSettings = PatientLevelPrediction::createRestrictPlpDataSettings()
#  )
#  

## ----message=FALSE, eval=FALSE------------------------------------------------
#  modelSettings <- setResNet(numLayers = c(2),
#                             sizeHidden = 128,
#                             hiddenFactor = 1,
#                             residualDropout = 0.1,
#                             hiddenDropout = 0.1,
#                             sizeEmbedding = 128,
#                             estimatorSettings = setEstimator(
#                               learningRate = 3e-4,
#                               weightDecay = 0,
#                               device = "cpu", # use cuda here if you have a gpu
#                               batchSize = 256,
#                               epochs = 5,
#                               seed = 42
#                             ),
#                             hyperParamSearch = "random",
#                             randomSample = 1)
#  
#  plpResults <- PatientLevelPrediction::runPlp(
#    plpData = plpData,
#    outcomeId = 3, # 4 is the id of GiBleed
#    modelSettings = modelSettings,
#    analysisName = "Nsaids_GiBleed",
#    analysisId = "1",
#    # Let's predict the risk of Gibleed in the year following start of NSAIDs use
#    populationSettings = PatientLevelPrediction::createStudyPopulationSettings(
#      requireTimeAtRisk = FALSE,
#      firstExposureOnly = TRUE,
#      riskWindowStart = 1,
#      riskWindowEnd = 365
#    ),
#    splitSettings = PatientLevelPrediction::createDefaultSplitSetting(splitSeed = 42),
#    saveDirectory = "./output" # save in a folder in the current directory
#  )
#  

## ----message=FALSE, eval=FALSE------------------------------------------------
#  databaseDetails <- PatientLevelPrediction::createDatabaseDetails(
#    connectionDetails = connectionDetails,
#    cdmDatabaseId = "2", # Eunomia version used
#    cdmDatabaseSchema = "main",
#    targetId = 2, # diclofenac cohort
#    outcomeIds = 3,
#    cdmDatabaseName = "eunomia"
#  )
#  
#  plpDataTransfer <- PatientLevelPrediction::getPlpData(
#    databaseDetails = databaseDetails,
#    covariateSettings = covariateSettings, # same as for the developed model
#    restrictPlpDataSettings = PatientLevelPrediction::createRestrictPlpDataSettings()
#  )
#  

## ----message=FALSE, eval=FALSE------------------------------------------------
#  modelSettingsTransfer <- setFinetuner(modelPath = './output/1/plpResult/model',
#                                        estimatorSettings = setEstimator(
#                                          learningRate = 3e-4,
#                                          weightDecay = 0,
#                                          device = "cpu", # use cuda here if you have a gpu
#                                          batchSize = 256,
#                                          epochs = 5,
#                                          seed = 42
#                                        ))
#  

## ----message=FALSE, eval=FALSE------------------------------------------------
#  plpResultsTransfer <- PatientLevelPrediction::runPlp(
#    plpData = plpDataTransfer,
#    outcomeId = 3,
#    modelSettings = modelSettingsTransfer,
#    analysisName = "Diclofenac_GiBleed",
#    analysisId = "2",
#    populationSettings = PatientLevelPrediction::createStudyPopulationSettings(
#      requireTimeAtRisk = FALSE,
#      firstExposureOnly = TRUE,
#      riskWindowStart = 1,
#      riskWindowEnd = 365
#    ),
#    splitSettings = PatientLevelPrediction::createDefaultSplitSetting(splitSeed = 42),
#    saveDirectory = "./outputTransfer" # save in a folder in the current directory
#  )

## ----tidy=TRUE,eval=TRUE------------------------------------------------------
citation("DeepPatientLevelPrediction")

