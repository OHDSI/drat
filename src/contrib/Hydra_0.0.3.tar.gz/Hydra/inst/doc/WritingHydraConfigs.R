## ----eval=FALSE, echo=TRUE-----------------------------------------------
#  doFooBar(
#    # Start fooBar
#    foo = "Bye",
#    bar = NULL
#    # End fooBar
#  )

## ----eval=FALSE, echo=TRUE-----------------------------------------------
#  doFooBar(
#    foo = "Hello",
#    bar = createBar(x = 123,
#                    y = 456)
#  )
#  

