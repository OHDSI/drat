structure(list(url = "http://atlas-dev.ohdsi.org/WebAPI/pathway-analysis/999999/generation/SYNPUF5PCT", 
    status_code = 500L, headers = structure(list(vary = "Accept-Encoding", 
        `content-encoding` = "gzip", `content-type` = "application/json", 
        `content-length` = "202", date = "Sun, 18 Jul 2021 21:19:46 GMT", 
        connection = "close"), class = c("insensitive", "list"
    )), all_headers = list(list(status = 500L, version = "HTTP/1.1", 
        headers = structure(list(vary = "Accept-Encoding", `content-encoding` = "gzip", 
            `content-type` = "application/json", `content-length` = "202", 
            date = "Sun, 18 Jul 2021 21:19:46 GMT", connection = "close"), class = c("insensitive", 
        "list")))), cookies = structure(list(domain = logical(0), 
        flag = logical(0), path = logical(0), secure = logical(0), 
        expiration = structure(numeric(0), class = c("POSIXct", 
        "POSIXt")), name = logical(0), value = logical(0)), row.names = integer(0), class = "data.frame"), 
    content = charToRaw("{\"payload\":{\"cause\":null,\"stackTrace\":[],\"message\":\"An exception occurred: java.lang.NullPointerException\",\"localizedMessage\":\"An exception occurred: java.lang.NullPointerException\",\"suppressed\":[]},\"headers\":{\"id\":\"b408daa3-8c4c-8e7d-396f-a5c0b0e86718\",\"timestamp\":1626643186993}}"), 
    date = structure(1626643186, class = c("POSIXct", "POSIXt"
    ), tzone = "GMT"), times = c(redirect = 0, namelookup = 7.2e-05, 
    connect = 7.4e-05, pretransfer = 0.000166, starttransfer = 0.084332, 
    total = 0.08438)), class = "response")
