IterativeHardThresholding 1.0.0
=============

Changes: initial HADES version
