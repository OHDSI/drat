library(testthat)
library(IterativeHardThresholding)

test_check("IterativeHardThresholding")
