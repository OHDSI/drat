diagExpEnv$dashboardUi(diagExpEnv$enabledTabs,
                       diagExpEnv$enableAnnotation,
                       diagExpEnv$showAnnotation,
                       diagExpEnv$enableAuthorization,
                       diagExpEnv$appVersionNum)
