## ----include=FALSE------------------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)

## ----eval = FALSE-------------------------------------------------------------
#  exampleViewer <- function(id) {
#    ns <- shiny::NS(id)
#  
#    shiny::fluidRow(
#  
#      shiny::column(width = 12,
#  
#                    shinydashboard::box(
#                      width = 12,
#                      title = "Example Title ",
#                      status = "info",
#                      solidHeader = TRUE,
#                      DT::dataTableOutput(ns('serverReference'))
#                    )
#      )
#    )
#  }

## ----eval = FALSE-------------------------------------------------------------
#  exampleServer <- function(
#    id,
#    extraInput
#    ) {
#    shiny::moduleServer(
#      id,
#      function(input, output, session) {
#  
#        output$serverReference <- data.frame(a=1:5, b=1:5)
#  
#      }
#    )
#  }

## ----eval = FALSE-------------------------------------------------------------
#  ui <- shiny::fluidPage(
#    exampleViewer("exampleName")
#  )
#  server <- function(input, output, session) {
#    exampleServer("exampleName")
#  }
#  shiny::shinyApp(ui, server)

## ----eval = FALSE-------------------------------------------------------------
#  test_that("Example Test", {
#    shiny::testServer(exampleModuleServer, args = list(id = "testModule"), {
#  
#      # session$setInputs allows simulation of user behaviour
#      session$setInputs(
#        testString = "foo"
#      )
#  
#      # after modifying input output can be verified
#      expect_equal(myReactive(), "Input is foo")
#      expect_equal(output$testOutput, "Input is foo")
#  
#    })
#  
#  })
#  

## ----eval = FALSE-------------------------------------------------------------
#  # setup.R
#  connectionDetails <- DatabaseConnector::createConnectionDetails(
#    dbms = 'sqlite',
#    server = 'testDb.sqlite'
#    )

## ----eval = FALSE-------------------------------------------------------------
#  testthat::test_dir('<path_to_package>/tests')

