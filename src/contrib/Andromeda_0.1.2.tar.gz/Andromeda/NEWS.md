Andromeda 0.1.2
===============

Changes

- Adding fast isSorted function.

- Changes in documentation for CRAN.


Andromeda 0.1.1
===============

Changes

- Minor edits to documentation in preparation for submission to CRAN.

- Changing compression level when saving: 10-fold reduction in compression time at the cost of 10% larger file size.

- Increasing batch size from 10,000 to 100,000 to increase speed.

- Turning of SQLIte journal to increase speed.


Andromeda 0.1.0
===============

Initial version.