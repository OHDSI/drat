library(testthat)
library(SelfControlledCohort)

test_check("SelfControlledCohort")
