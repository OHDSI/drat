## ----echo = TRUE, message = FALSE, warning = FALSE, tidy = FALSE, eval=FALSE----
#  remotes::install_github('ohdsi/PhenotypeLibrary')

## ----echo = TRUE, message = FALSE, warning = FALSE, tidy = FALSE, eval = FALSE----
#  PhenotypeLibrary::getPlCohortDefinitionSet(1165)

## ----echo = TRUE, message = FALSE, warning = FALSE, tidy = FALSE, eval = FALSE----
#  phenotypeDefinitions <- PhenotypeLibrary::getPlCohortDefinitionSet(1152:1215)

