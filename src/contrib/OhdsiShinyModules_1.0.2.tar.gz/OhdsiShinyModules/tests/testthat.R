library(testthat)
library(OhdsiShinyModules)
test_check("OhdsiShinyModules")
#unlink('T:/Temp', recursive = T)
