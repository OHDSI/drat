library(testthat)
library(FeatureExtraction)
options(dbms = "sql server")
test_check("FeatureExtraction")
