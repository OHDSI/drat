PheValuator 2.0.0
=================

Changes:

1. Major overhaul of the code base and functions, aimed at improving stability, consistency with other OHSDI packages, and usability.
