## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup, echo=FALSE--------------------------------------------------------
library(Capr)

## ----queryTable, echo=FALSE---------------------------------------------------
tb <- tibble::tribble(
  ~`OMOP Domain`, ~`Capr Function`,
  "DrugExposure", "drugExposure",
  "DrugEra", "drugEra",
  "ConditionOccurrence", "conditionOccurrence",
  "ConditionEra", "conditionEra",
  "ProcedureOccurrence", "procedure",
  "Measurement", "measurement",
  "VisitOccurrence", "visit",
  "Observation", "observation",
  "Death", "death"
)
knitr::kable(tb)

## ----queryEx, eval=FALSE------------------------------------------------------
#  t1dConceptSet <- cs(descendants(195771), name = "T1D")
#  t1dQuery <- conditionOccurrence(t1dConceptSet)

## ----queryInCohort, eval=FALSE------------------------------------------------
#  metforminConceptSet <- cs(descendants(1503297), name = "metformin")
#  t1dConceptSet <- cs(descendants(195771), name = "T1D")
#  
#  metforminCohort <- cohort(
#    entry = entry(
#      # metformin drug query as index event
#      drugExposure(metforminConceptSet, firstOccurrence()),
#      observationWindow = continuousObservation(priorDays = -365, postDays = 365L),
#      primaryCriteriaLimit = "All"
#    ),
#    attrition = attrition(
#      'noT1d' = withAll(
#        exactly(
#          x = 0,
#          # query for t1d occurrence to exclude patients
#          query = conditionOccurrence(t1dConceptSet),
#          aperture = duringInterval(
#            startWindow = eventStarts(a = -Inf, b = 0, index = "startDate")
#          )
#        )
#      )
#    ),
#    exit = exit(
#      endStrategy = observationExit(),
#      censor = censoringEvents(
#        #exit based on observence of t1d condition
#        # query for t1d occurrence for censor
#        conditionOccurrence(t1dConceptSet)
#      )
#    )
#  )

## ----attrInQuery, eval=FALSE--------------------------------------------------
#  t1dConceptSet <- cs(descendants(195771), name = "T1D")
#  
#  maleT1D <- conditionOccurrence(t1dConceptSet, male())
#  maleT1D18andOlder <- conditionOccurrence(t1dConceptSet, male(), age(gte(18)))
#  maleT1D18andOlderFirstDx <- conditionOccurrence(
#    t1dConceptSet, male(), age(gte(18)), firstOccurrence())

## ----criteriaExampleA, eval=FALSE---------------------------------------------
#  atenololConceptSet <- cs(descendants(1314002), name - "atenolol")
#  
#  atenololCriteria <- atLeast(
#    x = 2,
#    query = drugExposure(atenololConceptSet),
#    aperture = duringInterval(
#      startWindow = eventStarts(a = -365, b = -30, index = "startDate")
#    )
#  )

## ----criteriaExampleB, eval=FALSE---------------------------------------------
#  atenololConceptSet <- cs(descendants(1314002), name - "atenolol")
#  
#  atenololCriteriaA <- exactly(
#    x = 2,
#    query = drugExposure(atenololConceptSet),
#    aperture = duringInterval(
#      startWindow = eventStarts(a = -365, b = -30, index = "startDate")
#    )
#  )
#  
#  atenololCriteriaB <- atMost(
#    x = 2,
#    query = drugExposure(atenololConceptSet),
#    aperture = duringInterval(
#      startWindow = eventStarts(a = -365, b = -30, index = "startDate")
#    )
#  )
#  

## ----aperture1, eval=FALSE----------------------------------------------------
#  aperture1 <- duringInterval(
#    startWindow = eventStarts(a = -365, b = -30, index = "startDate")
#  )

## ----aperture2, eval=FALSE----------------------------------------------------
#  aperture2 <- duringInterval(
#    startWindow = eventStarts(a = -Inf, b = -30, index = "startDate")
#  )

## ----aperture3, eval=FALSE----------------------------------------------------
#  aperture3 <- duringInterval(
#    startWindow = eventStarts(a = -30, b = 30, index = "startDate")
#  )

## ----aperture4, eval=FALSE----------------------------------------------------
#  aperture4 <- duringInterval(
#    startWindow = eventStarts(a = -365, b = -30, index = "startDate"),
#    endWindow = eventEnds(a = 30, b = 365, index = "startDate")
#  )

## ----aperture5, eval=FALSE----------------------------------------------------
#  aperture5 <- duringInterval(
#    startWindow = eventStarts(a = -365, b = -30, index = "startDate"),
#    endWindow = eventEnds(a = 30, b = 365, index = "startDate"),
#    restrictVisit = TRUE,
#    ignoreObservationPeriod = TRUE
#  )

## ----t2dAlgo, eval=FALSE------------------------------------------------------
#  t2dAlgo <- withAny(
#    # Path 1: 0 T2Dx + 1 T2Rx + 1 abLab
#    withAll(
#      exactly(0,
#              t2d,
#              duringInterval(startWindow = eventStarts(-Inf, 0))
#      ),
#      atLeast(1,
#              t2dDrug,
#              duringInterval(startWindow = eventStarts(-Inf, 0))
#      ),
#      withAny(
#        atLeast(1,
#                abLabHb,
#                duringInterval(startWindow = eventStarts(-Inf, 0))
#        ),
#        atLeast(1,
#                abLabRan,
#                duringInterval(startWindow = eventStarts(-Inf, 0))
#        ),
#        atLeast(1,
#                abLabFast,
#                duringInterval(startWindow = eventStarts(-Inf, 0))
#        )
#      )
#    ),
#    #Path 2: 1 T2Dx + 0 T1Rx + 0 T2Rx + 1 AbLab
#    withAll(
#      atLeast(1,
#              t2d,
#              duringInterval(startWindow = eventStarts(-Inf, 0))
#      ),
#      exactly(0,
#              t1dDrug,
#              duringInterval(startWindow = eventStarts(-Inf, 0))
#      ),
#      exactly(0,
#              t2dDrug,
#              duringInterval(startWindow = eventStarts(-Inf, 0))
#      ),
#      withAny(
#        atLeast(1,
#                abLabHb,
#                duringInterval(startWindow = eventStarts(-Inf, 0))
#        ),
#        atLeast(1,
#                abLabRan,
#                duringInterval(startWindow = eventStarts(-Inf, 0))
#        ),
#        atLeast(1,
#                abLabFast,
#                duringInterval(startWindow = eventStarts(-Inf, 0))
#        )
#      )
#    ),
#    #Path 3: 1 T2Dx + 0 T1Rx + 1 T2Rx
#    withAll(
#      atLeast(1,
#              t2d,
#              duringInterval(startWindow = eventStarts(-Inf, 0))
#      ),
#      exactly(0,
#              t1dDrug,
#              duringInterval(startWindow = eventStarts(-Inf, 0))
#      ),
#      atLeast(1,
#              t2dDrug,
#              duringInterval(startWindow = eventStarts(-Inf, 0))
#      )
#    ),
#    #Path 4: 1 T2Dx + 1 T1Rx + 1 T1Rx|T2Rx
#    withAll(
#      atLeast(1,
#              t2d,
#              duringInterval(startWindow = eventStarts(-Inf, 0))
#      ),
#      atLeast(1,
#              t1dDrug,
#              duringInterval(startWindow = eventStarts(-Inf, 0))
#      ),
#      atLeast(1,
#              t1dDrugWT2Drug,
#              duringInterval(startWindow = eventStarts(-Inf, 0))
#      )
#    ),
#    #Path 5: 1 T2Dx  + 1 T1Rx + 0 T2Rx + 2 T2Dx
#    withAll(
#      atLeast(1,
#              t2d,
#              duringInterval(startWindow = eventStarts(-Inf, 0))
#      ),
#      atLeast(1,
#              t1dDrug,
#              duringInterval(startWindow = eventStarts(-Inf, 0))
#      ),
#      exactly(0,
#              t2dDrug,
#              duringInterval(startWindow = eventStarts(-Inf, 0))
#      ),
#      atLeast(2,
#              t2d,
#              duringInterval(startWindow = eventStarts(-Inf, 0))
#      )
#    )
#  )

## ----criteriaInGroup, eval=FALSE----------------------------------------------
#  noT1d <- withAll(
#    # criteria: no t1d prior
#    exactly(
#      x = 0,
#      query = conditionOccurrence(t1dConceptSet),
#      aperture = duringInterval(
#        startWindow = eventStarts(a = -Inf, b = 0, index = "startDate")
#      )
#    )
#  )
#  # wrap this in a group withAll

## ----cohortAttrition, eval=FALSE----------------------------------------------
#  cohort <- cohort(
#    entry = entry(
#      # index event....
#    ),
#    attrition = attrition(
#      'noT1d' = withAll(
#        exactly(
#          x = 0,
#          # query for t1d occurrence to exclude patients
#          query = conditionOccurrence(t1dConceptSet),
#          aperture = duringInterval(
#            startWindow = eventStarts(a = -Inf, b = 0, index = "startDate")
#          )
#        )
#      )
#    ),
#    exit = exit(
#      #cohort exit....
#    )
#  )

## ----groupInGroup, eval=FALSE-------------------------------------------------
#  # Path 1: 0 T2Dx + 1 T2Rx + 1 abLab
#  path1 <- withAll(
#    exactly(0,
#            t2d,
#            duringInterval(startWindow = eventStarts(-Inf, 0))
#    ),
#    atLeast(1,
#            t2dDrug,
#            duringInterval(startWindow = eventStarts(-Inf, 0))
#    ),
#    withAny(
#      atLeast(1,
#              abLabHb,
#              duringInterval(startWindow = eventStarts(-Inf, 0))
#      ),
#      atLeast(1,
#              abLabRan,
#              duringInterval(startWindow = eventStarts(-Inf, 0))
#      ),
#      atLeast(1,
#              abLabFast,
#              duringInterval(startWindow = eventStarts(-Inf, 0))
#      )
#    )
#  )

## ----hospHf, eval=FALSE-------------------------------------------------------
#  ipCse <- cs(descendants(9201, 9203, 262), name = "visit")
#  hf <- cs(descendants(316139), name = "heart failure")
#  
#  query <- visit(
#    ipCse, #index
#    #nested attribute
#    nestedWithAll(
#      atLeast(1,
#              conditionOccurrence(hf),
#              duringInterval(
#                startWindow = eventStarts(0, Inf, index = "startDate"),
#                endWindow = eventStarts(-Inf, 0, index = "endDate")
#              )
#      )
#    )
#  )

