TRUNCATE TABLE @work_database_schema.@test_cohort;
DROP TABLE @work_database_schema.@test_cohort;


