## ----tidy=TRUE,eval=FALSE-----------------------------------------------------
#  install.packages("remotes")
#  remotes::install_github("ohdsi/Eunomia")

## ----tidy=TRUE,eval=TRUE------------------------------------------------------
connectionDetails <- Eunomia::getEunomiaConnectionDetails()
Eunomia::createCohorts(connectionDetails = connectionDetails)

## ----tidy=TRUE,eval=FALSE-----------------------------------------------------
#  remotes::install_github("ohdsi/FeatureExtraction")
#  remotes::install_github("ohdsi/Characterization")

## ----tidy=TRUE,eval=TRUE------------------------------------------------------
library(Characterization)
library(dplyr)

## ----eval=TRUE----------------------------------------------------------------
exampleTargetIds <- c(1, 2, 4)
exampleOutcomeIds <- 3

## ----eval=TRUE----------------------------------------------------------------
exampleCovariateSettings <- FeatureExtraction::createCovariateSettings(
  useDemographicsGender = T,
  useDemographicsAge = T,
  useCharlsonIndex = T
)

## ----eval=TRUE----------------------------------------------------------------
exampleAggregateCovariateSettings <- createAggregateCovariateSettings(
  targetIds = exampleTargetIds,
  outcomeIds = exampleOutcomeIds,
  riskWindowStart = 1, startAnchor = "cohort start",
  riskWindowEnd = 365, endAnchor = "cohort start",
  covariateSettings = exampleCovariateSettings,
  minCharacterizationMean = 0.01
)

## ----eval=TRUE,results='hide',error=FALSE,warning=FALSE,message=FALSE---------
agc <- computeAggregateCovariateAnalyses(
  connectionDetails = connectionDetails,
  cdmDatabaseSchema = "main",
  cdmVersion = 5,
  targetDatabaseSchema = "main",
  targetTable = "cohort",
  aggregateCovariateSettings = exampleAggregateCovariateSettings,
  databaseId = "Eunomia",
  runId = 1
)

## ----eval=TRUE----------------------------------------------------------------
agc$covariates %>%
  collect() %>%
  kableExtra::kbl()

## ----eval=TRUE----------------------------------------------------------------
agc$covariatesContinuous %>%
  collect() %>%
  kableExtra::kbl()

## ----eval=TRUE----------------------------------------------------------------
agc$covariateRef %>%
  collect() %>%
  kableExtra::kbl()

## ----eval=TRUE----------------------------------------------------------------
agc$analysisRef %>%
  collect() %>%
  kableExtra::kbl()

## ----eval=TRUE----------------------------------------------------------------
exampleTargetIds <- c(1, 2, 4)
exampleOutcomeIds <- 3

## ----eval=TRUE----------------------------------------------------------------
exampleDechallengeRechallengeSettings <- createDechallengeRechallengeSettings(
  targetIds = exampleTargetIds,
  outcomeIds = exampleOutcomeIds,
  dechallengeStopInterval = 30,
  dechallengeEvaluationWindow = 31
)

## ----eval=TRUE----------------------------------------------------------------
dc <- computeDechallengeRechallengeAnalyses(
  connectionDetails = connectionDetails,
  targetDatabaseSchema = "main",
  targetTable = "cohort",
  dechallengeRechallengeSettings = exampleDechallengeRechallengeSettings,
  databaseId = "Eunomia"
)

## ----eval=TRUE----------------------------------------------------------------
dc$dechallengeRechallenge %>%
  collect() %>%
  kableExtra::kbl()

## ----eval=TRUE----------------------------------------------------------------
failed <- computeRechallengeFailCaseSeriesAnalyses(
  connectionDetails = connectionDetails,
  targetDatabaseSchema = "main",
  targetTable = "cohort",
  dechallengeRechallengeSettings = exampleDechallengeRechallengeSettings,
  outcomeDatabaseSchema = "main",
  outcomeTable = "cohort",
  databaseId = "Eunomia"
)

## ----eval=TRUE----------------------------------------------------------------
failed$rechallengeFailCaseSeries %>%
  collect() %>%
  kableExtra::kbl()

## ----eval=TRUE----------------------------------------------------------------
exampleTimeToEventSettings <- createTimeToEventSettings(
  targetIds = exampleTargetIds,
  outcomeIds = exampleOutcomeIds
)

## ----eval=TRUE----------------------------------------------------------------
tte <- computeTimeToEventAnalyses(
  connectionDetails = connectionDetails,
  cdmDatabaseSchema = "main",
  targetDatabaseSchema = "main",
  targetTable = "cohort",
  timeToEventSettings = exampleTimeToEventSettings,
  databaseId = "Eunomia"
)

## ----eval=TRUE----------------------------------------------------------------
tte$timeToEvent %>%
  collect() %>%
  top_n(10) %>%
  kableExtra::kbl()

## ----eval=FALSE,results='hide',error=FALSE,warning=FALSE,message=FALSE--------
#  characterizationSettings <- createCharacterizationSettings(
#    timeToEventSettings = list(
#      exampleTimeToEventSettings
#    ),
#    dechallengeRechallengeSettings = list(
#      exampleDechallengeRechallengeSettings
#    ),
#    aggregateCovariateSettings = list(
#      exampleAggregateCovariateSettings
#    )
#  )
#  
#  # save the settings using
#  saveCharacterizationSettings(
#    settings = characterizationSettings,
#    saveDirectory = file.path(tempdir(), "saveSettings")
#  )
#  
#  # the settings can be loaded
#  characterizationSettings <- loadCharacterizationSettings(
#    saveDirectory = file.path(tempdir(), "saveSettings")
#  )
#  
#  runCharacterizationAnalyses(
#    connectionDetails = connectionDetails,
#    cdmDatabaseSchema = "main",
#    targetDatabaseSchema = "main",
#    targetTable = "cohort",
#    outcomeDatabaseSchema = "main",
#    outcomeTable = "cohort",
#    characterizationSettings = characterizationSettings,
#    saveDirectory = file.path(tempdir(), "example"),
#    tablePrefix = "c_",
#    databaseId = "1"
#  )

## ----eval=FALSE---------------------------------------------------------------
#  connectionDetailsT <- DatabaseConnector::createConnectionDetails(
#    dbms = "sqlite",
#    server = file.path(tempdir(), "example", "sqliteCharacterization", "sqlite.sqlite")
#  )
#  
#  exportDatabaseToCsv(
#    connectionDetails = connectionDetailsT,
#    resultSchema = "main",
#    targetDialect = "sqlite",
#    tablePrefix = "c_",
#    saveDirectory = file.path(tempdir(), "csv")
#  )

