Hydra 0.0.11
============

Changes:

1. Updating prediction and estimation skeletons to use Andromeda instead of ff

Hydra 0.0.5
===========

Bugfixes:

1. Several bugfixes in the ComparativeEffectStudy Shiny app