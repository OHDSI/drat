## ---- echo = FALSE, message = FALSE-------------------------------------------
knitr::opts_chunk$set(
  cache = FALSE,
  comment = "#>",
  error = FALSE,
  tidy = FALSE
)

## ----tidy=FALSE,eval=FALSE----------------------------------------------------
#  remotes::install_github("OHDSI/PhenotypeLibrary")

## ----tidy=FALSE,eval=TRUE-----------------------------------------------------
PhenotypeLibrary::listPhenotypes()

## ----tidy=FALSE,eval=TRUE-----------------------------------------------------
cohortDefinitionSet <- PhenotypeLibrary::getPlCohortDefinitionSet(cohortIds = c(1, 2, 3))

cohortDefinitionSet

## ----tidy=FALSE,eval=FALSE----------------------------------------------------
#  connectionDetails <-
#    DatabaseConnector::createConnectionDetails(
#      dbms = "postgresql",
#      server = "some.server.com/ohdsi",
#      user = "joe",
#      password = "secret"
#    )
#  cdmDatabaseSchema <- "cdm_synpuf"
#  cohortDatabaseSchema <- "scratch.dbo"
#  cohortTables <- CohortGenerator::getCohortTableNames()
#  CohortGenerator::generateCohortSet(
#    connectionDetails = connectionDetails,
#    cdmDatabaseSchema = cdmDatabaseSchema,
#    cohortDatabaseSchema = cohortDatabaseSchema,
#    cohortTableNames = cohortTables,
#    cohortDefinitionSet = cohortDefinitionSet
#  )

## ----tidy=FALSE,eval=FALSE----------------------------------------------------
#  
#  databaseId <- "synpuf"
#  
#  databaseName <-
#    "Medicare Claims Synthetic Public Use Files (SynPUFs)"
#  
#  databaseDescription <-
#    "Medicare Claims Synthetic Public Use Files (SynPUFs) were created to allow interested parties to gain familiarity using Medicare claims data while protecting beneficiary privacy. These files are intended to promote development of software and applications that utilize files in this format, train researchers on the use and complexities of Centers for Medicare and Medicaid Services (CMS) claims, and support safe data mining innovations. The SynPUFs were created by combining randomized information from multiple unique beneficiaries and changing variable values. This randomization and combining of beneficiary information ensures privacy of health information."
#  
#  CohortDiagnostics::executeDiagnostics(
#    cohortDefinitionSet = cohortDefinitionSet,
#    exportFolder = outputFolder,
#    databaseId = databaseId,
#    databaseName = databaseName,
#    databaseDescription = databaseDescription,
#    cohortDatabaseSchema = cohortDatabaseSchema,
#    cdmDatabaseSchema = cdmDatabaseSchema,
#    connectionDetails = connectionDetails,
#    cohortTableNames = cohortTableNames
#  )

