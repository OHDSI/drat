library(testthat)
library(Capr)
test_check("Capr")
