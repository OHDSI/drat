## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  eval = FALSE
)

## ----setup--------------------------------------------------------------------
#  library(Capr)

## ----algebra------------------------------------------------------------------
#  newCohort <- cohort + inclusionRule
#  cohortAB <- cohortA + cohortB

## ----cs-----------------------------------------------------------------------
#  cs(descendants(201826L), name = "T2D")
#  cs(201826L, 201254L, name = "Diabetes")

## ----cohort-fn----------------------------------------------------------------
#  cohort(entry, attrition, exit, era)

## ----query--------------------------------------------------------------------
#  visit(conceptSet, ...)
#  condition(concept, ...)
#  

## ----attr---------------------------------------------------------------------
#  condition(cs(descendants(201826L), name = "T2D"), male())
#  condition(cs(descendants(201826L), name = "T2D"), age(gte(18)))
#  condition(cs(descendants(201826L), name = "T2D"), first())
#  

## ----criteria-----------------------------------------------------------------
#  exactly(0,
#          query = condition(cs(descendants(201826L), name = "T2D")),
#          aperture = duringInterval(eventStarts(-Inf, -1))
#          )

## ----group--------------------------------------------------------------------
#  withAny(
#    atLeast(1, query = abLabHb, aperture = ap1),
#    atLeast(1, query = abLabRan, aperture = ap1),
#    atLeast(1, query = abLabFast, aperture = ap1)
#  )

