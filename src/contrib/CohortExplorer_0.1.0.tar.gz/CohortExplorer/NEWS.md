CohortExplorer 0.1.0
======================
New functionality that adds a 'Feature Cohort' domain based on instantiated cohorts
Removed dependency on SqlRender. [Thank you @schuemie](https://github.com/OHDSI/CohortExplorer/commit/0f3d68fcb958e511cbb7910c2ca26b27d3b5d364)
Removed dependency on clock.

CohortExplorer 0.0.17
======================
First CRAN release

CohortExplorer 0.0.16
======================
Changes based on CRAN reviewer feedback.

CohortExplorer 0.0.15
======================
Destination CRAN


CohortExplorer 0.0.14
======================

Reduces the need to move data into R


CohortExplorer 0.0.13
======================

Support temp cohort table
Updates tests

CohortExplorer 0.0.12
======================

Minor bug fixes

CohortExplorer 0.0.11
======================

Minor bug fixes

CohortExplorer 0.0.10
======================

Minor bug fixes

CohortExplorer 0.0.9
======================

Skipped

CohortExplorer 0.0.8
======================

Skipped

CohortExplorer 0.0.7
======================

Ability to use the observation period as the cohort table

CohortExplorer 0.0.6
======================

Remove rouge browser()

CohortExplorer 0.0.5
======================

Add vignette.
Minor optimization to how shiny app is created.

CohortExplorer 0.0.4
======================

Bug fix to shiny.

CohortExplorer 0.0.3
======================

Resolving minor issues in github checks. 
Indentation.

CohortExplorer 0.0.2
======================

Make HADES conformant. 

CohortExplorer 0.0.1
======================

This is a unreleased package. 
