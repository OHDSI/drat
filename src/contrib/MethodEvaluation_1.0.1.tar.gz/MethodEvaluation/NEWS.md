MethodEvaluation 1.0.1
======================

Bugfixes:

1. Fixed bug in positive control synthesis causing only most predictive covariates to be used when predicting outcome probabilities.