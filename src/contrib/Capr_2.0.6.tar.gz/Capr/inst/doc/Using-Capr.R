## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  eval = FALSE
)

## -----------------------------------------------------------------------------
#  library(Capr)
#  
#  GIBleed <- cs(descendants(192671), name = "GIbleed")
#  
#  GIBleed

## -----------------------------------------------------------------------------
#  giBleedCohort <- cohort(
#    entry = entry(
#      conditionOccurrence(GIBleed),
#      observationWindow = continuousObservation(0L, 0L),
#      primaryCriteriaLimit = "First"
#    ),
#    exit = exit(
#      endStrategy = observationExit()
#    )
#  )
#  
#  giBleedCohort

## -----------------------------------------------------------------------------
#  
#  
#  connectionDetails <- Eunomia::getEunomiaConnectionDetails()
#  
#  giBleedCohortJson <- as.json(giBleedCohort)
#  
#  sql <- CirceR::buildCohortQuery(
#    expression = CirceR::cohortExpressionFromJson(giBleedCohortJson),
#    options = CirceR::createGenerateOptions(generateStats = FALSE)
#  )
#  
#  cohortsToCreate <- tibble::tibble(
#    cohortId = 1,
#    cohortName = "GI Bleed",
#    sql = sql
#  )
#  
#  
#  cohortTableNames <- CohortGenerator::getCohortTableNames(cohortTable = "my_cohort_table")
#  CohortGenerator::createCohortTables(
#    connectionDetails = connectionDetails,
#    cohortDatabaseSchema = "main",
#    cohortTableNames = cohortTableNames
#  )
#  # Generate the cohorts
#  cohortsGenerated <- CohortGenerator::generateCohortSet(
#    connectionDetails = connectionDetails,
#    cdmDatabaseSchema = "main",
#    cohortDatabaseSchema = "main",
#    cohortTableNames = cohortTableNames,
#    cohortDefinitionSet = cohortsToCreate
#  )
#  
#  # Get the cohort counts
#  cohortCounts <- CohortGenerator::getCohortCounts(
#    connectionDetails = connectionDetails,
#    cohortDatabaseSchema = "main",
#    cohortTable = cohortTableNames$cohortTable
#  )
#  
#  

