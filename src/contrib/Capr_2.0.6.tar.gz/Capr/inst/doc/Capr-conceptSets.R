## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(Capr)

## -----------------------------------------------------------------------------
ace1 <- cs(1335471, #benazepril
           1340128, #captopril
           1341927, #enalapril
           1308216, #lisinopril
           1363749,  #fosinopril
           name = "aceInhibitors")
ace1

## -----------------------------------------------------------------------------
ace2 <- cs(descendants(1335471, 1340128, 1341927, 1363749, 1308216),
           name = "aceInhibitors")
ace2

## -----------------------------------------------------------------------------
ace3 <- cs(descendants(1335471, 1340128, 1341927, 1363749), exclude(1308216),
           name = "aceInhibitors")
ace3

## ----baseSet, eval=FALSE------------------------------------------------------
#  diclofenac <- cs(descendants(1124300), name = "diclofenac")
#  cat(as.json(diclofenac))

## ----fillOut, eval=FALSE------------------------------------------------------
#  con <- DatabaseConnector::connect(Eunomia::getEunomiaConnectionDetails())
#  diclofenac <- getConceptSetDetails(diclofenac, con, vocabularyDatabaseSchema = "main")
#  cat(as.json(diclofenac))

