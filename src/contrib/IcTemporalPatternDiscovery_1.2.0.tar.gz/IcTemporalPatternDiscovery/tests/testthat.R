library(testthat)
test_check("IcTemporalPatternDiscovery")
