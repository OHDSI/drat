IcTemporalPatternDiscovery 1.2.0
================================

Changes

1. Updating to newer DatabaseConnector version.