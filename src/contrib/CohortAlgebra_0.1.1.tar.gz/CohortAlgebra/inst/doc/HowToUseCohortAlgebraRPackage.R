## ---- echo = FALSE, message = FALSE-------------------------------------------
knitr::opts_chunk$set(
  cache = FALSE,
  comment = "#>",
  error = FALSE,
  tidy = FALSE)

## ----tidy=FALSE,eval=FALSE----------------------------------------------------
#    remotes::install_github("OHDSI/CohortAlgebra")

## ----tidy=FALSE,eval=FALSE----------------------------------------------------
#  
#    oldToNewCohortId <- dplyr::tibble(oldCohortId = c(1, 2, 3), newCohortId = c(4,4,4))
#  
#    CohortAlgebra::eraFyCohorts(connectionDetails = connectionDetails,
#                                cohortDatabaseSchema = cohortDatabaseSchema,
#                                cohortTable = "cohort",
#                                oldToNewCohortId = oldToNewCohortId,
#                                eraconstructorpad = 0,
#                                purgeConflicts = TRUE)

