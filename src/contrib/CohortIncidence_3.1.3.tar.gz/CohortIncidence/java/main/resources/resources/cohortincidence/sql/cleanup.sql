DROP TABLE @schemaName.incidence_summary;
