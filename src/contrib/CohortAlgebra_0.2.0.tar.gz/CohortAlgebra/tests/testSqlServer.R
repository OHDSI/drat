library(testthat)
options(dbms = "sql server")
test_check("CohortAlgebra")
