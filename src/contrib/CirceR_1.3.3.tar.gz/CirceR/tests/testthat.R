library(testthat)
library(CirceR)

test_check("CirceR")
