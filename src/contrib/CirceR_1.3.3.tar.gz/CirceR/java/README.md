Source Code Information
=======================

Circe can be found at [https://github.com/OHDSI/circe-be](https://github.com/OHDSI/circe-be).

All other dependencies found in pom.xml of that project can be found via [Maven](https://mvnrepository.com/).
