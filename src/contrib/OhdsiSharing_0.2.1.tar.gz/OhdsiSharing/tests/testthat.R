library(testthat)
test_check("OhdsiSharing")
