#' @param cdmDatabaseSchema          Schema name where your omop cdm tables with person level data reside.
#'                                   Note that for SQL Server, this should include both the database and schema name, for example 
#'                                   'scratch.dbo'.
