#' @param cohortTable            The name of the cohort table.
