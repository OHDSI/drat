#' @param vocabularyDatabaseSchema   Schema name where your omop vocabulary tables reside. It maybe the cdmDatabaseSchema.
#'                                   Note that for SQL Server, this should include both the database and schema name, for example 
#'                                   'scratch.dbo'.
