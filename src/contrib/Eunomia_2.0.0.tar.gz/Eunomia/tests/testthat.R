library(testthat)
library(Eunomia)
test_check("Eunomia")
