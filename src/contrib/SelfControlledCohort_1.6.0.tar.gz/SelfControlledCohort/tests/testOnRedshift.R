library(testthat)
library(SelfControlledCohort)
options(dbms = "sqlite")
test_check("SelfControlledCohort")
