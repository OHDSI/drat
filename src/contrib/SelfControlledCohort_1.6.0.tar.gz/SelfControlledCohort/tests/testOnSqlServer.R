library(testthat)
library(SelfControlledCohort)
options(dbms = "sql server")
test_check("SelfControlledCohort")
