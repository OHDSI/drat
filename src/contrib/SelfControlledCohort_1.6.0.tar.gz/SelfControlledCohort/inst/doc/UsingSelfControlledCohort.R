## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ---- include=FALSE-----------------------------------------------------------
library(SelfControlledCohort)
library(Eunomia)

connectionDetails <- Eunomia::getEunomiaConnectionDetails()

result <- runSelfControlledCohort(
  connectionDetails = connectionDetails,
  cdmDatabaseSchema = "main",
  exposureIds = '', # include all drugs as exposures
  outcomeIds = '' # include all conditions as outcomes
)

## ---- message=F---------------------------------------------------------------
library(dplyr)
result$estimates %>% 
  arrange(desc(irr)) %>% 
  head()

## -----------------------------------------------------------------------------
example <- result$estimates %>% 
  filter(exposureId == 1713332, outcomeId == 257012) 

example %>% 
  tidyr::gather() %>% 
  mutate(value = format(round(value,1), scientific = F)) %>% 
  rename(column = key) %>% 
  knitr::kable(align = c("lr"))

## ---- include=FALSE-----------------------------------------------------------
Eunomia::createCohorts(connectionDetails)

## ---- include=FALSE-----------------------------------------------------------

result <- runSelfControlledCohort(
  connectionDetails = connectionDetails,
  cdmDatabaseSchema = "main",
  exposureIds = c(1,4), # The NSAIDs cohort #4 and the Celecoxib cohort #1
  outcomeIds = 3, # The GiBleed cohort #3
  exposureTable = "cohort",
  outcomeTable = "cohort",
)

## -----------------------------------------------------------------------------
result$estimates %>% 
  filter(exposureId == 4, outcomeId == 3) %>% 
  tidyr::gather() %>% 
  mutate(value = format(round(value,1), scientific = F)) %>% 
  rename(column = key) %>% 
  knitr::kable(align = c("lr"))

## -----------------------------------------------------------------------------
con <- DatabaseConnector::connect(connectionDetails)

## ---- include=FALSE-----------------------------------------------------------
result <- runSelfControlledCohort(
  connectionDetails = connectionDetails,
  cdmDatabaseSchema = "main",
  exposureIds = '', # use all rows in exposure table
  outcomeIds = '', # use all rows in outcome table
  exposureDatabaseSchema = "main",
  exposureTable = "condition_cohort",
  outcomeDatabaseSchema = "main",
  outcomeTable = "measurement_cohort",
  riskWindowStartExposed = 1,
  riskWindowEndExposed = 365,
  riskWindowEndUnexposed = -1,
  riskWindowStartUnexposed = -365,
)

## -----------------------------------------------------------------------------
result$estimates %>% 
  tidyr::gather() %>% 
  mutate(value = format(round(value,1), scientific = F)) %>% 
  rename(column = key) %>% 
  knitr::kable(align = c("lr"))

## -----------------------------------------------------------------------------
	
sccArgs1 <- createRunSelfControlledCohortArgs(firstExposureOnly = TRUE,
                                              firstOutcomeOnly = TRUE,
                                              minAge = "",
                                              maxAge = "",
                                              studyStartDate = "",
                                              studyEndDate = "",
                                              addLengthOfExposureExposed = TRUE,
                                              riskWindowStartExposed = 1,
                                              riskWindowEndExposed = 30,
                                              addLengthOfExposureUnexposed = TRUE,
                                              riskWindowEndUnexposed = -1,
                                              riskWindowStartUnexposed = -30,
                                              hasFullTimeAtRisk = FALSE,
                                              computeTarDistribution = TRUE,
                                              washoutPeriod = 0,
                                              followupPeriod = 0)

sccArgs2 <- createRunSelfControlledCohortArgs(firstExposureOnly = TRUE,
                                              firstOutcomeOnly = TRUE,
                                              minAge = "",
                                              maxAge = "",
                                              studyStartDate = "",
                                              studyEndDate = "",
                                              addLengthOfExposureExposed = TRUE,
                                              riskWindowStartExposed = 1,
                                              riskWindowEndExposed = 365,
                                              addLengthOfExposureUnexposed = TRUE,
                                              riskWindowEndUnexposed = -1,
                                              riskWindowStartUnexposed = -365,
                                              hasFullTimeAtRisk = FALSE,
                                              computeTarDistribution = TRUE,
                                              washoutPeriod = 0,
                                              followupPeriod = 0)

sccAnalysis1 <- createSccAnalysis(analysisId = 1,
                              description = "30 day risk windows",
                              exposureType = NULL, # What are the valid values for this argument?
                              outcomeType = NULL,
                              runSelfControlledCohortArgs = sccArgs1)


sccAnalysis2 <- createSccAnalysis(analysisId = 2,
                              description = "365 day risk windows",
                              exposureType = NULL,
                              outcomeType = NULL,
                              runSelfControlledCohortArgs = sccArgs1)

sccAnalysisList <- list(sccAnalysis1, sccAnalysis2)


## -----------------------------------------------------------------------------

exposureOutcomeList <- list(createExposureOutcome(exposureId = 4, outcomeId = 3),
                            createExposureOutcome(exposureId = 1, outcomeId = 3))
  

## -----------------------------------------------------------------------------
	
results <- runSccAnalyses(connectionDetails,
                          cdmDatabaseSchema = "main",
                          exposureTable = "cohort",
                          outcomeTable = "cohort",
                          outputFolder = "./SelfControlledCohortOutput",
                          sccAnalysisList = sccAnalysisList,
                          exposureOutcomeList = exposureOutcomeList,
                          analysisThreads = 1,
                          computeThreads = 1)


summarizeAnalyses(results, "./SelfControlledCohortOutput")

