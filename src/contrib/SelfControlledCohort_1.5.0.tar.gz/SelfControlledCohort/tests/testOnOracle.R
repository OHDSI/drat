library(testthat)
library(SelfControlledCohort)
options(dbms = "oracle")
test_check("SelfControlledCohort")
