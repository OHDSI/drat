library(testthat)
library(SelfControlledCohort)
options(dbms = "postgresql")
test_check("SelfControlledCohort")
