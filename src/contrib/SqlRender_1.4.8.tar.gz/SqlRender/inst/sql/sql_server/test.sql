SELECT * FROM table;
