## ----echo = FALSE, message = FALSE, warning = FALSE---------------------------
library(Keeper)

## ----eval = FALSE, echo = FALSE, warning=FALSE, message=FALSE-----------------
#  keeper <- createKeeper(
#    connectionDetails = connectionDetails,
#    databaseId = "Synpuf",
#    cdmDatabaseSchema = "dbo",
#    cohortDatabaseSchema = "results",
#    cohortTable = "cohort",
#    cohortDefinitionId = 1234,
#    cohortName = "DM type I",
#    sampleSize = 100,
#    assignNewId = TRUE,
#    useAncestor = TRUE,
#    doi = c(435216, 201254),
#    symptoms = c(79936, 432454, 4232487, 4229881, 254761),
#    comorbidities = c(141253, 432867, 436670, 433736, 255848),
#    drugs = c(21600712, 21602728, 21603531),
#    diagnosticProcedures = c(0),
#    measurements	= c(3004410,3005131,3005673,3010084,3033819,4149519,4229110, 4020120),
#    alternativeDiagnosis = c(192963,201826,441267,40443308),
#    treatmentProcedures = c(4242748),
#    complications =  c(201820,375545,380834,433968,442793,4016045,4209145,4299544)
#  )

