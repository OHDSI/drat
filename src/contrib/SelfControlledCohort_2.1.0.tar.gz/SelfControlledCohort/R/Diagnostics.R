# Copyright 2026 Observational Health Data Sciences and Informatics
#
# This file is part of SelfControlledCohort
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

#' Get default diagnostic thresholds
#'
#' @description
#' Returns default thresholds for diagnostic tests following SCCS standards.
#' Version 2.1.0+ uses revised diagnostics that align with SelfControlledCaseSeries package.
#'
#' @return A list of diagnostic thresholds
#'
#' @details
#' Thresholds:
#' \itemize{
#'   \item mdrrMaxAcceptable - Maximum acceptable MDRR (default: 10.0). Higher values indicate low power.
#'   \item maxPreExposureProportion - Maximum proportion of persons with pre-exposure outcomes (default: 0.05)
#'   \item preExposurePThreshold - Significance threshold for pre-exposure gain test (default: 0.05)
#'   \item maxEventDependentCensoring - Maximum proportion censored within 30 days of outcome (default: 0.25)
#'   \item minEventsPerWindow - Minimum events required in each window (default: 3)
#'   \item easeMaxAcceptable - Maximum acceptable EASE (default: 0.25). Requires negative controls.
#' }
#'
#' @examples
#' \donttest{
#' if (interactive()) {
#' # Get default thresholds
#'    thresholds <- getDefaultDiagnosticThresholds()
#'
#'    # Modify specific thresholds
#'    customThresholds <- getDefaultDiagnosticThresholds()
#'    customThresholds$mdrrMaxAcceptable <- 5.0
#' }
#' }
#' @export
getDefaultDiagnosticThresholds <- function() {
  list(
    mdrrMaxAcceptable = 10.0, # Max MDRR for adequate power
    maxPreExposureProportion = 0.05, # Max 5% with pre-exposure outcomes
    preExposurePThreshold = 0.05, # Significance level for pre-exposure test
    maxEventDependentCensoring = 0.25, # Max 25% censored within 30 days of outcome
    minEventsPerWindow = 3, # Min 3 events in each window
    easeMaxAcceptable = 0.25 # Max EASE for acceptable systematic error
  )
}

#' Run Self-Controlled Cohort Diagnostics
#'
#' @description
#' Runs a suite of diagnostic tests to assess the validity of SCC analysis assumptions.
#' Version 1.6.0+ implements diagnostics aligned with SelfControlledCaseSeries package standards.
#'
#' @param connection                  DatabaseConnector connection instance
#' @param cdmDatabaseSchema           Name of database schema that contains OMOP CDM
#' @param tempEmulationSchema         Schema for temp table emulation (Oracle, Impala)
#' @param resultsTable                Name of the results table (contains counts)
#' @param riskWindowsTable            Name of the risk windows table
#' @param outcomeTable                Name of outcome table (e.g., "condition_era", "cohort")
#' @param outcomeDatabaseSchema       Schema containing outcome table
#' @param analysisId                  Analysis identifier
#' @param databaseId                  Database identifier for results export
#' @param estimates                   Data frame of raw SCC results (including rr and se_log_rr)
#' @param controlType                 Calibrate effect estimates with outcome (default) or exposure controls.
#'                                    Determines whether EASE is grouped by target or outcome.
#' @param diagnostics                 Character vector of diagnostics to run. Options:
#'                                    "all", "mdrr", "pre_exposure_gain", "event_dependent", "ease"
#' @param thresholds                  Named list of diagnostic thresholds (see getDefaultDiagnosticThresholds)
#' @param computeThreads              Number of parallel threads to use for CPU-bound diagnostic
#'                                    computations (e.g., MDRR and EASE). Default is the number of
#'                                    available cores minus 1.
#' @param resultExportManager         ResultModelManager::ResultExportManager instance
#'
#' @return
#' Invisible data frame of diagnostic results
#'
#' @examples
#' \donttest{
#' if (interactive()) {
#'   connectionDetails <- Eunomia::getEunomiaConnectionDetails()
#'   connection <- DatabaseConnector::connect(connectionDetails)
#'
#'   diagnostics <- runSccDiagnostics(
#'     connection = connection,
#'     cdmDatabaseSchema = "main",
#'     resultsTable = "#scc_results",
#'     riskWindowsTable = "#risk_windows",
#'     analysisId = 1,
#'     databaseId = "Eunomia",
#'     estimates = resultsData,
#'     diagnostics = "all",
#'     thresholds = getDefaultDiagnosticThresholds()
#'   )
#'
#'   DatabaseConnector::disconnect(connection)
#' }
#' }
#' @export
runSccDiagnostics <- function(connection,
                              cdmDatabaseSchema,
                              tempEmulationSchema = getOption("sqlRenderTempEmulationSchema"),
                              resultsTable,
                              riskWindowsTable,
                              outcomeTable = "condition_era",
                              outcomeDatabaseSchema = cdmDatabaseSchema,
                              analysisId,
                              databaseId,
                              estimates = NULL,
                              controlType = "outcome",
                              diagnostics = c("all"),
                              thresholds = getDefaultDiagnosticThresholds(),
                              computeThreads = getOption("strategus.SelfControlledCohort.computeThreads",
                                default = parallel::detectCores() - 1
                              ),
                              resultExportManager) {
  if (!DatabaseConnector::dbIsValid(connection)) {
    stop("Invalid connection object")
  }

  checkmate::assertR6(resultExportManager, "ResultExportManager")

  # Ensure all thresholds are present by merging with defaults
  defaultThresholds <- getDefaultDiagnosticThresholds()
  for (name in names(defaultThresholds)) {
    if (is.null(thresholds[[name]])) {
      thresholds[[name]] <- defaultThresholds[[name]]
    }
  }

  # Expand "all" to specific diagnostics
  allDiagnostics <- c(
    "mdrr", "pre_exposure_gain", "event_dependent",
    "ease"
  )

  if ("all" %in% diagnostics) {
    diagnostics <- allDiagnostics
  }

  ParallelLogger::logInfo("Running SCC diagnostics")

  diagnosticResults <- data.frame()

  # Run MDRR diagnostic (power analysis)
  if ("mdrr" %in% diagnostics) {
    ParallelLogger::logInfo("- Running MDRR (power) diagnostic")
    mdrrResult <- .computeMdrrDiagnostic(
      connection = connection,
      resultsTable = resultsTable,
      analysisId = analysisId,
      thresholds = thresholds,
      tempEmulationSchema = tempEmulationSchema,
      computeThreads = computeThreads
    )
    diagnosticResults <- rbind(diagnosticResults, mdrrResult)
  }

  # Run pre-exposure gain diagnostic
  if ("pre_exposure_gain" %in% diagnostics) {
    ParallelLogger::logInfo("- Running pre-exposure gain diagnostic")
    preExpGainResult <- .computePreExposureGainDiagnostic(
      connection = connection,
      cdmDatabaseSchema = cdmDatabaseSchema,
      riskWindowsTable = riskWindowsTable,
      outcomeTable = outcomeTable,
      outcomeDatabaseSchema = outcomeDatabaseSchema,
      analysisId = analysisId,
      thresholds = thresholds,
      tempEmulationSchema = tempEmulationSchema,
      resultsTable = resultsTable
    )
    diagnosticResults <- rbind(diagnosticResults, preExpGainResult)
  }

  # Run event-dependent observation diagnostic
  if ("event_dependent" %in% diagnostics) {
    ParallelLogger::logInfo("- Running event-dependent observation diagnostic")
    eventDepResult <- .computeEventDependentDiagnostic(
      connection = connection,
      cdmDatabaseSchema = cdmDatabaseSchema,
      riskWindowsTable = riskWindowsTable,
      outcomeTable = outcomeTable,
      outcomeDatabaseSchema = outcomeDatabaseSchema,
      analysisId = analysisId,
      thresholds = thresholds,
      tempEmulationSchema = tempEmulationSchema,
      resultsTable = resultsTable
    )
    diagnosticResults <- rbind(diagnosticResults, eventDepResult)
  }

  # Run EASE diagnostic (systematic error)
  if ("ease" %in% diagnostics && !is.null(estimates)) {
    ParallelLogger::logInfo("- Running EASE (systematic error) diagnostic")
    easeResult <- .computeEaseDiagnostic(
      estimates = estimates,
      analysisId = analysisId,
      thresholds = thresholds,
      controlType = controlType,
      computeThreads = computeThreads
    )
    diagnosticResults <- rbind(diagnosticResults, easeResult)
  }

  # Add database_id to results
  # Ensure all required columns exist
  cols <- c("database_id", "analysis_id", "target_cohort_id", "outcome_cohort_id", "diagnostic_name", "diagnostic_value", "pass")

  if (nrow(diagnosticResults) > 0) {
    diagnosticResults$database_id <- databaseId

    # Reorder and rename columns to match specification
    # specification uses outcome_cohort_id, target_cohort_id, diagnostic_name, diagnostic_value, pass
    # ensure we don't have analysisId vs analysis_id confusion
    if (!"analysis_id" %in% colnames(diagnosticResults) && "analysisId" %in% colnames(diagnosticResults)) {
      diagnosticResults$analysis_id <- diagnosticResults$analysisId
    }

    for (col in cols) {
      if (!col %in% colnames(diagnosticResults)) {
        diagnosticResults[[col]] <- NA
      }
    }
  } else {
    # No diagnostics were produced - write an empty file with the expected columns
    # so the export folder stays consistent even when the analysis yields no data.
    diagnosticResults <- data.frame(
      database_id = character(0),
      analysis_id = numeric(0),
      target_cohort_id = numeric(0),
      outcome_cohort_id = numeric(0),
      diagnostic_name = character(0),
      diagnostic_value = numeric(0),
      pass = integer(0)
    )
  }

  diagnosticResults <- diagnosticResults |>
    dplyr::select(dplyr::all_of(cols))

  # Compute blinding status
  blindingRows <- .computeBlindingStatus(diagnosticResults, controlType = controlType)
  if (nrow(blindingRows) > 0) {
    diagnosticResults <- rbind(diagnosticResults, blindingRows)
  }

  # Export all results at once via Manager (always export, even if empty)
  resultExportManager$exportDataFrame(diagnosticResults, "scc_diagnostics_summary")

  if (nrow(diagnosticResults) > 0) {
    ParallelLogger::logInfo(sprintf("Completed %d diagnostic tests", nrow(diagnosticResults)))

    failures <- diagnosticResults |>
      dplyr::filter(.data$pass == 0 & !(.data$diagnostic_name %in% c("UNBLIND", "UNBLIND_FOR_CALIBRATION")))


    if (nrow(failures) > 0) {
      ParallelLogger::logInfo(sprintf("%d diagnostic test(s) failed:", nrow(failures)))
    } else {
      ParallelLogger::logInfo("All diagnostic tests passed")
    }
  } else {
    ParallelLogger::logWarn("No diagnostic results generated")
  }

  return(invisible(diagnosticResults))
}

#' Get diagnostics summary
#'
#' @description
#' Returns a summary of diagnostic results for each target-outcome pair, including
#' blinding status.
#'
#' @param diagnosticResults  Data frame of diagnostic results as returned by runSccDiagnostics
#'
#' @return
#' A data frame with blinding status per target-outcome pair
#'
#' @examples
#' \donttest{
#' if (interactive()) {
#' connectionDetails <- Eunomia::getEunomiaConnectionDetails()
#' connection <- DatabaseConnector::connect(connectionDetails)
#'
#' diagnostics <- runSccDiagnostics(
#'   connection = connection,
#'   cdmDatabaseSchema = "main",
#'   resultsTable = "#scc_results",
#'   riskWindowsTable = "#risk_windows",
#'   analysisId = 1,
#'   databaseId = "Eunomia",
#'   estimates = resultsData,
#'   diagnostics = "all",
#'   thresholds = getDefaultDiagnosticThresholds()
#' )
#'
#' DatabaseConnector::disconnect(connection)
#' summary <- getDiagnosticsSummary(diagnostics)
#' }
#' }
#' @export
getDiagnosticsSummary <- function(diagnosticResults) {
  if (is.null(diagnosticResults) || nrow(diagnosticResults) == 0) {
    return(data.frame())
  }

  summary <- diagnosticResults |>
    dplyr::filter(.data$diagnostic_name %in% c("UNBLIND", "UNBLIND_FOR_CALIBRATION")) |>
    tidyr::pivot_wider(
      names_from = "diagnostic_name",
      values_from = "pass",
      id_cols = c("database_id", "analysis_id", "target_cohort_id", "outcome_cohort_id")
    )

  return(summary)
}

#' Compute blinding status rows
#' @noRd
.computeBlindingStatus <- function(diagnosticResults, controlType = "outcome") {
  if (nrow(diagnosticResults) == 0) {
    return(data.frame())
  }

  # EASE is computed per calibration group and stored with a 0 on the opposing
  # cohort column: outcome_cohort_id = 0 for outcome controls (grouped by target),
  # target_cohort_id = 0 for exposure controls (grouped by outcome).  Separate
  # EASE from the per-pair diagnostics so it can be applied to every row of its
  # calibration group.
  if (controlType == "exposure") {
    easeRows <- diagnosticResults |>
      dplyr::filter(.data$diagnostic_name == "EASE") |>
      dplyr::select("database_id", "analysis_id", "outcome_cohort_id", "pass") |>
      dplyr::rename(easePass = "pass")
    easeJoinBy <- c("database_id", "analysis_id", "outcome_cohort_id")
  } else {
    easeRows <- diagnosticResults |>
      dplyr::filter(.data$diagnostic_name == "EASE") |>
      dplyr::select("database_id", "analysis_id", "target_cohort_id", "pass") |>
      dplyr::rename(easePass = "pass")
    easeJoinBy <- c("database_id", "analysis_id", "target_cohort_id")
  }

  pairRows <- diagnosticResults |>
    dplyr::filter(.data$diagnostic_name != "EASE", .data$outcome_cohort_id != 0)

  # Group by target-outcome pair and compute aggregate pass status
  blindingStatus <- pairRows |>
    dplyr::group_by(.data$database_id, .data$analysis_id, .data$target_cohort_id, .data$outcome_cohort_id) |>
    dplyr::summarize(
      # Tier 1: unblind_for_calibration - all non-MDRR diagnostics must pass
      pass_for_calibration = as.integer(all(.data$pass[.data$diagnostic_name != "MDRR"] == 1, na.rm = TRUE)),
      # Tier 2: unblind - all diagnostics must pass (including MDRR)
      pass_all = as.integer(all(.data$pass == 1, na.rm = TRUE)),
      .groups = "drop"
    ) |>
    dplyr::left_join(easeRows, by = easeJoinBy) |>
    dplyr::mutate(
      # EASE gates unblinding when it was evaluated (pass = 0 blocks).  When EASE
      # is missing or not evaluated (pass = NA) it is treated as pass-through.
      pass_for_calibration = as.integer(.data$pass_for_calibration == 1 & (is.na(.data$easePass) | .data$easePass == 1)),
      pass_all = as.integer(.data$pass_all == 1 & (is.na(.data$easePass) | .data$easePass == 1))
    ) |>
    dplyr::select(-"easePass")

  # Create new rows for the summary
  unblindRows <- blindingStatus |>
    dplyr::transmute(
      .data$database_id,
      .data$analysis_id,
      .data$target_cohort_id,
      .data$outcome_cohort_id,
      diagnostic_name = "UNBLIND",
      diagnostic_value = NA_real_,
      pass = .data$pass_all
    )

  unblindCalibrationRows <- blindingStatus |>
    dplyr::transmute(
      .data$database_id,
      .data$analysis_id,
      .data$target_cohort_id,
      .data$outcome_cohort_id,
      diagnostic_name = "UNBLIND_FOR_CALIBRATION",
      diagnostic_value = NA_real_,
      pass = .data$pass_for_calibration
    )

  return(rbind(unblindRows, unblindCalibrationRows))
}

#' Compute EASE diagnostic
#' @noRd
.computeEaseDiagnostic <- function(estimates, analysisId, thresholds, controlType = "outcome", computeThreads = 1) {
  if (is.null(estimates) || nrow(estimates) == 0) {
    return(data.frame())
  }

  # Ensure columns expected by computeEase exist regardless of case
  # we expect rr and se_log_rr or seLogRr
  # Normalize names to CamelCase for internal logic
  if (!("true_effect_size" %in% colnames(estimates))) {
    return(data.frame())
  }

  negatives <- estimates |>
    dplyr::filter(.data$true_effect_size == 1)

  if (nrow(negatives) == 0) {
    return(data.frame())
  }


  # Map snake_case to CamelCase for common fields if they exist as snake
  nameMap <- c(
    targetCohortId = "target_cohort_id",
    outcomeCohortId = "outcome_cohort_id",
    seLogRr = "se_log_rr"
  )
  
  for (i in seq_along(nameMap)) {
    new <- names(nameMap)[i]
    old <- nameMap[i]
    if (old %in% colnames(negatives) && !(new %in% colnames(negatives))) {
      negatives[[new]] <- negatives[[old]]
    }
  }

  groupCol <- if (controlType == "exposure") "outcome_cohort_id" else "target_cohort_id"
  groups <- split(negatives, negatives[[groupCol]])

  if (computeThreads > 1 && length(groups) > 1) {
    cluster <- ParallelLogger::makeCluster(min(computeThreads, length(groups)))
    on.exit(ParallelLogger::stopCluster(cluster), add = TRUE)

    easeResults <- ParallelLogger::clusterApply(
      cluster,
      groups,
      .computeEaseForGroup,
      analysisId = analysisId,
      thresholds = thresholds,
      controlType = controlType,
      progressBar = FALSE
    )
    easeResults <- dplyr::bind_rows(easeResults)
  } else {
    easeResults <- dplyr::bind_rows(lapply(
      groups,
      .computeEaseForGroup,
      analysisId = analysisId,
      thresholds = thresholds,
      controlType = controlType
    ))
  }

  return(easeResults)
}

#' Compute EASE for a single calibration group
#'
#' This worker only uses the EmpiricalCalibration package (a hard dependency) and
#' base functions, so it can run on ParallelLogger cluster nodes without requiring
#' the SelfControlledCohort package to be installed (e.g., during R CMD build).
#' @noRd
.computeEaseForGroup <- function(data, analysisId, thresholds, controlType = "outcome") {
  groupCol <- if (controlType == "exposure") "outcome_cohort_id" else "target_cohort_id"
  groupId <- data[[groupCol]][1]

  ease <- NA_real_
  if (nrow(data) > 1) {
    ease <- tryCatch(
      {
        negatives <- data[!is.na(data$rr) & !is.na(data$seLogRr), , drop = FALSE]
        if (nrow(negatives) >= 2) {
          nullDist <- EmpiricalCalibration::fitNull(logRr = log(negatives$rr), seLogRr = negatives$seLogRr)
          if (!is.na(nullDist["mean"]) && !is.na(nullDist["sd"])) {
            as.numeric(EmpiricalCalibration::computeExpectedAbsoluteSystematicError(nullDist))
          } else {
            NA_real_
          }
        } else {
          NA_real_
        }
      },
      error = function(e) NA_real_
    )
  }

  pass <- if (is.na(ease)) {
    NA_integer_ # Not evaluated (insufficient controls) - treated as pass-through
  } else {
    as.integer(ease <= thresholds$easeMaxAcceptable)
  }

  data.frame(
    analysis_id = analysisId,
    target_cohort_id = if (controlType == "exposure") 0 else groupId,
    outcome_cohort_id = if (controlType == "exposure") groupId else 0,
    diagnostic_name = "EASE",
    diagnostic_value = ease,
    pass = pass
  )
}



#' Compute MDRR (power) diagnostic
#' @noRd
.computeMdrrDiagnostic <- function(connection,
                                   resultsTable,
                                   analysisId,
                                   thresholds,
                                   tempEmulationSchema,
                                   computeThreads = 1) {
  sql <- "
  SELECT
    target_cohort_id,
    outcome_cohort_id,
    num_outcomes_exposed,
    num_outcomes_unexposed,
    time_at_risk_exposed,
    time_at_risk_unexposed
  FROM @results_table
  WHERE analysis_id = @analysis_id
  "

  cluster <- ParallelLogger::makeCluster(computeThreads)
  on.exit(ParallelLogger::stopCluster(cluster), add = TRUE)

  computeMdrrCallBack <- function(rows, position, cluster, analysisId, thresholds) {
    if (nrow(rows) == 0) {
      return(NULL)
    }
    batches <- ceiling(nrow(rows) / 10000)
    rows <- split(rows, rep_len(seq_len(batches), nrow(rows)))
    rows <- ParallelLogger::clusterApply(
      cluster,
      rows,
      .computeMdrrForRows,
      analysisId = analysisId,
      thresholds = thresholds,
      progressBar = FALSE
    )
    dplyr::bind_rows(rows)
  }

  # Stream the results table in batches to avoid materializing the full
  # target-outcome grid in memory.
  batchResults <- DatabaseConnector::renderTranslateQueryApplyBatched(
    connection = connection,
    sql = sql,
    fun = computeMdrrCallBack,
    args = list(cluster = cluster, analysisId = analysisId, thresholds = thresholds),
    results_table = resultsTable,
    analysis_id = analysisId,
    tempEmulationSchema = tempEmulationSchema,
    snakeCaseToCamelCase = TRUE
  )

  diagnostics <- dplyr::bind_rows(batchResults)

  if (is.null(diagnostics) || nrow(diagnostics) == 0) {
    return(data.frame())
  }

  return(diagnostics)
}

#' Compute MDRR rows for a chunk of results
#'
#' This worker only uses base/stats functions so it can run on ParallelLogger
#' cluster nodes without requiring the SelfControlledCohort package to be
#' installed (e.g., during R CMD build when rebuilding vignettes).
#' @noRd
.computeMdrrForRows <- function(rows, analysisId, thresholds) {
  computeMdrr <- function(exposedPersonTime, unexposedPersonTime, exposedEvents, unexposedEvents) {
    if (exposedPersonTime <= 0 || unexposedPersonTime <= 0) {
      return(NA_real_)
    }
    if (exposedEvents < 1 || unexposedEvents < 1) {
      return(NA_real_)
    }

    n <- exposedEvents + unexposedEvents
    r <- exposedPersonTime / (exposedPersonTime + unexposedPersonTime)

    if (r <= 0 || r >= 1) {
      return(Inf)
    }

    zAlpha <- stats::qnorm(1 - 0.05 / 2)

    computePowerSrl <- function(b, z, r, n) {
      if (b <= 0) {
        return(0)
      }
      eb <- exp(b)
      A <- 2 * ((eb * r / (eb * r + 1 - r)) * b - log(eb * r + 1 - r))
      B <- b^2 / A * eb * r * (1 - r) / (eb * r + 1 - r)^2
      zb <- (sqrt(n * A) - z) / sqrt(B)
      return(stats::pnorm(zb))
    }

    targetFn <- function(b) {
      computePowerSrl(b, zAlpha, r, n) - 0.80
    }

    if (targetFn(log(100)) < 0) {
      return(100)
    }
    if (targetFn(1e-6) > 0) {
      return(1.0)
    }

    root <- tryCatch(
      stats::uniroot(targetFn, interval = c(1e-6, log(100)), tol = 1e-4)$root,
      error = function(e) NA_real_
    )

    if (is.na(root)) {
      return(NA_real_)
    }
    return(exp(root))
  }

  mdrr <- vapply(seq_len(nrow(rows)), function(i) {
    computeMdrr(
      exposedPersonTime = rows$timeAtRiskExposed[i],
      unexposedPersonTime = rows$timeAtRiskUnexposed[i],
      exposedEvents = rows$numOutcomesExposed[i],
      unexposedEvents = rows$numOutcomesUnexposed[i]
    )
  }, numeric(1))

  # Check if MDRR is acceptable
  pass <- ifelse(is.na(mdrr), 0L, as.integer(mdrr <= thresholds$mdrrMaxAcceptable))

  data.frame(
    analysis_id = analysisId,
    target_cohort_id = rows$targetCohortId,
    outcome_cohort_id = rows$outcomeCohortId,
    diagnostic_name = "MDRR",
    diagnostic_value = mdrr,
    pass = pass
  )
}

#' Compute pre-exposure gain diagnostic
#' @noRd
.computePreExposureGainDiagnostic <- function(connection,
                                              cdmDatabaseSchema,
                                              riskWindowsTable,
                                              outcomeTable,
                                              outcomeDatabaseSchema,
                                              analysisId,
                                              thresholds,
                                              tempEmulationSchema,
                                              resultsTable = NULL) {
  preExpData <- testPreExposureGain(
    connection = connection,
    riskWindowsTable = riskWindowsTable,
    outcomeTable = outcomeTable,
    outcomeDatabaseSchema = outcomeDatabaseSchema,
    analysisId = analysisId,
    cdmDatabaseSchema = cdmDatabaseSchema,
    tempEmulationSchema = tempEmulationSchema,
    resultsTable = resultsTable
  )

  if (nrow(preExpData) == 0) {
    return(data.frame())
  }

  # Test passes if p-value > threshold (not significantly higher before)
  pVal <- preExpData$pValue
  pass <- ifelse(is.na(pVal), 1L, as.integer(pVal > thresholds$preExposurePThreshold))

  rateRatioRows <- data.frame(
    analysis_id = analysisId,
    target_cohort_id = preExpData$targetCohortId,
    outcome_cohort_id = preExpData$outcomeCohortId,
    diagnostic_name = "PRE_EXPOSURE_RATE_RATIO",
    diagnostic_value = preExpData$preExposureRateRatio,
    pass = 1L # We primarily gate on the p-value
  )

  pValueRows <- data.frame(
    analysis_id = analysisId,
    target_cohort_id = preExpData$targetCohortId,
    outcome_cohort_id = preExpData$outcomeCohortId,
    diagnostic_name = "PRE_EXPOSURE_P_VALUE",
    diagnostic_value = pVal,
    pass = pass
  )

  return(rbind(rateRatioRows, pValueRows))
}


#' Compute event-dependent observation diagnostic
#' @noRd
.computeEventDependentDiagnostic <- function(connection,
                                             cdmDatabaseSchema,
                                             riskWindowsTable,
                                             outcomeTable,
                                             outcomeDatabaseSchema,
                                             analysisId,
                                             thresholds,
                                             tempEmulationSchema,
                                             resultsTable = NULL) {
  # Determine outcome table columns
  outcomeTable <- tolower(outcomeTable)
  if (outcomeTable == "condition_era") {
    outcomeStartDate <- "condition_era_start_date"
    outcomeId <- "condition_concept_id"
    outcomePersonId <- "person_id"
  } else if (outcomeTable == "condition_occurrence") {
    outcomeStartDate <- "condition_start_date"
    outcomeId <- "condition_concept_id"
    outcomePersonId <- "person_id"
  } else {
    outcomeStartDate <- "cohort_start_date"
    outcomeId <- "cohort_definition_id"
    outcomePersonId <- "subject_id"
  }

  # Restrict to the outcomes of interest when possible, so the database does not
  # scan the entire outcome table for concept ids the study never requested.
  outcomeRestriction <- ""
  if (!is.null(resultsTable)) {
    outcomeRestriction <- "
  INNER JOIN (
    SELECT DISTINCT outcome_cohort_id
    FROM @results_table
    WHERE analysis_id = @analysis_id
  ) roi
    ON o.@outcome_id = roi.outcome_cohort_id"
  }

  sql <- sprintf("
  SELECT
    rw.exposure_id as target_cohort_id,
    o.@outcome_id as outcome_cohort_id,
    COUNT(DISTINCT rw.person_id) as total_persons_with_outcome,
    SUM(CASE WHEN DATEDIFF(d, o.@outcome_start_date, op.observation_period_end_date) <= 30
             THEN 1 ELSE 0 END) as censored_within_30_days
  FROM @risk_windows_table rw
  INNER JOIN @outcome_database_schema.@outcome_table o
    ON rw.person_id = o.@outcome_person_id
    AND o.@outcome_start_date >= rw.risk_window_start_unexposed
    AND o.@outcome_start_date <= rw.risk_window_end_exposed%s
  INNER JOIN @cdm_database_schema.observation_period op
    ON rw.person_id = op.person_id
    AND o.@outcome_start_date >= op.observation_period_start_date
    AND o.@outcome_start_date <= op.observation_period_end_date
  WHERE rw.analysis_id = @analysis_id
  GROUP BY rw.exposure_id, o.@outcome_id
  ", outcomeRestriction)

  args <- list(
    connection = connection,
    sql = sql,
    risk_windows_table = riskWindowsTable,
    outcome_database_schema = outcomeDatabaseSchema,
    outcome_table = outcomeTable,
    outcome_start_date = outcomeStartDate,
    outcome_id = outcomeId,
    outcome_person_id = outcomePersonId,
    cdm_database_schema = cdmDatabaseSchema,
    analysis_id = analysisId,
    tempEmulationSchema = tempEmulationSchema,
    snakeCaseToCamelCase = TRUE
  )
  if (!is.null(resultsTable)) {
    args$results_table <- resultsTable
  }

  results <- do.call(DatabaseConnector::renderTranslateQuerySql, args)

  if (nrow(results) == 0) {
    return(data.frame())
  }

  proportion <- results$censoredWithin30Days / results$totalPersonsWithOutcome

  diagnostics <- data.frame(
    analysis_id = analysisId,
    target_cohort_id = results$targetCohortId,
    outcome_cohort_id = results$outcomeCohortId,
    diagnostic_name = "EVENT_DEPENDENT_OBSERVATION",
    diagnostic_value = proportion,
    pass = as.integer(proportion <= thresholds$maxEventDependentCensoring)
  )

  return(diagnostics)
}

