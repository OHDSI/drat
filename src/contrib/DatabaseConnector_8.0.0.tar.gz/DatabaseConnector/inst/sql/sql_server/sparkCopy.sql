COPY INTO @sqlTableName
FROM (
  SELECT @selectFields
  FROM 'abfss://@azureContainerName@@azureStorageAccount.dfs.core.windows.net/@fileName'
) 
FILEFORMAT = CSV
FORMAT_OPTIONS (
  'header' = 'true',
  'multiLine' = 'true',
  'quote' = '"',
  'escape' = '"'
)
COPY_OPTIONS('mergeSchema' = 'true');
