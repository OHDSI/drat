## ---- echo = FALSE, message = FALSE, warning = FALSE---------------------
library(CaseCrossover)
knitr::opts_chunk$set(
  cache=FALSE,
  comment = "#>",
  error = FALSE,
  tidy = FALSE)

## ----tidy=FALSE,eval=TRUE------------------------------------------------
connectionDetails <- createConnectionDetails(dbms = "postgresql", 
                                             server = "localhost/ohdsi", 
                                             user = "joe", 
                                             password = "supersecret")

cdmDatabaseSchema <- "my_cdm_data"
cohortDatabaseSchema <- "my_work_schema"
cohortTable <- "vignette_cohorts"

## ----tidy=FALSE,eval=FALSE-----------------------------------------------
#  library(SqlRender)
#  sql <- readSql("vignette.sql")
#  sql <- renderSql(sql,
#                   cdmDatabaseSchema = cdmDatabaseSchema,
#                   cohortDatabaseSchema = cohortDatabaseSchema,
#                   cohortTable = cohortTable)$sql
#  sql <- translateSql(sql, targetDialect = connectionDetails$dbms)$sql
#  
#  connection <- connect(connectionDetails)
#  executeSql(connection, sql)

## ----tidy=FALSE,eval=FALSE-----------------------------------------------
#  negativeControls <- c(705178,
#                        705944,
#                        710650,
#                        714785,
#                        719174,
#                        719311,
#                        735340,
#                        742185,
#                        780369,
#                        781182,
#                        924724,
#                        990760,
#                        1110942,
#                        1111706,
#                        1136601,
#                        1317967,
#                        1501309,
#                        1505346,
#                        1551673,
#                        1560278,
#                        1584910,
#                        19010309,
#                        19044727,
#                        40163731)
#  diclofenac <- 1124300
#  giBleed <- 1
#  rheumatoidArthritis <- 2
#  
#  exposureOutcomeNcList <- list()
#  for (exposureId in c(diclofenac, negativeControls)) {
#    exposureOutcomeNc <- createExposureOutcomeNestingCohort(exposureId = exposureId,
#                                                            outcomeId = giBleed,
#                                                            nestingCohortId = rheumatoidArthritis)
#    exposureOutcomeNcList[[length(exposureOutcomeNcList) + 1]] <- exposureOutcomeNc
#  }
#  

## ----tidy=FALSE,eval=TRUE------------------------------------------------
getDbCaseCrossoverDataArgs1 <- createGetDbCaseCrossoverDataArgs(useNestingCohort = FALSE)

selectSubjectsToIncludeArgs1 <- createSelectSubjectsToIncludeArgs(firstOutcomeOnly = FALSE,
                                                                  washoutPeriod = 180)

getExposureStatusArgs1 <- createGetExposureStatusArgs(firstExposureOnly = FALSE,
                                                      riskWindowStart = 0,
                                                      riskWindowEnd = 0,
                                                      controlWindowOffsets = -30)

## ----tidy=FALSE,eval=TRUE------------------------------------------------
ccrAnalysis1 <- createCcrAnalysis(analysisId = 1,
                                 description = "Simple case-crossover",
                                 getDbCaseCrossoverDataArgs = getDbCaseCrossoverDataArgs1,
                                 selectSubjectsToIncludeArgs = selectSubjectsToIncludeArgs1,
                                 getExposureStatusArgs = getExposureStatusArgs1)

## ----tidy=FALSE,eval=TRUE------------------------------------------------
getDbCaseCrossoverDataArgs2 <- createGetDbCaseCrossoverDataArgs(useNestingCohort = TRUE,
                                                       getTimeControlData = TRUE,
                                                       getVisits = TRUE)

ccrAnalysis2 <- createCcrAnalysis(analysisId = 2,
                                description = "Nested case-crossover",
                                getDbCaseCrossoverDataArgs = getDbCaseCrossoverDataArgs2,
                                selectSubjectsToIncludeArgs = selectSubjectsToIncludeArgs1,
                                getExposureStatusArgs = getExposureStatusArgs1)

matchingCriteria1 <- createMatchingCriteria(matchOnAge = TRUE,
                                           ageCaliper = 2,
                                           matchOnGender = TRUE)

selectSubjectsToIncludeArgs2 <- createSelectSubjectsToIncludeArgs(firstOutcomeOnly = FALSE,
                                                                  washoutPeriod = 180,
                                                                  matchingCriteria = matchingCriteria1)

ccrAnalysis3 <- createCcrAnalysis(analysisId = 3,
                                description = "Nested case-time-control, matching on age and gender",
                                getDbCaseCrossoverDataArgs = getDbCaseCrossoverDataArgs2,
                                selectSubjectsToIncludeArgs = selectSubjectsToIncludeArgs2,
                                getExposureStatusArgs = getExposureStatusArgs1)

matchingCriteria2 <- createMatchingCriteria(matchOnAge = TRUE,
                                            ageCaliper = 2,
                                            matchOnGender = TRUE,
                                            matchOnVisitDate = TRUE)

selectSubjectsToIncludeArgs3 <- createSelectSubjectsToIncludeArgs(firstOutcomeOnly = FALSE,
                                                                  washoutPeriod = 180,
                                                                  matchingCriteria = matchingCriteria2)

ccrAnalysis4 <- createCcrAnalysis(analysisId = 4,
                                description = "Nested case-time-control, matching on age, gender, and visit",
                                getDbCaseCrossoverDataArgs = getDbCaseCrossoverDataArgs2,
                                selectSubjectsToIncludeArgs = selectSubjectsToIncludeArgs3,
                                getExposureStatusArgs = getExposureStatusArgs1)

## ----tidy=FALSE,eval=TRUE------------------------------------------------
ccrAnalysisList <- list(ccrAnalysis1, ccrAnalysis2, ccrAnalysis3, ccrAnalysis4)

## ----tidy=FALSE,eval=TRUE------------------------------------------------
outcomeIds = list(narrowDefinition = 1,
                  broadDefinition = 11)

exposureOutcomeNc <- createExposureOutcomeNestingCohort(exposureId = 1124300,
                                                        outcomeId = outcomeIds,
                                                        nestingCohortId = 2)

## ----tidy=FALSE,eval=TRUE------------------------------------------------
ccrAnalysis1A <- createCcrAnalysis(analysisId = 1,
                                 description = "Simple case-crossover, using narrow def.",
                                 outcomeType = "narrowDefinition",
                                 getDbCaseCrossoverDataArgs = getDbCaseCrossoverDataArgs1,
                                 selectSubjectsToIncludeArgs = selectSubjectsToIncludeArgs1,
                                 getExposureStatusArgs = getExposureStatusArgs1)

ccrAnalysis1B <- createCcrAnalysis(analysisId = 2,
                                 description = "Simple case-crossover, using broad def.",
                                 outcomeType = "broadDefinition",
                                 getDbCaseCrossoverDataArgs = getDbCaseCrossoverDataArgs1,
                                 selectSubjectsToIncludeArgs = selectSubjectsToIncludeArgs1,
                                 getExposureStatusArgs = getExposureStatusArgs1)

ccrAnalysisList2 <- list(ccrAnalysis1A, ccrAnalysis1B)

## ----tidy=FALSE,eval=FALSE-----------------------------------------------
#  result <- runCcrAnalyses(connectionDetails = connectionDetails,
#                          cdmDatabaseSchema = cdmDatabaseSchema,
#                          oracleTempSchema = cdmDatabaseSchema,
#                          exposureDatabaseSchema = cdmDatabaseSchema,
#                          exposureTable = "drug_era",
#                          outcomeDatabaseSchema = cohortDatabaseSchema,
#                          outcomeTable = cohortTable,
#                          nestingCohortDatabaseSchema = cohortDatabaseSchema,
#                          nestingCohortTable = cohortTable,
#                          outputFolder = outputFolder,
#                          exposureOutcomeNestingCohortList = exposureOutcomeNcList,
#                          ccrAnalysisList = ccrAnalysisList,
#                          getDbCaseCrossoverDataThreads = 1,
#                          selectSubjectsToIncludeThreads = 4,
#                          getExposureStatusThreads = 3,
#                          fitCaseCrossoverModelThreads = 4)

## ----tidy=FALSE,eval=FALSE-----------------------------------------------
#  ccrModelFile <- result$modelFile[result$exposureId == 1124300 &
#                                     result$outcomeId == 1 &
#                                     result$analysisId == 1]
#  ccModel <- readRDS(ccrModelFile)
#  summary(ccrModel)

## ----echo=FALSE,message=FALSE--------------------------------------------
if (file.exists("s:/temp/vignetteCaseCrossover2/outcomeModelReference.rds")){
  result <- readRDS("s:/temp/vignetteCaseCrossover2/outcomeModelReference.rds")
  ccrModelFile <- result$modelFile[result$exposureId == 1124300 & 
                                     result$outcomeId == 1 &
                                     result$analysisId == 1]
  ccrModel <- readRDS(ccrModelFile)
  summary(ccrModel)
}

## ----tidy=FALSE,eval=FALSE-----------------------------------------------
#  analysisSum <- summarizeCcrAnalyses(result)
#  head(analysisSum)

## ----echo=FALSE,message=FALSE--------------------------------------------
if (file.exists("s:/temp/vignetteCaseCrossover2/outcomeModelReference.rds")){
  analysisSum <- summarizeCcrAnalyses(result)
  head(analysisSum)
}

## ----tidy=FALSE,eval=FALSE-----------------------------------------------
#  library(EmpiricalCalibration)
#  
#  # Analysis 1: Simple case-crossover
#  negCons <- analysisSum[analysisSum$analysisId == 1 & analysisSum$exposureId != 1124300, ]
#  ei <-  analysisSum[analysisSum$analysisId == 1 & analysisSum$exposureId == 1124300, ]
#  null <- fitNull(negCons$logRr, negCons$seLogRr)
#  plotCalibrationEffect(logRrNegatives = negCons$logRr,
#                        seLogRrNegatives = negCons$seLogRr,
#                        logRrPositives = ei$logRr,
#                        seLogRrPositives = ei$seLogRr,
#                        null)

## ----echo=FALSE,message=FALSE,eval=TRUE----------------------------------
if (file.exists("s:/temp/vignetteCaseCrossover2/outcomeModelReference.rds")){
  library(EmpiricalCalibration)
  negCons <- analysisSum[analysisSum$analysisId == 1 & analysisSum$exposureId != 1124300, ]
  ei <-  analysisSum[analysisSum$analysisId == 1 & analysisSum$exposureId == 1124300, ]
  null <- fitNull(negCons$logRr, negCons$seLogRr)
  plotCalibrationEffect(logRrNegatives = negCons$logRr, 
                        seLogRrNegatives = negCons$seLogRr, 
                        logRrPositives = ei$logRr, 
                        seLogRrPositives = ei$seLogRr, 
                        null)
}

## ----tidy=FALSE,eval=FALSE-----------------------------------------------
#  # Analysis 2: Nesting in rheumatoid arthritis
#  negCons <- analysisSum[analysisSum$analysisId == 2 & analysisSum$exposureId != 1124300, ]
#  ei <-  analysisSum[analysisSum$analysisId == 2 & analysisSum$exposureId == 1124300, ]
#  null <- fitNull(negCons$logRr, negCons$seLogRr)
#  plotCalibrationEffect(logRrNegatives = negCons$logRr,
#                        seLogRrNegatives = negCons$seLogRr,
#                        logRrPositives = ei$logRr,
#                        seLogRrPositives = ei$seLogRr,
#                        null)

## ----echo=FALSE,message=FALSE,eval=TRUE----------------------------------
if (file.exists("s:/temp/vignetteCaseCrossover2/outcomeModelReference.rds")){
  library(EmpiricalCalibration)
  negCons <- analysisSum[analysisSum$analysisId == 2 & analysisSum$exposureId != 1124300, ]
  ei <-  analysisSum[analysisSum$analysisId == 2 & analysisSum$exposureId == 1124300, ]
  null <- fitNull(negCons$logRr, negCons$seLogRr)
  plotCalibrationEffect(logRrNegatives = negCons$logRr, 
                        seLogRrNegatives = negCons$seLogRr, 
                        logRrPositives = ei$logRr, 
                        seLogRrPositives = ei$seLogRr, 
                        null)
}

## ----tidy=FALSE,eval=FALSE-----------------------------------------------
#  # Analysis 3: Nested case-time-control, matching on age and gender
#  negCons <- analysisSum[analysisSum$analysisId == 3 & analysisSum$exposureId != 1124300, ]
#  ei <-  analysisSum[analysisSum$analysisId == 3 & analysisSum$exposureId == 1124300, ]
#  null <- fitNull(negCons$logRr, negCons$seLogRr)
#  plotCalibrationEffect(logRrNegatives = negCons$logRr,
#                        seLogRrNegatives = negCons$seLogRr,
#                        logRrPositives = ei$logRr,
#                        seLogRrPositives = ei$seLogRr,
#                        null)

## ----echo=FALSE,message=FALSE,eval=TRUE----------------------------------
if (file.exists("s:/temp/vignetteCaseCrossover2/outcomeModelReference.rds")){
  library(EmpiricalCalibration)
  negCons <- analysisSum[analysisSum$analysisId == 3 & analysisSum$exposureId != 1124300, ]
  ei <-  analysisSum[analysisSum$analysisId == 3 & analysisSum$exposureId == 1124300, ]
  null <- fitNull(negCons$logRr, negCons$seLogRr)
  plotCalibrationEffect(logRrNegatives = negCons$logRr, 
                        seLogRrNegatives = negCons$seLogRr, 
                        logRrPositives = ei$logRr, 
                        seLogRrPositives = ei$seLogRr, 
                        null)
}

## ----tidy=FALSE,eval=FALSE-----------------------------------------------
#  # Analysis 4: Nested case-time-control, matching on age, gender, and visit
#  negCons <- analysisSum[analysisSum$analysisId == 4 & analysisSum$exposureId != 1124300, ]
#  ei <-  analysisSum[analysisSum$analysisId == 4 & analysisSum$exposureId == 1124300, ]
#  null <- fitNull(negCons$logRr, negCons$seLogRr)
#  plotCalibrationEffect(logRrNegatives = negCons$logRr,
#                        seLogRrNegatives = negCons$seLogRr,
#                        logRrPositives = ei$logRr,
#                        seLogRrPositives = ei$seLogRr,
#                        null)

## ----echo=FALSE,message=FALSE,eval=TRUE----------------------------------
if (file.exists("s:/temp/vignetteCaseCrossover2/outcomeModelReference.rds")){
  library(EmpiricalCalibration)
  negCons <- analysisSum[analysisSum$analysisId == 4 & analysisSum$exposureId != 1124300, ]
  ei <-  analysisSum[analysisSum$analysisId == 4 & analysisSum$exposureId == 1124300, ]
  null <- fitNull(negCons$logRr, negCons$seLogRr)
  plotCalibrationEffect(logRrNegatives = negCons$logRr, 
                        seLogRrNegatives = negCons$seLogRr, 
                        logRrPositives = ei$logRr, 
                        seLogRrPositives = ei$seLogRr, 
                        null)
}

## ----tidy=TRUE,eval=TRUE-------------------------------------------------
citation("CaseCrossover")

## ----tidy=TRUE,eval=TRUE-------------------------------------------------
citation("Cyclops")

