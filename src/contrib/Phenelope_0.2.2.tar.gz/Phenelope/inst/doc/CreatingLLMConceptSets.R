## ----echo = FALSE, message = FALSE, warning = FALSE---------------------------
library(Phenelope)

## ----tidy=FALSE,eval=FALSE----------------------------------------------------
# # create database connection details
# connectionDetails <- DatabaseConnector::createConnectionDetails(
#   dbms = "postgresql",
#   server = "localhost/ohdsi",
#   user = "joe",
#   password = "supersecret"
# )

## ----tidy=FALSE,eval=FALSE----------------------------------------------------
# # create LLM client for ellmer
# llmClient <- ellmer::chat_azure_openai(
#   endpoint = gsub("/openai/deployments.*", "", keyring::key_get("genai_gpto3_endpoint")),
#   api_version = "2023-03-15-preview",
#   model = "o3",
#   credentials = function() keyring::key_get("genai_api_gpt4_key")
# )

## ----tidy=FALSE,eval=FALSE----------------------------------------------------
# targetName <- "Acute liver failure"
# targetClinicalDefinition <- "Acute liver failure is a rare but life-threatening syndrome characterized by the rapid deterioration of hepatocellular function, manifesting as significant coagulopathy and hepatic encephalopathy of any grade, developing within 28 days of the onset of jaundice or initial hepatic symptoms in an individual without evidence of pre-existing chronic liver disease or cirrhosis. The syndrome arises from a direct, primary insult to hepatocytes — including viral, toxic, drug-induced, autoimmune, metabolic, or indeterminate causes — and is conceptually distinct from liver dysfunction occurring as a secondary consequence of hemodynamic compromise (e.g., ischemic hepatitis, shock liver), systemic sepsis, or passive hepatic congestion from right-sided heart failure, all of which are explicitly excluded."

## ----tidy=FALSE,eval=FALSE----------------------------------------------------
# # run the
# finalSet <- Phenelope::createConceptSet(
#   name = targetName
#   clinicalDefinition = targetClinicalDefinition,
#   llmClient = llmClient,
#   connectionDetails = connectionDetails,
#   vocabDatabaseSchema = "yourCDMSchema",
#   cacheFolder = "c:/llmConceptSets/type2Dm"
# )

