## ---- echo = FALSE, message = FALSE-------------------------------------------
knitr::opts_chunk$set(
  cache = FALSE,
  comment = "#>",
  error = FALSE,
  tidy = FALSE
)

## ----eval = FALSE, echo=TRUE--------------------------------------------------
#  cohortIds <- c(1778211, 1778212, 1778213)
#  ROhdsiWebApi::authorizeWebApi(baseUrl = baseUrl, authMethod = "windows")
#  cohortDefinitionSet <- ROhdsiWebApi::exportCohortDefinitionSet(
#    baseUrl = baseUrl,
#    cohortIds = cohortIds
#  )

