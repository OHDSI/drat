# @file PrintFriendly.R
#
# Copyright 2020 Observational Health Data Sciences and Informatics
#
# This file is part of CirceR
# 
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# 
#     http://www.apache.org/licenses/LICENSE-2.0
# 
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

#' Render cohort print-friendly
#' 
#' @description 
#' Generates a print-friendly (human-readable) representation of the cohort definition. This can for example 
#' be used in a study protocol.
#'
#' @param expression  A character vector or result of cohortExpressionFromJson containing the cohort expression.
#'
#' @return 
#' A character vector containing the markdown.
#' 
#' @export
cohortPrintFriendly <- function(expression) {
  UseMethod("cohortPrintFriendly", .get_backend())
}

#' @export
cohortPrintFriendly.circe_backend_java <- function(expression) {
  ensureJavaBackend()
  renderer <- rJava::new(Class = rJava::J("org.ohdsi.circe.cohortdefinition.printfriendly.MarkdownRender"))
  expr <- expression
  if (is.list(expression)) { # assuming this is a JSON parsed expression in a RJSONIO list 
    expr <- RJSONIO::toJSON(expression)
  } 
  # expression can be a org.ohdsi.circe.cohortdefinition.CohortExpression or a String (it’s an overload method):
  markdown <- renderer$renderCohort(expr)

  return(markdown)
}

#' @export
cohortPrintFriendly.circe_backend_python <- function(expression) {
  circe <- ensurePythonBackend()
  if (is.list(expression) && !inherits(expression, "python.builtin.object")) {
    expression <- RJSONIO::toJSON(expression)
  }
  if (is.character(expression)) {
    expression <- circe$cohort_expression_from_json(expression)
  }
  return(circe$cohort_print_friendly(expression))
}

#' Render conceptSet array for print-friendly
#' 
#' @description 
#' Generates a print-friendly (human-readable) representation of an array of concept sets. This can for example 
#' be used in a study protocol.
#'
#' @param conceptSetList  A ConceptSet[] (from cohortExpression.conceptSets), a JSON string, or a list from RJSONIO::fromJson
#'
#' @return 
#' A character vector containing the markdown.
#' 
#' @export
conceptSetListPrintFriendly <- function(conceptSetList) {
  UseMethod("conceptSetListPrintFriendly", .get_backend())
}

#' @export
conceptSetListPrintFriendly.circe_backend_java <- function(conceptSetList) {
  ensureJavaBackend()
  renderer <- rJava::new(Class = rJava::J("org.ohdsi.circe.cohortdefinition.printfriendly.MarkdownRender"))

  if (is.character(conceptSetList)) {
    markdown <- renderer$renderConceptSetList(conceptSetList)
  } else if (is.list(conceptSetList)) {
    if (length(conceptSetList) == 0) {
      markdown <- ""
    } else if (inherits(conceptSetList[[1]],"jobjRef")) { # this is an java array
      markdown <- renderer$renderConceptSetList(rJava::.jarray(conceptSetList, contents.class = "org.ohdsi.circe.cohortdefinition.ConceptSet"))  
    } else {
      markdown <- renderer$renderConceptSetList(RJSONIO::toJSON(conceptSetList))
    }
  } else {
    stop("Unable to determine conceptSetList type in conceptSetListPrintFriendly()")
  }

  return(markdown)
}

#' @export
conceptSetListPrintFriendly.circe_backend_python <- function(conceptSetList) {
  circe <- ensurePythonBackend()
  renderer <- circe$cohortdefinition$MarkdownRender()
  
  if (is.list(conceptSetList) && !is.character(conceptSetList)) {
    # If it's an R list, convert to JSON for the Python side to handle uniformly
    conceptSetList <- RJSONIO::toJSON(conceptSetList)
  }
  
  return(renderer$render_concept_set_list(conceptSetList))
}

#' Render conceptSet array for print-friendly
#' 
#' @description 
#' Generates a print-friendly (human-readable) representation of a single concept set. This can for example 
#' be used in a study protocol.
#'
#' @param conceptSet  A ConceptSet (from cohortExpression.conceptSets[i]), a JSON string, or a list from RJSONIO::fromJson
#'
#' @return 
#' A character vector containing the markdown.
#' 
#' @export
conceptSetPrintFriendly <- function(conceptSet) {
  UseMethod("conceptSetPrintFriendly", .get_backend())
}

#' @export
conceptSetPrintFriendly.circe_backend_java <- function(conceptSet) {
  ensureJavaBackend()
  renderer <- rJava::new(Class = rJava::J("org.ohdsi.circe.cohortdefinition.printfriendly.MarkdownRender"))
  expr <- conceptSet
  if (is.list(conceptSet)) { # assuming this is a JSON parsed expression in a RJSONIO list 
    expr <- RJSONIO::toJSON(conceptSet)
  } 
  
  markdown <- renderer$renderConceptSet(expr)
  
  return(markdown)
}

#' @export
conceptSetPrintFriendly.circe_backend_python <- function(conceptSet) {
  circe <- ensurePythonBackend()
  renderer <- circe$cohortdefinition$MarkdownRender()
  
  if (is.list(conceptSet) && !is.character(conceptSet)) {
    conceptSet <- RJSONIO::toJSON(conceptSet)
  }
  
  return(renderer$render_concept_set(conceptSet))
}

