## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)

## ---- eval=FALSE--------------------------------------------------------------
#  
#  # load the data
#  plpData <- PatientLevelPrediction::loadPlpData('locationOfData')
#  
#  # pick the set<Model> from  DeepPatientLevelPrediction
#  deepLearningModel <- DeepPatientLevelPrediction::setResNet()
#  
#  # use PatientLevelPrediction to fit model
#  deepLearningResult <- PatientLevelPrediction::runPlp(
#      plpData = plpData,
#      outcomeId = 1230,
#      modelSettings = deepLearningModel,
#      analysisId = 'resNetTorch',
#      ...
#    )
#  

## ---- eval=FALSE--------------------------------------------------------------
#  
#  modelSettings <- setMultiLayerPerceptron(
#    numLayers = c(3L, 5L),
#    sizeHidden = c(64L, 128L),
#    dropout = c(0.2),
#    sizeEmbedding = c(32L, 64L),
#    estimatorSettings = setEstimator(
#      learningRate = c(1e-3, 1e-4),
#      weightDecay = c(1e-5),
#      batchSize = c(128L),
#      epochs=c(5L),
#      seed=12L
#    ),
#    randomSample=10L
#  )
#  
#  mlpResult <- PatientLevelPrediction::runPlp(
#      plpData = plpData,
#      outcomeId = 3,
#      modelSettings = modelSettings,
#      analysisId = 'MLP',
#      analysisName = 'Testing Deep Learning',
#      populationSettings = populationSet,
#      splitSettings = PatientLevelPrediction::createDefaultSplitSetting(),
#      preprocessSettings = PatientLevelPrediction::createPreprocessSettings(),
#      executeSettings = PatientLevelPrediction::createExecuteSettings(
#        runSplitData = T,
#        runSampleData = F,
#        runfeatureEngineering = F,
#        runPreprocessData = T,
#        runModelDevelopment = T,
#        runCovariateSummary = F
#      ),
#      saveDirectory = file.path(testLoc, 'DeepNNTorch')
#    )
#  

## ---- eval=FALSE--------------------------------------------------------------
#  
#  resset <- setResNet(
#    numLayers = c(2L),
#    sizeHidden = c(32L),
#    hiddenFactor = c(2L),
#    residualDropout = c(0.1),
#    hiddenDropout = c(0.1),
#    sizeEmbedding = c(32L),
#    estimatorSettings = setEstimator(learningRate = c(3e-4),
#                                     weightDecay = c(1e-6),
#                                     #device='cuda:0', # uncomment to use GPU
#                                     batchSize = 128L,
#                                     epochs = 3L,
#                                     seed = 42L),
#    hyperParamSearch = 'random',
#    randomSample = 1
#  )
#  
#  resResult <- PatientLevelPrediction::runPlp(
#      plpData = plpData,
#      outcomeId = 3,
#      modelSettings = resset,
#      analysisId = 'ResNet',
#      analysisName = 'Testing ResNet',
#      populationSettings = populationSet,
#      splitSettings = PatientLevelPrediction::createDefaultSplitSetting(),
#      preprocessSettings = PatientLevelPrediction::createPreprocessSettings(),
#      executeSettings = PatientLevelPrediction::createExecuteSettings(
#        runSplitData = T,
#        runSampleData = F,
#        runfeatureEngineering = F,
#        runPreprocessData = T,
#        runModelDevelopment = T,
#        runCovariateSummary = F
#      ),
#      saveDirectory = file.path(getwd(), 'ResNet') # change to save elsewhere
#    )
#  

## ---- eval=FALSE--------------------------------------------------------------
#  
#  modelSettings <- setTransformer(numBlocks = 3L,
#                                  dimToken = 32L,
#                                  dimOut = 1,
#                                  numHeads = 4L,
#                                  attDropout = 0.25,
#                                  ffnDropout = 0.25,
#                                  resDropout = 0,
#                                  dimHidden = 128L,
#                                  estimatorSettings = setEstimator(
#                                    learningRate = 3e-4,
#                                    weightDecay = 1e-6,
#                                    batchSize = 128L,
#                                    epochs = 10L,
#                                    device = 'cpu'
#                                  ),
#                                  randomSample=1L)
#  
#  
#  
#  TransformerResult <- PatientLevelPrediction::runPlp(
#      plpData = plpData,
#      outcomeId = 3,
#      modelSettings = modelSettings,
#      analysisId = 'Transformer',
#      analysisName = 'Testing transformer',
#      populationSettings = populationSet,
#      splitSettings = PatientLevelPrediction::createDefaultSplitSetting(),
#      preprocessSettings = PatientLevelPrediction::createPreprocessSettings(),
#      executeSettings = PatientLevelPrediction::createExecuteSettings(
#        runSplitData = T,
#        runSampleData = F,
#        runfeatureEngineering = F,
#        runPreprocessData = T,
#        runModelDevelopment = T,
#        runCovariateSummary = F
#      ),
#      saveDirectory = file.path(getwd(), 'Transformer') # change to save elsewhere
#    )

## ----tidy=TRUE,eval=TRUE------------------------------------------------------
citation("DeepPatientLevelPrediction")

