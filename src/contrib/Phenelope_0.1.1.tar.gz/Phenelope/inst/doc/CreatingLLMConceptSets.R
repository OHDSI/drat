## ----echo = FALSE, message = FALSE, warning = FALSE---------------------------
library(Phenelope)

## ----tidy=FALSE,eval=FALSE----------------------------------------------------
# # create database connection details
# connectionDetails <- DatabaseConnector::createConnectionDetails(
#   dbms = "postgresql",
#   server = "localhost/ohdsi",
#   user = "joe",
#   password = "supersecret"
# )

## ----tidy=FALSE,eval=FALSE----------------------------------------------------
# # create LLM client for ellmer
# llmClient <- ellmer::chat_azure_openai(
#   endpoint = gsub("/openai/deployments.*", "", keyring::key_get("genai_gpt4o_endpoint")),
#   api_version = "2023-03-15-preview",
#   model = "gpt-4o",
#   credentials = function() keyring::key_get("genai_api_gpt4_key")
# )

## ----tidy=FALSE,eval=FALSE----------------------------------------------------
# # run the
# finalSet <- Penelope::createConceptSet(
#   conceptName = "Type 2 Diabetes Mellitus",
#   originalConceptList = c(201826),
#   llmClient = llmClient,
#   connectionDetails = connectionDetails,
#   cdmDatabaseSchema = "yourCDMSchema",
#   outputDirectory = "c:/llmConceptSets/type2Dm"
# )

