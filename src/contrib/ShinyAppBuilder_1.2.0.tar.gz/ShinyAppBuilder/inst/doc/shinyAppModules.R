## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)

## ----echo=FALSE---------------------------------------------------------------

inputsForConfig <- data.frame(
  Inputs = c('moduleId','tabName','shinyModulePackage',
      'moduleUiFunction', 'moduleServerFunction',
      'moduleDatabaseConnectionKeyService',
      'moduleDatabaseConnectionKeyUsername',
      'moduleInfoBoxFile',
      'moduleIcon','resultDatabaseDetails','useKeyring'
),

Description = c("a unique id for the shiny app", "The menu text for the module", "The R package that contains the shiny module", "The name of the module's UI function", "The name of the module's server function", 
                "A name for the keyring service/environment variable to store the result database details",
                "A name for the keyring username/environment variable to store the result database details",
                "The function in the shinyModulePackage package that contains the helper information",
                "An icon to use in the menu for this module",
                "A list containing the results details: dbms, tablePrefix, cohortTablePrefix, databaseTablePrefix, schema, databaseTable, incidenceTablePrefix",
                "Whether to use keyring of environmental variables")
)

knitr::kable(inputsForConfig)


## ----eval=FALSE---------------------------------------------------------------
#  
#  aboutModule <- createModuleConfig(
#        moduleId = 'about',
#        tabName = "About",
#        shinyModulePackage = "OhdsiShinyModule",
#        moduleUiFunction = 'aboutViewer',
#        moduleServerFunction = 'aboutServer',
#        moduleDatabaseConnectionKeyService = NULL,
#        moduleDatabaseConnectionKeyUsername = NULL,
#        moduleInfoBoxFile =  "aboutHelperFile()",
#        moduleIcon = 'info',
#        resultDatabaseDetails = NULL,
#        useKeyring = TRUE
#      )
#  

## ----eval=FALSE---------------------------------------------------------------
#  
#  aboutModule <- createDefaultAboutConfig(
#        resultDatabaseDetails = NULL,
#        useKeyring = TRUE
#      )
#  

## ----eval=FALSE---------------------------------------------------------------
#  
#  resultDatabaseDetails <- list(
#        dbms = 'sqlite',
#        tablePrefix = 'plp_',
#        cohortTablePrefix = 'cg_',
#        databaseTablePrefix = '',
#        schema = 'main',
#        databaseTable = 'DATABASE_META_DATA'
#      )
#  
#  predictionModule <- createModuleConfig(
#      moduleId = 'prediction',
#      tabName = "Prediction",
#      shinyModulePackage = 'OhdsiShinyModules',
#      moduleUiFunction = "predictionViewer",
#      moduleServerFunction = "predictionServer",
#      moduleDatabaseConnectionKeyService ="resultDatabaseDetails",
#      moduleDatabaseConnectionKeyUsername = "prediction",
#      moduleInfoBoxFile =  "predictionHelperFile()",
#      moduleIcon = "chart-line",
#      resultDatabaseDetails = resultDatabaseDetails,
#      useKeyring = TRUE
#      )
#  

## ----eval=FALSE---------------------------------------------------------------
#  
#  resultDatabaseDetails <- list(
#        dbms = 'sqlite',
#        tablePrefix = 'plp_',
#        cohortTablePrefix = 'cg_',
#        databaseTablePrefix = '',
#        schema = 'main',
#        databaseTable = 'DATABASE_META_DATA'
#      )
#  
#  predictionModule <- createDefaultPredictionConfig(
#        resultDatabaseDetails = resultDatabaseDetails,
#        useKeyring = TRUE
#      )
#  

## ----eval=FALSE---------------------------------------------------------------
#  
#  resultDatabaseDetails <- list(
#        dbms = 'sqlite',
#        tablePrefix = 'cm_',
#        cohortTablePrefix = 'cg_',
#        databaseTablePrefix = '',
#        schema = 'main',
#        databaseTable = 'DATABASE_META_DATA'
#      )
#  
#  cohortMethodModule <- createDefaultEstimationConfig(
#        resultDatabaseDetails = resultDatabaseDetails,
#        useKeyring = TRUE
#      )
#  
#  cohortGeneratorModule <- createDefaultCohortGeneratorConfig()
#  

## ----eval=FALSE---------------------------------------------------------------
#  
#  library(dplyr)
#  shinyAppConfig <- initializeModuleConfig() %>%
#    addModuleConfig(aboutModule) %>%
#    addModuleConfig(cohortGeneratorModule) %>%
#    addModuleConfig(cohortMethodModule) %>%
#    addModuleConfig(predictionModule)
#  

## ----eval=FALSE---------------------------------------------------------------
#  # create a connection to the result database
#  connectionDetails <- DatabaseConnector::createConnectionDetails()
#  createShinyApp(shinyAppConfig, connectionDetails = connectionDetails)

## ----eval=FALSE---------------------------------------------------------------
#  # create a connection to the result database
#  connectionDetails <- DatabaseConnector::createConnectionDetails()
#  viewShiny(shinyAppConfig, connectionDetails = connectionDetails)

## ----eval=FALSE---------------------------------------------------------------
#  library(ShinyAppBuilder)
#  library(dplyr)
#  
#  aboutModule <- createModuleConfig(
#        moduleId = 'about',
#        tabName = "About",
#        shinyModulePackage = "OhdsiShinyModule",
#        moduleUiFunction = 'aboutViewer',
#        moduleServerFunction = 'aboutServer',
#        moduleDatabaseConnectionKeyService = NULL,
#        moduleDatabaseConnectionKeyUsername = NULL,
#        moduleInfoBoxFile =  "aboutHelperFile()",
#        moduleIcon = 'info',
#        resultDatabaseDetails = NULL,
#        useKeyring = TRUE
#      )
#  
#  resultDatabaseDetails <- list(
#        dbms = 'sqlite',
#        tablePrefix = 'plp_',
#        cohortTablePrefix = 'cg_',
#        databaseTablePrefix = '',
#        schema = 'main',
#        databaseTable = 'DATABASE_META_DATA'
#      )
#  
#  predictionModule <- createModuleConfig(
#      moduleId = 'prediction',
#      tabName = "Prediction",
#      shinyModulePackage = 'OhdsiShinyModules',
#      moduleUiFunction = "predictionViewer",
#      moduleServerFunction = "predictionServer",
#      moduleDatabaseConnectionKeyService ="resultDatabaseDetails",
#      moduleDatabaseConnectionKeyUsername = "prediction",
#      moduleInfoBoxFile =  "predictionHelperFile()",
#      moduleIcon = "chart-line",
#      resultDatabaseDetails = resultDatabaseDetails,
#      useKeyring = TRUE
#      )
#  
#  resultDatabaseDetails <- list(
#        dbms = 'sqlite',
#        tablePrefix = 'cm_',
#        cohortTablePrefix = 'cg_',
#        databaseTablePrefix = '',
#        schema = 'main',
#        databaseTable = 'DATABASE_META_DATA'
#      )
#  
#  cohortMethodModule <- createDefaultEstimationConfig(
#        resultDatabaseDetails = resultDatabaseDetails,
#        useKeyring = TRUE
#      )
#  
#  cohortGeneratorModule <- createDefaultCohortGeneratorConfig()
#  
#  
#  # add the modules into a single shiny config
#  shinyAppConfig <- initializeModuleConfig() %>%
#    addModuleConfig(aboutModule) %>%
#    addModuleConfig(cohortGeneratorModule) %>%
#    addModuleConfig(cohortMethodModule) %>%
#    addModuleConfig(predictionModule)
#  
#  
#  # add connection details to result database
#  connectionDetails <- DatabaseConnector::createConnectionDetails()
#  viewShiny(shinyAppConfig, connectionDetails = connectionDetails)
#  

