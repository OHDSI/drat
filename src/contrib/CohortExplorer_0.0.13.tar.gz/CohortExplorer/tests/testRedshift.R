library(testthat)
# commenting out because the permissions to create table is available for the account
# options(dbms = "redshift")
# test_check("CohortExplorer")
