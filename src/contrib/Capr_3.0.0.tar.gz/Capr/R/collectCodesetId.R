# Utilities ---------------
getGuid <- function(x) {
  tibble::tibble(
    guid = as.character(x@conceptSet@id)
  )
}

replaceGuid <- function(x, y) {
  x@conceptSet@id <- y
  return(x)
}

# Recursively collect all data.frames from a list (e.g. nested lists from Group)
# without flattening data.frames. Used when CorrelatedCriteria has nested groups.
collect_dfs <- function(x) {
  if (is.data.frame(x)) {
    return(list(x))
  }
  if (!is.list(x)) {
    return(list())
  }
  out <- list()
  for (i in seq_along(x)) {
    out <- c(out, collect_dfs(x[[i]]))
  }
  out
}

# Collect Guid --------------------------

setGeneric("collectGuid", function(x) standardGeneric("collectGuid"))

setMethod("collectGuid", "conceptSetAttribute", function(x) {
  getGuid(x)
})

setMethod("collectGuid", "conceptAttribute", function(x) {
  return(NULL)
})

setMethod("collectGuid", "opAttributeSuper", function(x) {
  return(NULL)
})

setMethod("collectGuid", "valueAsStringAttribute", function(x) {
  return(NULL)
})

# setMethod("collectGuid", "Query", function(x) {
#   getGuid(x)
# })
#
# setMethod("collectGuid", "nestedAttribute", function(x) {
#   collectGuid(x@group)
# })

#' @include query.R
setMethod("collectGuid", "Query", function(x) {
  ids <- getGuid(x)

  #collect guids for nested attributes
  checkNest <- purrr::map_chr(x@attributes, ~as.character(.x@name))
  if (any(checkNest %in% c("CorrelatedCriteria"))) {
    ii <- which(checkNest == "CorrelatedCriteria")
    id2 <- collectGuid(x@attributes[[ii]]@group)
    # id2 can be nested lists of tibbles when group contains nested groups
    dfs <- collect_dfs(id2)
    if (length(dfs) > 0L) ids <- dplyr::bind_rows(ids, dfs)
  }
  
  # collect guids for conceptSetAttribute objects
  conceptSetAttrs <- purrr::keep(x@attributes, ~methods::is(.x, "conceptSetAttribute"))
  if (length(conceptSetAttrs) > 0) {
    conceptSetIds <- purrr::map_dfr(conceptSetAttrs, ~collectGuid(.x))
    ids <- dplyr::bind_rows(ids, conceptSetIds)
  }
  
  return(ids)

})

#' @include criteria.R
setMethod("collectGuid", "Criteria", function(x) {
  collectGuid(x@query)
})

#' @include criteria.R
setMethod("collectGuid", "Group", function(x) {
  purrr::map(x@criteria, ~collectGuid(.x)) |>
    append(purrr::map(x@group, ~collectGuid(.x)))
})


setMethod("collectGuid", "CohortEntry", function(x) {
  purrr::map(x@entryEvents, ~collectGuid(.x)) |>
    append(collectGuid(x@additionalCriteria))
  #TODO may need a flatten here with additional criteria
})

setMethod("collectGuid", "CohortAttrition", function(x) {
  purrr::map(unname(x@rules), ~collectGuid(.x)) |>
    purrr::flatten()
})

setMethod("collectGuid", "CohortExit", function(x) {
  #check if endstrategy is drug exit
  es_nm_check <- "conceptSet" %in% methods::slotNames(methods::is(x@endStrategy))
  if (es_nm_check) {
    #get concept sets from drug exit
    ll <- list(getGuid(x@endStrategy))
  } else {
    ll <- list()
  }
  append(ll, purrr::map(x@censoringCriteria@criteria, ~collectGuid(.x)))

})

setMethod("collectGuid", "Cohort", function(x) {

  tt <- collectGuid(x@entry) |>
    append(collectGuid(x@attrition)) |>
    append(collectGuid(x@exit)) |>
    unlist() |>
    unname() |>
    unique()

  tb <- tibble::tibble(guid = tt) |>
    dplyr::mutate(
      codesetId = dplyr::row_number() - 1,
      codesetId = as.integer(.data$codesetId)
    )

  return(tb)
})

# Replace CodesetId -----------------------
## TODO HASH table implementation of find/replace
setGeneric("replaceCodesetId", function(x, guidTable) standardGeneric("replaceCodesetId"))

setMethod("replaceCodesetId", "conceptSetAttribute", function(x, guidTable) {
  
  if (nrow(getGuid(x)) > 0) {
    y <- getGuid(x) |>
      dplyr::inner_join(guidTable, by = c("guid")) |>
      dplyr::pull(.data$codesetId)
  } else {
    y <- NULL
  }
  
  x <- replaceGuid(x, y)
  
  return(x)
})

setMethod("replaceCodesetId", "conceptAttribute", function(x, guidTable) {
  return(x)
})

setMethod("replaceCodesetId", "opAttributeSuper", function(x, guidTable) {
  return(x)
})


setMethod("replaceCodesetId", "Query", function(x, guidTable) {

  if (nrow(getGuid(x)) > 0) {
    y <- getGuid(x) |>
      dplyr::inner_join(guidTable, by = c("guid")) |>
      dplyr::pull(.data$codesetId)
  } else {
    y <- NULL
  }

  #first replace the query id
  x <- replaceGuid(x, y)

  #next check for any nested criteria and replace
  #replace guids for nested attributes
  checkNest <- purrr::map_chr(x@attributes, ~as.character(.x@name))
  if (any(checkNest %in% c("CorrelatedCriteria"))) {
    ii <- which(checkNest == "CorrelatedCriteria")
    nest <- replaceCodesetId(x@attributes[[ii]]@group, guidTable)

    x@attributes[[ii]]@group <- nest
  }
  
  # replace codeset ids for conceptSetAttribute objects
  conceptSetAttrIndices <- which(purrr::map_lgl(x@attributes, ~methods::is(.x, "conceptSetAttribute")))
  if (length(conceptSetAttrIndices) > 0) {
    for (i in conceptSetAttrIndices) {
      x@attributes[[i]] <- replaceCodesetId(x@attributes[[i]], guidTable)
    }
  }

  return(x)
})

setMethod("replaceCodesetId", "DrugExposureExit", function(x, guidTable) {

  y <- getGuid(x) |>
    dplyr::inner_join(guidTable, by = c("guid")) |>
    dplyr::pull(.data$codesetId)

  x <- replaceGuid(x, y)

  return(x)
})



setMethod("replaceCodesetId", "Criteria", function(x, guidTable) {

  x@query <- replaceCodesetId(x@query, guidTable = guidTable)

  return(x)
})


setMethod("replaceCodesetId", "Group", function(x, guidTable) {
  crit <- purrr::map(x@criteria, ~replaceCodesetId(.x, guidTable))
  grp <- purrr::map(x@group, ~replaceCodesetId(.x, guidTable))

  x@criteria <- crit
  x@group <- grp

  return(x)
})


setMethod("replaceCodesetId", "CohortEntry", function(x, guidTable) {
  pc <- purrr::map(x@entryEvents, ~replaceCodesetId(.x, guidTable))
  ac <- replaceCodesetId(x@additionalCriteria, guidTable)

  x@entryEvents <- pc
  x@additionalCriteria <- ac
  return(x)

})

setMethod("replaceCodesetId", "CohortAttrition", function(x, guidTable = guidTable) {
  irs <- purrr::map(x@rules, ~replaceCodesetId(.x, guidTable))
  x@rules <- irs
  return(x)
})


setMethod("replaceCodesetId", "CohortExit", function(x, guidTable = guidTable) {
  #check if endstrategy is drug exit
  es_nm_check <- "conceptSet" %in% methods::slotNames(methods::is(x@endStrategy))
  if (es_nm_check) {
    #get concept sets from drug exit
    es <- replaceCodesetId(x@endStrategy, guidTable = guidTable)
    x@endStrategy <- es
  }
  # Censoring Events replace
  cen <- purrr::map(x@censoringCriteria@criteria, ~replaceCodesetId(.x, guidTable))
  x@censoringCriteria@criteria <- cen
  return(x)

})


setMethod("replaceCodesetId", "Cohort", function(x, guidTable = guidTable) {

  x@entry <- replaceCodesetId(x@entry, guidTable = guidTable)
  x@attrition <- replaceCodesetId(x@attrition, guidTable = guidTable)
  x@exit <- replaceCodesetId(x@exit, guidTable = guidTable)

  return(x)
})

# list Concept Set ------------------

# Invariant: every listConceptSets() method returns a FLAT list of concept sets,
# where each concept set is a named list with id/name/expression. Leaf methods
# wrap a single set in list(...); container methods concatenate their children's
# flat lists with a single unconditional flatten -- never guess shape (regression
# guard for issue #123, where a single-element outer nest returned an empty list).
setGeneric("listConceptSets", function(x) standardGeneric("listConceptSets"))

setMethod("listConceptSets", "conceptSetAttribute", function(x) {
  list(as.list(x@conceptSet))
})

setMethod("listConceptSets", "conceptAttribute", function(x) {
  return(NULL)
})

setMethod("listConceptSets", "opAttributeSuper", function(x) {
  return(NULL)
})


#' @include query.R
setMethod("listConceptSets", "Query", function(x) {
  qs <- as.list(x@conceptSet)

  # handle listing concepts if have nestedAttribute
  #next check for any nested criteria and replace
  #replace guids for nested attributes
  checkNest <- purrr::map_chr(x@attributes, ~as.character(.x@name))
  if (any(checkNest %in% c("CorrelatedCriteria"))) {
    ii <- which(checkNest == "CorrelatedCriteria")
    nest <- listConceptSets(x@attributes[[ii]]@group)
    out <- c(list(qs), nest)
  } else {
    out <- list(qs)
  }
  
  # handle listing concept sets from conceptSetAttribute objects
  conceptSetAttrs <- purrr::keep(x@attributes, ~methods::is(.x, "conceptSetAttribute"))
  if (length(conceptSetAttrs) > 0) {
    conceptSetsFromAttrs <- purrr::list_flatten(
      purrr::map(conceptSetAttrs, ~listConceptSets(.x))
    )
    out <- c(out, conceptSetsFromAttrs)
  }

  return(out)
})

#' @include criteria.R
setMethod("listConceptSets", "Criteria", function(x) {
 listConceptSets(x@query)
})

#' @include criteria.R
setMethod("listConceptSets", "Group", function(x) {

  # Every child method returns a flat list of concept sets (see invariant above),
  # so a single unconditional flatten is always correct -- no shape-guessing.
  ll1 <- purrr::list_flatten(purrr::map(x@criteria, ~listConceptSets(.x)))
  ll2 <- purrr::list_flatten(purrr::map(x@group, ~listConceptSets(.x)))

  c(ll1, ll2)
})

setMethod("listConceptSets", "CohortEntry", function(x) {

  # listConceptSets() on each entryEvent (Query/Group) already returns a flat
  # list of id-lists, so flatten unconditionally across entryEvents rather than
  # guessing from list length (a per-entryEvent length coincidentally matching
  # some other entryEvent's length previously caused this to skip flattening
  # entirely, silently dropping every concept set - see test-collectCodesetId.R).
  ce <- purrr::map(x@entryEvents, ~listConceptSets(.x)) |>
    purrr::flatten()

  ce |>
    append(listConceptSets(x@additionalCriteria))
})

setMethod("listConceptSets", "CohortAttrition", function(x) {
  purrr::map(unname(x@rules), ~listConceptSets(.x)) |>
    purrr::list_flatten()
})

setMethod("listConceptSets", "CohortExit", function(x) {
  # check if endstrategy is drug exit
  es_nm_check <- "conceptSet" %in% methods::slotNames(methods::is(x@endStrategy))
  if (es_nm_check) {
    # get concept sets from drug exit
    ll <- list(as.list(x@endStrategy@conceptSet))
  } else {
    ll <- list()
  }
  # get concept sets from censoring criteria
  ll2 <- purrr::map(x@censoringCriteria@criteria,
                    ~listConceptSets(.x) |>
                      purrr::flatten())

  res <- append(ll, ll2)
  return(res)
})

setMethod("listConceptSets", "Cohort", function(x) {
  l1 <- listConceptSets(x@entry)
  l2 <- listConceptSets(x@attrition)
  l3 <- listConceptSets(x@exit)
  ll <- c(l1, l2, l3) |>
    .removeNullId()

  # Drop elements with no id or length != 1 (e.g. from nested groups)
  ll <- purrr::keep(ll, function(x) length(x$id) == 1L)
  ids <- purrr::map_chr(ll, ~as.character(.x$id))

  # Warn when same-content concept sets with different names are silently merged
  dup_idx <- which(duplicated(ids))
  for (i in dup_idx) {
    kept_name  <- ll[[which(ids == ids[[i]])[[1]]]]$name
    dropped_name <- ll[[i]]$name
    if (!identical(kept_name, dropped_name)) {
      cli::cli_warn(c(
        "Concept sets {.val {dropped_name}} and {.val {kept_name}} have identical contents and were merged.",
        "i" = "{.val {dropped_name}} was dropped; {.val {kept_name}} was kept."
      ))
    }
  }

  rr <- ll[!duplicated(ids)]
  return(rr)
})


.removeNullId <- function(ll) {
  idToDrop <- purrr::map_lgl(ll, ~is.null(.x$id)) |>
    which()
  if (length(idToDrop) == 0) {
    ll2 <- ll
  } else {
    ll2 <- ll[-c(idToDrop)]
  }

  return(ll2)
}

# Collect (id, attributeName) for every conceptSetAttribute in the cohort.
# Used to exclude ValueAsConcept-only concept sets from ConceptSets when we inline them.
setGeneric("collectConceptSetAttributeUsage", function(x) standardGeneric("collectConceptSetAttributeUsage"))

setMethod("collectConceptSetAttributeUsage", "conceptSetAttribute", function(x) {
  list(list(id = x@conceptSet@id, name = x@name))
})
setMethod("collectConceptSetAttributeUsage", "conceptAttribute", function(x) list())
setMethod("collectConceptSetAttributeUsage", "opAttributeSuper", function(x) list())

setMethod("collectConceptSetAttributeUsage", "Query", function(x) {
  out <- list()
  checkNest <- purrr::map_chr(x@attributes, ~as.character(.x@name))
  if (any(checkNest %in% c("CorrelatedCriteria"))) {
    ii <- which(checkNest == "CorrelatedCriteria")
    out <- c(out, collectConceptSetAttributeUsage(x@attributes[[ii]]@group))
  }
  conceptSetAttrs <- purrr::keep(x@attributes, ~methods::is(.x, "conceptSetAttribute"))
  if (length(conceptSetAttrs) > 0) {
    out <- c(out, purrr::list_flatten(purrr::map(conceptSetAttrs, collectConceptSetAttributeUsage)))
  }
  out
})
setMethod("collectConceptSetAttributeUsage", "Criteria", function(x) collectConceptSetAttributeUsage(x@query))

setMethod("collectConceptSetAttributeUsage", "Group", function(x) {
  a <- purrr::map(x@criteria, collectConceptSetAttributeUsage)
  b <- purrr::map(x@group, collectConceptSetAttributeUsage)
  purrr::list_flatten(c(a, b))
})
setMethod("collectConceptSetAttributeUsage", "CohortEntry", function(x) {
  ce <- purrr::map(x@entryEvents, collectConceptSetAttributeUsage)
  purrr::list_flatten(c(ce, list(collectConceptSetAttributeUsage(x@additionalCriteria))))
})
setMethod("collectConceptSetAttributeUsage", "CohortAttrition", function(x) {
  purrr::list_flatten(purrr::map(unname(x@rules), collectConceptSetAttributeUsage))
})
setMethod("collectConceptSetAttributeUsage", "CohortExit", function(x) {
  purrr::list_flatten(purrr::map(x@censoringCriteria@criteria, collectConceptSetAttributeUsage))
})
setMethod("collectConceptSetAttributeUsage", "Cohort", function(x) {
  purrr::list_flatten(list(
    collectConceptSetAttributeUsage(x@entry),
    collectConceptSetAttributeUsage(x@attrition),
    collectConceptSetAttributeUsage(x@exit)
  ))
})
