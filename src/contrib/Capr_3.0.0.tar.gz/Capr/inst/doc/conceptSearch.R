## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  eval = FALSE
)

## ----setup--------------------------------------------------------------------
# library(Capr)

## ----connect------------------------------------------------------------------
# connection <- DatabaseConnector::connect(
#   Eunomia::getEunomiaConnectionDetails()
# )
# vocabularyDatabaseSchema <- "main"

## ----connect-full, eval=FALSE-------------------------------------------------
# connectionDetails <- DatabaseConnector::createConnectionDetails(
#   dbms = "postgresql",
#   server = "your-server/cdm",
#   user = "user",
#   password = "password"
# )
# connection <- DatabaseConnector::connect(connectionDetails)
# vocabularyDatabaseSchema <- "cdm_vocab"

## ----search-basic-------------------------------------------------------------
# # Find standard condition concepts matching "atrial fibrillation"
# results <- searchConcepts(
#   "atrial fibrillation",
#   connection,
#   vocabularyDatabaseSchema = vocabularyDatabaseSchema
# )
# results

## ----search-filtered----------------------------------------------------------
# # Only drug concepts, include non-standard (source codes)
# searchConcepts(
#   "metformin",
#   connection,
#   vocabularyDatabaseSchema = vocabularyDatabaseSchema,
#   domain = "Drug",
#   standardOnly = FALSE,
#   limit = 20L
# )

## ----fast-search--------------------------------------------------------------
# results <- rankedSearchConcepts(
#   "atrial fibrillation",
#   connection,
#   vocabularyDatabaseSchema = vocabularyDatabaseSchema,
#   limit = 20L
# )
# # Results include relevance score and mapping_count
# results[, c("concept_id", "concept_name", "relevance", "mapping_count")]

## ----fast-search-page---------------------------------------------------------
# # Second page
# rankedSearchConcepts(
#   "atrial fibrillation",
#   connection,
#   vocabularyDatabaseSchema = vocabularyDatabaseSchema,
#   limit = 20L,
#   offset = 0L
# )

## ----descendants--------------------------------------------------------------
# # All descendants of "Atrial Fibrillation" (313217)
# afib_desc <- getConceptDescendants(
#   313217L,
#   connection,
#   vocabularyDatabaseSchema = vocabularyDatabaseSchema
# )
# afib_desc

## ----descendants-depth--------------------------------------------------------
# # Direct children only (level 1)
# getConceptDescendants(
#   313217L,
#   connection,
#   vocabularyDatabaseSchema = vocabularyDatabaseSchema,
#   minLevels = 1L,
#   maxLevels = 1L
# )

## ----map-source---------------------------------------------------------------
# # Map ICD-10 atrial fibrillation codes to standard concepts
# mapSourceToStandard(
#   c("I48", "I48.0", "I48.1"),
#   connection,
#   vocabularyDatabaseSchema = vocabularyDatabaseSchema,
#   vocabularyId = "ICD10CM"
# )

## ----concept-info-------------------------------------------------------------
# getConceptInfo(
#   c(313217L, 320128L, 201826L),
#   connection,
#   vocabularyDatabaseSchema = vocabularyDatabaseSchema
# )

## ----workflow-----------------------------------------------------------------
# # 1. Find the right concept ID
# results <- rankedSearchConcepts(
#   "atrial fibrillation",
#   connection,
#   vocabularyDatabaseSchema = vocabularyDatabaseSchema,
#   domain = "Condition"
# )
# # Inspect results - concept 313217 is "Atrial fibrillation"
# 
# # 2. Build a concept set with all descendants
# afib_cs <- cs(descendants(313217L), name = "Atrial Fibrillation")
# 
# # 3. Optionally fill in display names for Atlas
# afib_cs <- getConceptSetDetails(
#   afib_cs,
#   connection,
#   vocabularyDatabaseSchema = vocabularyDatabaseSchema
# )
# 
# # 4. Build the cohort
# afib_cohort <- cohort(
#   entry = entry(
#     conditionOccurrence(afib_cs),
#     primaryCriteriaLimit = "First"
#   ),
#   exit = exit(endStrategy = observationExit())
# )
# 
# # 5. Serialize to JSON
# toCohortJson(afib_cohort)

## ----disconnect---------------------------------------------------------------
# DatabaseConnector::disconnect(connection)

