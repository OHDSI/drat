## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  eval = FALSE
)

## -----------------------------------------------------------------------------
# library(Capr)

## -----------------------------------------------------------------------------
# jsonPath <- "cohort.json"
# 
# caprCode <- jsonToCapr(jsonPath, mode = "strict")
# cat(caprCode)

## -----------------------------------------------------------------------------
# outRPath <- "cohort_from_atlas.R"
# 
# jsonToCaprFile(
#   jsonPath = jsonPath,
#   outRPath = outRPath,
#   mode = "strict"
# )

## -----------------------------------------------------------------------------
# source(outRPath)
# 
# # cohortDef should now exist in your environment
# cohortJson <- toCohortJson(cohortDef)

## -----------------------------------------------------------------------------
# sql <- CirceR::buildCohortQuery(
#   expression = CirceR::cohortExpressionFromJson(cohortJson),
#   options = CirceR::createGenerateOptions(generateStats = FALSE)
# )
# 
# nchar(sql) > 0

## -----------------------------------------------------------------------------
# caprCodeSkip <- jsonToCapr(jsonPath, mode = "skip")
# cat(caprCodeSkip)

## -----------------------------------------------------------------------------
# result <- jsonToCapr(
#   jsonPath = jsonPath,
#   mode = "skip",
#   returnSkipped = TRUE
# )
# 
# names(result)
# # [1] "lines" "skipped" "emptyGroupWarnings"
# 
# result$skipped

