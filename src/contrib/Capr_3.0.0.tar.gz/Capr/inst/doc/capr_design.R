## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  eval = FALSE
)

## ----setup--------------------------------------------------------------------
# library(Capr)

## ----cs-----------------------------------------------------------------------
# cs(descendants(201826L), name = "T2D")
# cs(201826L, 201254L, name = "Diabetes")

## ----cohort-fn----------------------------------------------------------------
# cohort(entry, attrition, exit, era)

## ----query--------------------------------------------------------------------
# visit(conceptSet, ...)
# conditionOccurrence(conceptSet, ...)
# 

## ----attr---------------------------------------------------------------------
# conditionOccurrence(cs(descendants(201826L), name = "T2D"), male())
# conditionOccurrence(cs(descendants(201826L), name = "T2D"), age(gte(18)))
# conditionOccurrence(cs(descendants(201826L), name = "T2D"), firstOccurrence())
# 

## ----criteria-----------------------------------------------------------------
# exactly(0,
#   query = conditionOccurrence(cs(descendants(201826L), name = "T2D")),
#         aperture = duringInterval(eventStarts(-Inf, -1))
#         )

## ----group--------------------------------------------------------------------
# withAny(
#   atLeast(1, query = abLabHb, aperture = ap1),
#   atLeast(1, query = abLabRan, aperture = ap1),
#   atLeast(1, query = abLabFast, aperture = ap1)
# )

## ----inspect, eval = FALSE----------------------------------------------------
# t2dm <- cs(descendants(201826L), name = "T2DM")
# hf   <- cs(descendants(316139L), name = "Heart failure")
# 
# cd <- cohort(
#   entry = entry(
#     conditionOccurrence(t2dm, male()),
#     conditionOccurrence(hf, nestedWithAll(atLeast(1, conditionOccurrence(hf))))
#   ),
#   exit = exit(endStrategy = fixedExit(offsetDays = 30L))
# )
# 
# cd                                    # compact overview (calls show())
# summary(cd)                           # fuller view, expands nested criteria
# summary(cd, listConceptSets = TRUE)   # also lists concept sets (id + logic)

