## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)

## ---- echo = TRUE, message = FALSE, warning = FALSE,tidy=FALSE,eval=FALSE-----
#  install.packages("remotes")
#  remotes::install_github("OHDSI/FeatureExtraction")
#  remotes::install_github("OHDSI/PatientLevelPrediction")
#  remotes::install_github("OHDSI/DeepPatientLevelPrediction")

## ---- echo = TRUE, message = FALSE, warning = FALSE,tidy=FALSE,eval=FALSE-----
#  library(PatientLevelPrediction)
#  library(DeepPatientLevelPrediction)
#  
#  data(plpDataSimulationProfile)
#  sampleSize <- 1e4
#  plpData <- simulatePlpData(
#    plpDataSimulationProfile,
#    n = sampleSize
#  )
#  
#  populationSettings <- PatientLevelPrediction::createStudyPopulationSettings(
#                                                            requireTimeAtRisk = F,
#                                                            riskWindowStart = 1,
#                                                            riskWindowEnd = 365)
#  # a very simple resnet
#  modelSettings <- setResNet(numLayers = 2,
#                             sizeHidden = 64,
#                             hiddenFactor = 1,
#                             residualDropout = 0,
#                             hiddenDropout = 0.2,
#                             sizeEmbedding = 64,
#                             estimatorSettings = setEstimator(learningRate = 3e-4,
#                                                              weightDecay = 1e-6,
#                                                              device='cpu',
#                                                              batchSize=128,
#                                                              epochs=3,
#                                                              seed = 42),
#                             hyperParamSearch = 'random',
#                             randomSample = 1)
#  
#  plpResults <- PatientLevelPrediction::runPlp(plpData = plpData,
#                 outcomeId = 3,
#                 modelSettings = modelSettings,
#                 analysisId = 'Test',
#                 analysisName = 'Testing DeepPlp',
#                 populationSettings = populationSettings,
#                 splitSettings = createDefaultSplitSetting(),
#                 sampleSettings = createSampleSettings(),
#                 featureEngineeringSettings = createFeatureEngineeringSettings(),
#                 preprocessSettings = createPreprocessSettings(),
#                 logSettings = createLogSettings(),
#                 executeSettings = createExecuteSettings(runSplitData = T,
#                                                        runSampleData = F,
#                                                        runfeatureEngineering = F,
#                                                        runPreprocessData = T,
#                                                        runModelDevelopment = T,
#                                                        runCovariateSummary = T
#                                                        ))

## ----tidy=TRUE,eval=TRUE------------------------------------------------------
citation("DeepPatientLevelPrediction")

