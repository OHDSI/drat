select cast(%d as int) as target_cohort_definition_id, 
	cast ('%s' as varchar(255)) as target_name