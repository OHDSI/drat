structure(list(url = "http://atlas-dev.ohdsi.org/WebAPI/cohortdefinition/sql/", 
    status_code = 500L, headers = structure(list(vary = "Accept-Encoding", 
        `content-encoding` = "gzip", `content-type` = "application/json", 
        `content-length` = "203", date = "Fri, 16 Jul 2021 19:37:29 GMT", 
        connection = "close"), class = c("insensitive", "list"
    )), all_headers = list(list(status = 500L, version = "HTTP/1.1", 
        headers = structure(list(vary = "Accept-Encoding", `content-encoding` = "gzip", 
            `content-type` = "application/json", `content-length` = "203", 
            date = "Fri, 16 Jul 2021 19:37:29 GMT", connection = "close"), class = c("insensitive", 
        "list")))), cookies = structure(list(domain = logical(0), 
        flag = logical(0), path = logical(0), secure = logical(0), 
        expiration = structure(numeric(0), class = c("POSIXct", 
        "POSIXt")), name = logical(0), value = logical(0)), row.names = integer(0), class = "data.frame"), 
    content = charToRaw("{\"payload\":{\"cause\":null,\"stackTrace\":[],\"message\":\"An exception occurred: java.lang.NullPointerException\",\"localizedMessage\":\"An exception occurred: java.lang.NullPointerException\",\"suppressed\":[]},\"headers\":{\"id\":\"8df1a9ed-cbe2-1651-17cd-81bf068b4713\",\"timestamp\":1626464250512}}"), 
    date = structure(1626464249, class = c("POSIXct", "POSIXt"
    ), tzone = "GMT"), times = c(redirect = 0, namelookup = 2.3e-05, 
    connect = 2.4e-05, pretransfer = 6.8e-05, starttransfer = 0.021824, 
    total = 0.021888)), class = "response")
