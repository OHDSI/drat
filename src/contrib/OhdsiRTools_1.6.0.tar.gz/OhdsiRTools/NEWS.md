OhdsiRTools v1.6.0
==================

Deprecating logging and parallel computation functions, which have been moved to ParallelLogger.


OhdsiRTools v1.5.5
==================

Changes: initial submission to CRAN.
