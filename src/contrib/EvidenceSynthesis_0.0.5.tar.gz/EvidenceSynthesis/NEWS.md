EvidenceSynthesis 0.0.5
=======================

Bug fixes

1. Fixing build error in R 4.0.0.