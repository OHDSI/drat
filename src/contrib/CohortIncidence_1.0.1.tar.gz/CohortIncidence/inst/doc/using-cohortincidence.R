## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  error = FALSE,
  comment = "#>"
)

## ---- setup, echo=FALSE-------------------------------------------------------
library(CohortIncidence)

## ----eval=FALSE---------------------------------------------------------------
#  install.packages("remotes")
#  remotes::install_github("ohdsi/CohortIncidence")

## ---- comment = ""------------------------------------------------------------
# Fetch DDL from package
ddl <- CohortIncidence::getResultsDdl();
cat(ddl)

## ---- eval = FALSE------------------------------------------------------------
#  connectionDetails <- DatabaseConnector::createConnectionDetails(dbms = "postgresql",server={Sys.getenv("server")}, port = Sys.getenv("port"));
#  
#  # to specify the target schema (the typical use case):
#  ddl <- SqlRender::render(CohortIncidence::getResultsDdl(), schemaName = "mySchema");
#  
#  # a work-around to provide a prefix to the result table, in case creating new schema is restricted
#  ddlPrefix <- SqlRender::render(CohortIncidence::getResultsDdl(), "schemaName.incidence_summary" = "mySchema.prefix_incidence_summary");
#  
#  con <- DatabaseConnector::connect(connectionDetails);
#  DatabaseConnector::executeSql(ddl);
#  DatabaseConnector::disconnect(con);
#  

## -----------------------------------------------------------------------------
t1 <- CohortIncidence::createCohortRef(id=1, name="Target cohort 1");

o1 <- CohortIncidence::createOutcomeDef(id=1,name="Outcome 1, 30d Clean", 
                                               cohortId =2,
                                               cleanWindow =30);

tar1 <- CohortIncidence::createTimeAtRiskDef(id=1, 
                                             startDateField="StartDate", 
                                             endDateField="StartDate", 
                                             endOffset=30);

# Note: c() is used when dealing with an array of numbers, 
# later we use list() when dealing with an array of objects
analysis1 <- CohortIncidence::createIncidenceAnalysis(targets = c(t1$id),
                                                      outcomes = c(o1$id),
                                                      tars = c(tar1$id));

subgroup1 <- CohortIncidence::createCohortSubgroup(id=1, name="Subgroup 1", cohortRef = createCohortRef(id=300));


# Create Design (note use of list() here):
irDesign <- CohortIncidence::createIncidenceDesign(targetDefs = list(t1),
                                                   outcomeDefs = list(o1),
                                                   tars=list(tar1),
                                                   analysisList = list(analysis1),
                                                   subgroups = list(subgroup1));
# Render the design as JSON
jsonlite::toJSON(irDesign,pretty = T)


## -----------------------------------------------------------------------------

buildOptions <- CohortIncidence::buildOptions(cohortTable = "demoCohortSchema.cohort",
                                              cdmSchema = "mycdm",
                                              resultsSchema = "myresults",
                                              refId = 1)

analysisSql <- CohortIncidence::buildQuery(incidenceDesign =  as.character(jsonlite::toJSON(irDesign)),
                                           buildOptions = buildOptions);
cat(analysisSql)


