select cast(%d as int) as time_at_risk_id, 
	cast (%d as int) as time_at_risk_start_index, cast (%d as int) as time_at_risk_start_offset,
	cast (%d as int) as time_at_risk_end_index, cast (%d as int) as time_at_risk_end_offset