package org.ohdsi.cohortincidence;

/**
 *
 * @author cknoll1
 */
public class TestParams {
	public String resultSchema;
	public String[] prepDataSets;
	public String designJson;
	public String[] verifyDataSets;
}
