## ---- echo = FALSE, message = FALSE, warning = FALSE---------------------
library(CohortMethod)
knitr::opts_chunk$set(
  cache=FALSE,
  comment = "#>",
  error = FALSE,
  tidy = FALSE)

## ----tidy=TRUE,eval=FALSE------------------------------------------------
#  install.packages("drat")
#  drat::addRepo("OHDSI")
#  install.packages("CohortMethod")

## ----tidy=FALSE,eval=FALSE-----------------------------------------------
#  connectionDetails <- createConnectionDetails(dbms = "postgresql",
#                                               server = "localhost/ohdsi",
#                                               user = "joe",
#                                               password = "supersecret")
#  
#  cdmDatabaseSchema <- "my_cdm_data"
#  resultsDatabaseSchema <- "my_results"
#  cdmVersion <- "5"

## ----tidy=FALSE,eval=FALSE-----------------------------------------------
#  library(SqlRender)
#  sql <- readSql("coxibVsNonselVsGiBleed.sql")
#  sql <- renderSql(sql,
#                   cdmDatabaseSchema = cdmDatabaseSchema,
#                   resultsDatabaseSchema = resultsDatabaseSchema)$sql
#  sql <- translateSql(sql, targetDialect = connectionDetails$dbms)$sql
#  
#  connection <- connect(connectionDetails)
#  executeSql(connection, sql)

## ----tidy=FALSE,eval=FALSE-----------------------------------------------
#  sql <- paste("SELECT cohort_definition_id, COUNT(*) AS count",
#               "FROM @resultsDatabaseSchema.coxibVsNonselVsGiBleed",
#               "GROUP BY cohort_definition_id")
#  sql <- renderSql(sql, resultsDatabaseSchema = resultsDatabaseSchema)$sql
#  sql <- translateSql(sql, targetDialect = connectionDetails$dbms)$sql
#  
#  querySql(connection, sql)

## ----echo=FALSE,message=FALSE--------------------------------------------
data.frame(cohort_concept_id = c(1,2,3),count=c(149403,541152,552708))

## ----tidy=FALSE,eval=FALSE-----------------------------------------------
#  nsaids <- 21603933
#  
#  # Define which types of covariates must be constructed:
#  covariateSettings <- createCovariateSettings(useCovariateDemographics = TRUE,
#                                               useCovariateDemographicsAge = TRUE,
#                                               useCovariateDemographicsGender = TRUE,
#                                               useCovariateDemographicsRace = TRUE,
#                                               useCovariateDemographicsEthnicity = TRUE,
#                                               useCovariateDemographicsYear = TRUE,
#                                               useCovariateDemographicsMonth = TRUE,
#                                               useCovariateConditionOccurrence = TRUE,
#                                               useCovariateConditionOccurrenceLongTerm = TRUE,
#                                               useCovariateConditionOccurrenceShortTerm = TRUE,
#                                               useCovariateConditionOccurrenceInptMediumTerm = TRUE,
#                                               useCovariateConditionEra = TRUE,
#                                               useCovariateConditionEraEver = TRUE,
#                                               useCovariateConditionEraOverlap = TRUE,
#                                               useCovariateConditionGroup = TRUE,
#                                               useCovariateDrugExposure = TRUE,
#                                               useCovariateDrugExposureLongTerm = TRUE,
#                                               useCovariateDrugExposureShortTerm = TRUE,
#                                               useCovariateDrugEra = TRUE,
#                                               useCovariateDrugEraLongTerm = TRUE,
#                                               useCovariateDrugEraShortTerm = TRUE,
#                                               useCovariateDrugEraEver = TRUE,
#                                               useCovariateDrugEraOverlap = TRUE,
#                                               useCovariateDrugGroup = TRUE,
#                                               useCovariateProcedureOccurrence = TRUE,
#                                               useCovariateProcedureOccurrenceLongTerm = TRUE,
#                                               useCovariateProcedureOccurrenceShortTerm = TRUE,
#                                               useCovariateProcedureGroup = TRUE,
#                                               useCovariateObservation = TRUE,
#                                               useCovariateObservationLongTerm = TRUE,
#                                               useCovariateObservationShortTerm = TRUE,
#                                               useCovariateObservationCountLongTerm = TRUE,
#                                               useCovariateMeasurementLongTerm = TRUE,
#                                               useCovariateMeasurementShortTerm = TRUE,
#                                               useCovariateMeasurementCountLongTerm = TRUE,
#                                               useCovariateMeasurementBelow = TRUE,
#                                               useCovariateMeasurementAbove = TRUE,
#                                               useCovariateConceptCounts = TRUE,
#                                               useCovariateRiskScores = TRUE,
#                                               useCovariateRiskScoresCharlson = TRUE,
#                                               useCovariateRiskScoresDCSI = TRUE,
#                                               useCovariateRiskScoresCHADS2 = TRUE,
#                                               useCovariateInteractionYear = FALSE,
#                                               useCovariateInteractionMonth = FALSE,
#                                               longTermDays = 365,
#                                               mediumTermDays = 180,
#                                               shortTermDays = 30,
#                                               excludedCovariateConceptIds = nsaids,
#                                               addDescendantsToExclude = TRUE,
#                                               deleteCovariatesSmallCount = 100)
#  
#  #Load data:
#  cohortMethodData <- getDbCohortMethodData(connectionDetails = connectionDetails,
#                                            cdmDatabaseSchema = cdmDatabaseSchema,
#                                            oracleTempSchema = resultsDatabaseSchema,
#                                            targetId = 1,
#                                            comparatorId = 2,
#                                            outcomeIds = 3,
#                                            studyStartDate = "",
#                                            studyEndDate = "",
#                                            exposureDatabaseSchema = resultsDatabaseSchema,
#                                            exposureTable = "coxibVsNonselVsGiBleed",
#                                            outcomeDatabaseSchema = resultsDatabaseSchema,
#                                            outcomeTable = "coxibVsNonselVsGiBleed",
#                                            cdmVersion = cdmVersion,
#                                            excludeDrugsFromCovariates = FALSE,
#                                            firstExposureOnly = TRUE,
#                                            removeDuplicateSubjects = TRUE,
#                                            restrictToCommonPeriod = FALSE,
#                                            washoutPeriod = 180,
#                                            covariateSettings = covarSettings)
#  cohortMethodData

## ----echo=FALSE,message=FALSE,eval=TRUE----------------------------------
if (file.exists("s:/temp/cohortMethodVignette/cohortMethodData")){
  cohortMethodData <- loadCohortMethodData("s:/temp/cohortMethodVignette/cohortMethodData")
} 

## ----echo=FALSE,message=FALSE--------------------------------------------
if (file.exists("s:/temp/cohortMethodVignette/cohortMethodData")){
  cohortMethodData
}

## ----tidy=TRUE,eval=FALSE------------------------------------------------
#  summary(cohortMethodData)

## ----echo=FALSE,message=FALSE--------------------------------------------
if (file.exists("s:/temp/cohortMethodVignette/cohortMethodData")){
  summary(cohortMethodData)
}

## ----tidy=TRUE,eval=FALSE------------------------------------------------
#  saveCohortMethodData(cohortMethodData, "coxibVsNonselVsGiBleed")

## ----tidy=FALSE,eval=FALSE-----------------------------------------------
#  studyPop <- createStudyPopulation(cohortMethodData = cohortMethodData,
#                                    outcomeId = 3,
#                                    firstExposureOnly = FALSE,
#                                    restrictToCommonPeriod = FALSE,
#                                    washoutPeriod = 0,
#                                    removeDuplicateSubjects = FALSE,
#                                    removeSubjectsWithPriorOutcome = TRUE,
#                                    minDaysAtRisk = 1,
#                                    riskWindowStart = 0,
#                                    addExposureDaysToStart = FALSE,
#                                    riskWindowEnd = 30,
#                                    addExposureDaysToEnd = TRUE)

## ----tidy=TRUE,eval=FALSE------------------------------------------------
#  getAttritionTable(studyPop)

## ----echo=FALSE,message=FALSE--------------------------------------------
if (file.exists("s:/temp/cohortMethodVignette/studyPop.rds")){
  studyPop <- readRDS("s:/temp/cohortMethodVignette/studyPop.rds")
  getAttritionTable(studyPop)
}

## ----tidy=TRUE,eval=FALSE------------------------------------------------
#  ps <- createPs(cohortMethodData = cohortMethodData, population = studyPop)

## ----echo=FALSE,message=FALSE,eval=TRUE----------------------------------
if (file.exists("s:/temp/cohortMethodVignette/ps.rds")) {
  ps <- readRDS("s:/temp/cohortMethodVignette/ps.rds")
}

## ----tidy=TRUE,eval=FALSE------------------------------------------------
#  computePsAuc(ps)

## ----echo=FALSE,message=FALSE,eval=TRUE----------------------------------
if (file.exists("s:/temp/cohortMethodVignette/ps.rds")) {
  computePsAuc(ps)
}

## ----tidy=TRUE,eval=FALSE------------------------------------------------
#  plotPs(ps, scale = "preference")

## ----echo=FALSE,message=FALSE,eval=TRUE----------------------------------
if (file.exists("s:/temp/cohortMethodVignette/ps.rds")) {
  plotPs(ps, scale = "preference")
}

## ----tidy=TRUE,eval=FALSE------------------------------------------------
#  propensityModel <- getPsModel(ps, cohortMethodData)
#  head(propensityModel)

## ----echo=FALSE,message=FALSE--------------------------------------------
if (file.exists("s:/temp/cohortMethodVignette/cohortMethodData")){
  propensityModel <- getPsModel(ps, cohortMethodData)
  truncRight <- function(x, n){
    nc <- nchar(x)
    x[nc > (n-3)] <- paste('...',substr(x[nc > (n-3)], nc[nc > (n-3)]-n+1, nc[nc > (n-3)]),sep="")
    x
  }
  propensityModel$covariateName <- truncRight(as.character(propensityModel$covariateName),40)
  head(propensityModel)  
  }

## ----tidy=TRUE,eval=FALSE------------------------------------------------
#  trimmedPop <- trimByPsToEquipoise(ps)
#  plotPs(trimmedPop, ps, scale = "preference")

## ----echo=FALSE,message=FALSE,eval=TRUE----------------------------------
if (file.exists("s:/temp/cohortMethodVignette/ps.rds")) {
  trimmedPop <- trimByPsToEquipoise(ps)  
  plotPs(trimmedPop, ps, scale = "preference")
}

## ----tidy=TRUE,eval=FALSE------------------------------------------------
#  stratifiedPop <- stratifyByPs(ps, numberOfStrata = 5)
#  plotPs(stratifiedPop, ps, scale = "preference")

## ----echo=FALSE,message=FALSE,eval=TRUE----------------------------------
if (file.exists("s:/temp/cohortMethodVignette/ps.rds")) {
  stratifiedPop <- stratifyByPs(ps, numberOfStrata = 5)  
  plotPs(stratifiedPop, ps, scale = "preference")
}

## ----tidy=TRUE,eval=FALSE------------------------------------------------
#    matchedPop <- matchOnPs(ps, caliper = 0.2, caliperScale = "standardized logit", maxRatio = 1)
#    plotPs(matchedPop, ps)

## ----echo=FALSE,message=FALSE,eval=TRUE----------------------------------
if (file.exists("s:/temp/cohortMethodVignette/ps.rds")) {
  matchedPop <- matchOnPs(ps, caliper = 0.2, caliperScale = "standardized logit", maxRatio = 1)
  plotPs(matchedPop, ps)
}

## ----tidy=TRUE,eval=FALSE------------------------------------------------
#  getAttritionTable(matchedPop)

## ----echo=FALSE,message=FALSE--------------------------------------------
if (file.exists("s:/temp/cohortMethodVignette/ps.rds")){
  getAttritionTable(matchedPop)
}

## ----tidy=TRUE,eval=FALSE------------------------------------------------
#  drawAttritionDiagram(matchedPop)

## ----echo=FALSE,message=FALSE,eval=TRUE,fig.width=5,fig.height=6---------
if (file.exists("s:/temp/cohortMethodVignette/OutcomeModel3.rds")) {
  drawAttritionDiagram(matchedPop)
}

## ----tidy=TRUE,eval=FALSE------------------------------------------------
#  balance <- computeCovariateBalance(matchedPop, cohortMethodData)

## ----echo=FALSE,message=FALSE,eval=TRUE----------------------------------
if (file.exists("s:/temp/cohortMethodVignette/balance.rds")) {
  balance <- readRDS("s:/temp/cohortMethodVignette/balance.rds")
}

## ----tidy=TRUE,eval=FALSE------------------------------------------------
#  plotCovariateBalanceScatterPlot(balance)

## ----echo=FALSE,message=FALSE,eval=TRUE,fig.width=8,fig.height=5---------
if (file.exists("s:/temp/cohortMethodVignette/balance.rds")) {
  plotCovariateBalanceScatterPlot(balance)
}

## ----tidy=TRUE,eval=FALSE------------------------------------------------
#  plotCovariateBalanceOfTopVariables(balance)

## ----echo=FALSE,message=FALSE,eval=TRUE,fig.width=8,fig.height=5---------
if (file.exists("s:/temp/cohortMethodVignette/balance.rds")) {
  plotCovariateBalanceOfTopVariables(balance)
}

## ----eval=FALSE----------------------------------------------------------
#  insertDbPopulation(population = matchedPop,
#                     cohortIds = c(101,100),
#                     connectionDetails = connectionDetails,
#                     cohortDatabaseSchema = resultsDatabaseSchema,
#                     cohortTable = "coxibVsNonselVsGiBleed",
#                     createTable = FALSE,
#                     cdmVersion = cdmVersion)

## ----tidy=FALSE,eval=FALSE-----------------------------------------------
#  computeMdrr(population = studyPop,
#              modelType = "cox",
#              alpha = 0.05,
#              power = 0.8,
#              twoSided = TRUE)

## ----echo=FALSE,message=FALSE,eval=TRUE----------------------------------
if (file.exists("s:/temp/cohortMethodVignette/studyPop.rds")){
computeMdrr(population = studyPop,
            modelType = "cox",
            alpha = 0.05, 
            power = 0.8, 
            twoSided = TRUE)
}

## ----tidy=FALSE,eval=FALSE-----------------------------------------------
#  computeMdrr(population = matchedPop,
#              modelType = "cox",
#              alpha = 0.05,
#              power = 0.8,
#              twoSided = TRUE)

## ----echo=FALSE,message=FALSE,eval=TRUE----------------------------------
if (file.exists("s:/temp/cohortMethodVignette/studyPop.rds")){
computeMdrr(population = matchedPop,
            modelType = "cox",
            alpha = 0.05, 
            power = 0.8, 
            twoSided = TRUE)
}

## ----tidy=FALSE,eval=FALSE-----------------------------------------------
#  getFollowUpDistribution(population = matchedPop)

## ----echo=FALSE,message=FALSE,eval=TRUE----------------------------------
if (file.exists("s:/temp/cohortMethodVignette/studyPop.rds")){
getFollowUpDistribution(population = matchedPop)
}

## ----tidy=FALSE,eval=FALSE-----------------------------------------------
#  plotFollowUpDistribution(population = matchedPop)

## ----echo=FALSE,message=FALSE,eval=TRUE,fig.width=8,fig.height=5---------
if (file.exists("s:/temp/cohortMethodVignette/studyPop.rds")){
plotFollowUpDistribution(population = matchedPop)
}

## ----tidy=FALSE,eval=FALSE-----------------------------------------------
#  outcomeModel <- fitOutcomeModel(population = studyPop,
#                                  modelType = "cox",
#                                  stratified = FALSE,
#                                  useCovariates = FALSE)
#  outcomeModel

## ----echo=FALSE,message=FALSE,eval=TRUE----------------------------------
if (file.exists("s:/temp/cohortMethodVignette/OutcomeModel1.rds")) {
  outcomeModel <- readRDS("s:/temp/cohortMethodVignette/OutcomeModel1.rds")
  outcomeModel
}

## ----tidy=FALSE,eval=FALSE-----------------------------------------------
#  outcomeModel <- fitOutcomeModel(population = matchedPop,
#                                  modelType = "cox",
#                                  stratified = TRUE,
#                                  useCovariates = FALSE)
#  outcomeModel

## ----echo=FALSE,message=FALSE,eval=TRUE----------------------------------
if (file.exists("s:/temp/cohortMethodVignette/OutcomeModel2.rds")) {
  outcomeModel <- readRDS("s:/temp/cohortMethodVignette/OutcomeModel2.rds")
  outcomeModel
}

## ----tidy=FALSE,eval=FALSE-----------------------------------------------
#  outcomeModel <- fitOutcomeModel(population = matchedPop,
#                                  cohortMethodData = cohortMethodData,
#                                  modelType = "cox",
#                                  stratified = TRUE,
#                                  useCovariates = TRUE)
#  outcomeModel

## ----echo=FALSE,message=FALSE,eval=TRUE----------------------------------
if (file.exists("s:/temp/cohortMethodVignette/OutcomeModel3.rds")) {
  outcomeModel <- readRDS("s:/temp/cohortMethodVignette/OutcomeModel3.rds")
  outcomeModel
}

## ----tidy=TRUE,eval=FALSE------------------------------------------------
#  summary(outcomeModel)

## ----echo=FALSE,message=FALSE,eval=TRUE----------------------------------
if (file.exists("s:/temp/cohortMethodVignette/OutcomeModel3.rds")) {
  summary(outcomeModel)
}

## ----tidy=TRUE,eval=FALSE------------------------------------------------
#  exp(coef(outcomeModel))

## ----echo=FALSE,message=FALSE,eval=TRUE----------------------------------
if (file.exists("s:/temp/cohortMethodVignette/OutcomeModel3.rds")) {
  exp(coef(outcomeModel))
}

## ----tidy=TRUE,eval=FALSE------------------------------------------------
#  exp(confint(outcomeModel))

## ----echo=FALSE,message=FALSE,eval=TRUE----------------------------------
if (file.exists("s:/temp/cohortMethodVignette/OutcomeModel3.rds")) {
  exp(confint(outcomeModel))
}

## ----tidy=TRUE,eval=FALSE------------------------------------------------
#  fullOutcomeModel <- getOutcomeModel(outcomeModel,cohortMethodData)
#  head(fullOutcomeModel)

## ----echo=FALSE,message=FALSE--------------------------------------------
if (file.exists("s:/temp/cohortMethodVignette/OutcomeModel3.rds")){
  fullOutcomeModel <- getOutcomeModel(outcomeModel,cohortMethodData)
  fullOutcomeModel$covariateName <- truncRight(as.character(fullOutcomeModel$covariateName),40)
  head(fullOutcomeModel)  
}

## ----tidy=TRUE,eval=FALSE------------------------------------------------
#  plotKaplanMeier(matchedPop, includeZero = FALSE)

## ----echo=FALSE, message=FALSE, results='hide'---------------------------
if (file.exists("s:/temp/cohortMethodVignette/ps.rds")) {
  plotKaplanMeier(matchedPop, includeZero = FALSE)
}

## ----tidy=TRUE,eval=TRUE-------------------------------------------------
citation("CohortMethod")

## ----tidy=TRUE,eval=TRUE-------------------------------------------------
citation("Cyclops")

