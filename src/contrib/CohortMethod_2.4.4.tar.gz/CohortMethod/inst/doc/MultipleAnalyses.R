## ---- echo = FALSE, message = FALSE, warning = FALSE---------------------
library(CohortMethod)
if (file.exists("S:/temp"))
  setwd("s:/temp")
knitr::opts_chunk$set(
  cache=FALSE,
  comment = "#>",
  error = FALSE,
  tidy = FALSE)

## ----tidy=FALSE,eval=TRUE------------------------------------------------
connectionDetails <- createConnectionDetails(dbms = "postgresql", 
                                             server = "localhost/ohdsi", 
                                             user = "joe", 
                                             password = "supersecret")

cdmDatabaseSchema <- "my_cdm_data"
resultsDatabaseSchema <- "my_results"
cdmVersion <- "5"

## ----tidy=FALSE,eval=FALSE-----------------------------------------------
#  library(SqlRender)
#  sql <- readSql("VignetteOutcomes.sql")
#  sql <- renderSql(sql,
#                   cdmDatabaseSchema = cdmDatabaseSchema,
#                   resultsDatabaseSchema = resultsDatabaseSchema)$sql
#  sql <- translateSql(sql, targetDialect = connectionDetails$dbms)$sql
#  
#  connection <- connect(connectionDetails)
#  executeSql(connection, sql)

## ----tidy=FALSE,eval=FALSE-----------------------------------------------
#  dcos <- createDrugComparatorOutcomes(targetId = 1118084,
#                                       comparatorId = 1124300,
#                                       excludedCovariateConceptIds = 21603933,
#                                       outcomeIds = c(192671, 29735, 140673, 197494,
#                                                      198185, 198199, 200528, 257315,
#                                                      314658, 317376, 321319, 380731,
#                                                      432661, 432867, 433516, 433701,
#                                                      433753, 435140, 435459, 435524,
#                                                      435783, 436665, 436676, 442619,
#                                                      444252, 444429, 4131756, 4134120,
#                                                      4134454, 4152280, 4165112, 4174262,
#                                                      4182210, 4270490, 4286201, 4289933))
#  
#  drugComparatorOutcomesList <- list(dcos)

## ----tidy=FALSE,eval=TRUE------------------------------------------------
covarSettings <- createCovariateSettings(useCovariateDemographics = TRUE,
                                         useCovariateDemographicsAge = TRUE,
                                         useCovariateDemographicsGender = TRUE,
                                         useCovariateDemographicsRace = TRUE,
                                         useCovariateDemographicsEthnicity = TRUE,
                                         useCovariateDemographicsYear = TRUE,
                                         useCovariateDemographicsMonth = TRUE,
                                         useCovariateConditionOccurrence = TRUE,
                                         useCovariateConditionOccurrenceLongTerm = TRUE,
                                         useCovariateConditionOccurrenceShortTerm = TRUE,
                                         useCovariateConditionOccurrenceInptMediumTerm = TRUE,
                                         useCovariateConditionEra = TRUE,
                                         useCovariateConditionEraEver = TRUE,
                                         useCovariateConditionEraOverlap = TRUE,
                                         useCovariateConditionGroup = TRUE,
                                         useCovariateDrugExposure = TRUE,
                                         useCovariateDrugExposureLongTerm = TRUE,
                                         useCovariateDrugExposureShortTerm = TRUE,
                                         useCovariateDrugEra = TRUE,
                                         useCovariateDrugEraLongTerm = TRUE,
                                         useCovariateDrugEraShortTerm = TRUE,
                                         useCovariateDrugEraEver = TRUE,
                                         useCovariateDrugEraOverlap = TRUE,
                                         useCovariateDrugGroup = TRUE,
                                         useCovariateProcedureOccurrence = TRUE,
                                         useCovariateProcedureOccurrenceLongTerm = TRUE,
                                         useCovariateProcedureOccurrenceShortTerm = TRUE,
                                         useCovariateProcedureGroup = TRUE,
                                         useCovariateObservation = TRUE,
                                         useCovariateObservationLongTerm = TRUE,
                                         useCovariateObservationShortTerm = TRUE,
                                         useCovariateObservationCountLongTerm = TRUE,
                                         useCovariateMeasurementLongTerm = TRUE,
                                         useCovariateMeasurementShortTerm = TRUE,
                                         useCovariateMeasurementCountLongTerm = TRUE,
                                         useCovariateMeasurementBelow = TRUE,
                                         useCovariateMeasurementAbove = TRUE,
                                         useCovariateConceptCounts = TRUE,
                                         useCovariateRiskScores = TRUE,
                                         useCovariateRiskScoresCharlson = TRUE,
                                         useCovariateRiskScoresDCSI = TRUE,
                                         useCovariateRiskScoresCHADS2 = TRUE,
                                         useCovariateInteractionYear = FALSE,
                                         useCovariateInteractionMonth = FALSE,
                                         longTermDays = 365,
                                         mediumTermDays = 180,
                                         shortTermDays = 30,
                                         addDescendantsToExclude = TRUE,
                                         deleteCovariatesSmallCount = 100)

getDbCmDataArgs <- createGetDbCohortMethodDataArgs(washoutPeriod = 183,
                                                   restrictToCommonPeriod = FALSE,
                                                   firstExposureOnly = TRUE,
                                                   removeDuplicateSubjects = TRUE,
                                                   studyStartDate = "",
                                                   studyEndDate = "",
                                                   excludeDrugsFromCovariates = FALSE,
                                                   covariateSettings = covarSettings)

createStudyPopArgs <- createCreateStudyPopulationArgs(removeSubjectsWithPriorOutcome = TRUE,
                                                      minDaysAtRisk = 1,
                                                      riskWindowStart = 0,
                                                      addExposureDaysToStart = FALSE,
                                                      riskWindowEnd = 30,
                                                      addExposureDaysToEnd = TRUE)

fitOutcomeModelArgs1 <- createFitOutcomeModelArgs(useCovariates = FALSE,
                                                  modelType = "cox",
                                                  stratified = FALSE)

## ----tidy=FALSE,eval=TRUE------------------------------------------------
cmAnalysis1 <- createCmAnalysis(analysisId = 1,
                                description = "No matching, simple outcome model",
                                getDbCohortMethodDataArgs = getDbCmDataArgs,
                                createStudyPopArgs = createStudyPopArgs,
                                fitOutcomeModel = TRUE,
                                fitOutcomeModelArgs = fitOutcomeModelArgs1)

## ----tidy=FALSE,eval=TRUE------------------------------------------------
createPsArgs <- createCreatePsArgs() # Using only defaults

matchOnPsArgs <- createMatchOnPsArgs(maxRatio = 100)

cmAnalysis2 <- createCmAnalysis(analysisId = 2,
                                description = "Matching plus simple outcome model",
                                getDbCohortMethodDataArgs = getDbCmDataArgs,
                                createStudyPopArgs = createStudyPopArgs,
                                createPs = TRUE,
                                createPsArgs = createPsArgs,
                                matchOnPs = TRUE,
                                matchOnPsArgs = matchOnPsArgs,
                                computeCovariateBalance = TRUE,
                                fitOutcomeModel = TRUE,
                                fitOutcomeModelArgs = fitOutcomeModelArgs1)

stratifyByPsArgs <- createStratifyByPsArgs(numberOfStrata = 5)

fitOutcomeModelArgs2 <- createFitOutcomeModelArgs(useCovariates = FALSE,
                                                  modelType = "cox",
                                                  stratified = TRUE)

cmAnalysis3 <- createCmAnalysis(analysisId = 3,
                                description = "Stratification plus stratified outcome model",
                                getDbCohortMethodDataArgs = getDbCmDataArgs,
                                createStudyPopArgs = createStudyPopArgs,
                                createPs = TRUE,
                                createPsArgs = createPsArgs,
                                stratifyByPs = TRUE,
                                stratifyByPsArgs = stratifyByPsArgs,
                                fitOutcomeModel = TRUE,
                                fitOutcomeModelArgs = fitOutcomeModelArgs2)

cmAnalysis4 <- createCmAnalysis(analysisId = 4,
                                description = "Matching plus stratified outcome model",
                                getDbCohortMethodDataArgs = getDbCmDataArgs,
                                createStudyPopArgs = createStudyPopArgs,
                                createPs = TRUE,
                                createPsArgs = createPsArgs,
                                matchOnPs = TRUE,
                                matchOnPsArgs = matchOnPsArgs,
                                computeCovariateBalance = TRUE,
                                fitOutcomeModel = TRUE,
                                fitOutcomeModelArgs = fitOutcomeModelArgs2)

fitOutcomeModelArgs3 <- createFitOutcomeModelArgs(useCovariates = TRUE,
                                                  modelType = "cox",
                                                  stratified = TRUE)

cmAnalysis5 <- createCmAnalysis(analysisId = 5,
                                description = "Matching plus full outcome model",
                                getDbCohortMethodDataArgs = getDbCmDataArgs,
                                createStudyPopArgs = createStudyPopArgs,
                                createPs = TRUE,
                                createPsArgs = createPsArgs,
                                matchOnPs = TRUE,
                                matchOnPsArgs = matchOnPsArgs,
                                computeCovariateBalance = TRUE,
                                fitOutcomeModel = TRUE,
                                fitOutcomeModelArgs = fitOutcomeModelArgs3)

## ----tidy=FALSE,eval=TRUE------------------------------------------------
cmAnalysisList <- list(cmAnalysis1, cmAnalysis2, cmAnalysis3, cmAnalysis4, cmAnalysis5)

## ----tidy=FALSE,eval=TRUE------------------------------------------------
comparatorIds = list(drugInSameClass = 1124300,
                     drugWithSameIndication = 1125315)

dcos <- createDrugComparatorOutcomes(targetId = 1118084,
                                     comparatorId = comparatorIds,
                                     outcomeIds = 192671)

drugComparatorOutcomesList2 <- list(dcos)

## ----tidy=FALSE,eval=TRUE------------------------------------------------
cmAnalysis1 <- createCmAnalysis(analysisId = 1,
                                description = "Analysis using drug in same class",
                                comparatorType = "drugInSameClass",
                                getDbCohortMethodDataArgs = getDbCmDataArgs,
								createStudyPopArgs = createStudyPopArgs,
                                createPs = TRUE,
                                createPsArgs = createPsArgs,
                                matchOnPs = TRUE,
                                matchOnPsArgs = matchOnPsArgs,
                                fitOutcomeModel = TRUE,
                                fitOutcomeModelArgs = fitOutcomeModelArgs1)

cmAnalysis2 <- createCmAnalysis(analysisId = 2,
                                description = "Analysis using drug with same indication",
                                comparatorType = "drugWithSameIndication",
                                getDbCohortMethodDataArgs = getDbCmDataArgs,
								createStudyPopArgs = createStudyPopArgs,
                                createPs = TRUE,
                                createPsArgs = createPsArgs,
                                matchOnPs = TRUE,
                                matchOnPsArgs = matchOnPsArgs,
                                fitOutcomeModel = TRUE,
                                fitOutcomeModelArgs = fitOutcomeModelArgs1)

cmAnalysisList2 <- list(cmAnalysis1, cmAnalysis2)

## ----tidy=FALSE,eval=FALSE-----------------------------------------------
#  result <- runCmAnalyses(connectionDetails = connectionDetails,
#                          cdmDatabaseSchema = cdmDatabaseSchema,
#                          exposureDatabaseSchema = cdmDatabaseSchema,
#                          exposureTable = "drug_era",
#                          outcomeDatabaseSchema = resultsDatabaseSchema,
#                          outcomeTable = "outcomes",
#                          cdmVersion = cdmVersion,
#                          outputFolder = "./CohortMethodOutput",
#                          cmAnalysisList = cmAnalysisList,
#                          drugComparatorOutcomesList = drugComparatorOutcomesList,
#                          getDbCohortMethodDataThreads = 1,
#                          createPsThreads = 1,
#                          psCvThreads = 10,
#                          createStudyPopThreads = 4,
#                          computeCovarBalThreads = 2,
#                          trimMatchStratifyThreads = 10,
#                          fitOutcomeModelThreads = 4,
#                          outcomeCvThreads = 10)

## ----tidy=FALSE,eval=FALSE-----------------------------------------------
#  psFile <- result$psFile[result$targetId == 1118084 &
#                          result$comparatorId == 1124300 &
#                          result$outcomeId == 192671 &
#                          result$analysisId == 5]
#  ps <- readRDS(psFile)
#  plotPs(ps)

## ----echo=FALSE,message=FALSE--------------------------------------------
if (file.exists("s:/temp/cohortMethodVignette2/outcomeModelReference.rds")){
  result <- readRDS("s:/temp/cohortMethodVignette2/outcomeModelReference.rds")
  psFile <- result$psFile[result$targetId == 1118084 & 
                            result$comparatorId == 1124300 & 
                            result$outcomeId == 192671 &
                            result$analysisId == 5]
  ps <- readRDS(psFile)
  plotPs(ps)
}

## ----tidy=FALSE,eval=FALSE-----------------------------------------------
#  analysisSum <- summarizeAnalyses(result)
#  head(analysisSum)

## ----echo=FALSE,message=FALSE--------------------------------------------
if (file.exists("s:/temp/cohortMethodVignette2/analysisSummary.rds")){
  analysisSum <- readRDS("s:/temp/cohortMethodVignette2/analysisSummary.rds")
  head(analysisSum)
}

## ----tidy=FALSE,eval=FALSE-----------------------------------------------
#  install.packages("EmpiricalCalibration")
#  library(EmpiricalCalibration)
#  
#  # Analysis 1: No matching, simple outcome model
#  negCons <- analysisSum[analysisSum$analysisId == 1 & analysisSum$outcomeId != 192671, ]
#  hoi <-  analysisSum[analysisSum$analysisId == 1 & analysisSum$outcomeId == 192671, ]
#  null <- fitNull(negCons$logRr, negCons$seLogRr)
#  plotCalibrationEffect(negCons$logRr, negCons$seLogRr, hoi$logRr, hoi$seLogRr, null)

## ----echo=FALSE,message=FALSE,eval=TRUE----------------------------------
if (file.exists("s:/temp/cohortMethodVignette2/analysisSummary.rds")){
  library(EmpiricalCalibration)
  negCons <- analysisSum[analysisSum$analysisId == 1 & analysisSum$outcomeId != 192671, ]
  hoi <-  analysisSum[analysisSum$analysisId == 1 & analysisSum$outcomeId == 192671, ]
  null <- fitNull(negCons$logRr, negCons$seLogRr)
  plotCalibrationEffect(negCons$logRr, negCons$seLogRr, hoi$logRr, hoi$seLogRr, null)
}

## ----tidy=FALSE,eval=FALSE-----------------------------------------------
#  # Analysis 2: Matching plus simple outcome model
#  negCons <- analysisSum[analysisSum$analysisId == 2 & analysisSum$outcomeId != 192671, ]
#  hoi <-  analysisSum[analysisSum$analysisId == 2 & analysisSum$outcomeId == 192671, ]
#  null <- fitNull(negCons$logRr, negCons$seLogRr)
#  plotCalibrationEffect(negCons$logRr, negCons$seLogRr, hoi$logRr, hoi$seLogRr, null)

## ----echo=FALSE,message=FALSE,eval=TRUE----------------------------------
if (file.exists("s:/temp/cohortMethodVignette2/analysisSummary.rds")){
  negCons <- analysisSum[analysisSum$analysisId == 2 & analysisSum$outcomeId != 192671, ]
  hoi <-  analysisSum[analysisSum$analysisId == 2 & analysisSum$outcomeId == 192671, ]
  null <- fitNull(negCons$logRr, negCons$seLogRr)
  plotCalibrationEffect(negCons$logRr, negCons$seLogRr, hoi$logRr, hoi$seLogRr, null)
}

## ----tidy=FALSE,eval=FALSE-----------------------------------------------
#  # Analysis 3: Stratification plus simple outcome model
#  negCons <- analysisSum[analysisSum$analysisId == 3 & analysisSum$outcomeId != 192671, ]
#  hoi <-  analysisSum[analysisSum$analysisId == 3 & analysisSum$outcomeId == 192671, ]
#  null <- fitNull(negCons$logRr, negCons$seLogRr)
#  plotCalibrationEffect(negCons$logRr, negCons$seLogRr, hoi$logRr, hoi$seLogRr, null)

## ----echo=FALSE,message=FALSE,eval=TRUE----------------------------------
if (file.exists("s:/temp/cohortMethodVignette2/analysisSummary.rds")){
  negCons <- analysisSum[analysisSum$analysisId == 3 & analysisSum$outcomeId != 192671, ]
  hoi <-  analysisSum[analysisSum$analysisId == 3 & analysisSum$outcomeId == 192671, ]
  null <- fitNull(negCons$logRr, negCons$seLogRr)
  plotCalibrationEffect(negCons$logRr, negCons$seLogRr, hoi$logRr, hoi$seLogRr, null)
}

## ----tidy=FALSE,eval=FALSE-----------------------------------------------
#  # Analysis 4: Matching plus stratified outcome model
#  negCons <- analysisSum[analysisSum$analysisId == 4 & analysisSum$outcomeId != 192671, ]
#  hoi <-  analysisSum[analysisSum$analysisId == 4 & analysisSum$outcomeId == 192671, ]
#  null <- fitNull(negCons$logRr, negCons$seLogRr)
#  plotCalibrationEffect(negCons$logRr, negCons$seLogRr, hoi$logRr, hoi$seLogRr, null)

## ----echo=FALSE,message=FALSE,eval=TRUE----------------------------------
if (file.exists("s:/temp/cohortMethodVignette2/analysisSummary.rds")){
  negCons <- analysisSum[analysisSum$analysisId == 4 & analysisSum$outcomeId != 192671, ]
  hoi <-  analysisSum[analysisSum$analysisId == 4 & analysisSum$outcomeId == 192671, ]
  null <- fitNull(negCons$logRr, negCons$seLogRr)
  plotCalibrationEffect(negCons$logRr, negCons$seLogRr, hoi$logRr, hoi$seLogRr, null)
}

## ----tidy=FALSE,eval=FALSE-----------------------------------------------
#  # Analysis 5: Matching plus full outcome model
#  negCons <- analysisSum[analysisSum$analysisId == 5 & analysisSum$outcomeId != 192671, ]
#  hoi <-  analysisSum[analysisSum$analysisId == 5 & analysisSum$outcomeId == 192671, ]
#  null <- fitNull(negCons$logRr, negCons$seLogRr)
#  plotCalibrationEffect(negCons$logRr, negCons$seLogRr, hoi$logRr, hoi$seLogRr, null)

## ----echo=FALSE,message=FALSE,eval=TRUE----------------------------------
if (file.exists("s:/temp/cohortMethodVignette2/analysisSummary.rds")){
  negCons <- analysisSum[analysisSum$analysisId == 5 & analysisSum$outcomeId != 192671, ]
  hoi <-  analysisSum[analysisSum$analysisId == 5 & analysisSum$outcomeId == 192671, ]
  null <- fitNull(negCons$logRr, negCons$seLogRr)
  plotCalibrationEffect(negCons$logRr, negCons$seLogRr, hoi$logRr, hoi$seLogRr, null)
}

## ----tidy=TRUE,eval=TRUE-------------------------------------------------
citation("CohortMethod")

## ----tidy=TRUE,eval=TRUE-------------------------------------------------
citation("Cyclops")

