## ----echo = FALSE, message = FALSE, warning = FALSE---------------------------
library(SelfControlledCaseSeries)
outputFolder <- "d:/temp/vignetteSccs"
folderExists <- dir.exists(outputFolder)

## ----eval=FALSE---------------------------------------------------------------
#  install.packages("remotes")
#  library(remotes)
#  install_github("ohdsi/SelfControlledCaseSeries")

## ----eval=FALSE---------------------------------------------------------------
#  connectionDetails <- createConnectionDetails(dbms = "postgresql",
#                                               server = "localhost/ohdsi",
#                                               user = "joe",
#                                               password = "supersecret")
#  
#  cdmDatabaseSchema <- "my_cdm_data"
#  cohortDatabaseSchema <- "my_results"
#  options(sqlRenderTempEmulationSchema = NULL)
#  cdmVersion <- "5"

## ----eval=FALSE---------------------------------------------------------------
#  library(SqlRender)
#  sql <- readSql("vignette.sql")
#  sql <- render(sql,
#                cdmDatabaseSchema = cdmDatabaseSchema,
#                cohortDatabaseSchema = cohortDatabaseSchema,
#                outcomeTable = "my_outcomes")
#  sql <- translate(sql, targetDialect = connectionDetails$dbms)
#  
#  connection <- connect(connectionDetails)
#  executeSql(connection, sql)

## ----eval=FALSE---------------------------------------------------------------
#  sql <- paste("SELECT cohort_definition_id, COUNT(*) AS count",
#               "FROM @cohortDatabaseSchema.@outcomeTable",
#               "GROUP BY cohort_definition_id")
#  sql <- render(sql,
#                cohortDatabaseSchema = cohortDatabaseSchema,
#                outcomeTable = "my_outcomes")
#  sql <- translate(sql, targetDialect = connectionDetails$dbms)
#  
#  querySql(connection, sql)

## ----echo=FALSE,message=FALSE-------------------------------------------------
data.frame(cohort_concept_id = c(1),count = c(1029443))

## ----eval=FALSE---------------------------------------------------------------
#  diclofenac <- 1124300
#  
#  sccsData <- getDbSccsData(connectionDetails = connectionDetails,
#                            cdmDatabaseSchema = cdmDatabaseSchema,
#                            outcomeDatabaseSchema = cohortDatabaseSchema,
#                            outcomeTable = outcomeTable,
#                            outcomeIds = 1,
#                            exposureDatabaseSchema = cdmDatabaseSchema,
#                            exposureTable = "drug_era",
#                            exposureIds = diclofenac,
#                            cdmVersion = cdmVersion)
#  sccsData

## ----echo=FALSE,message=FALSE,eval=TRUE---------------------------------------
diclofenac <- 1124300
if (folderExists) {
  sccsData <- loadSccsData(file.path(outputFolder, "data1.zip"))
} 

## ----echo=FALSE,message=FALSE-------------------------------------------------
if (folderExists) {
  sccsData
}

## ----eval=FALSE---------------------------------------------------------------
#  summary(sccsData)

## ----echo=FALSE,message=FALSE-------------------------------------------------
if (folderExists) {
  summary(sccsData)
}

## ----eval=FALSE---------------------------------------------------------------
#  saveSccsData(sccsData, "diclofenacAndGiBleed.zip")

## ----eval=FALSE---------------------------------------------------------------
#  studyPop <- createStudyPopulation(sccsData = sccsData,
#                                    outcomeId = 1,
#                                    firstOutcomeOnly = FALSE,
#                                    naivePeriod = 180)

## ----eval=FALSE---------------------------------------------------------------
#  getAttritionTable(studyPop)

## ----echo=FALSE,message=FALSE-------------------------------------------------
if (folderExists) {
  studyPop <- readRDS(file.path(outputFolder, "studyPop.rds"))
  getAttritionTable(studyPop)
}

## ----eval=FALSE---------------------------------------------------------------
#  covarDiclofenac <- createEraCovariateSettings(label = "Exposure of interest",
#                                                includeEraIds = diclofenac,
#                                                start = 0,
#                                                end = 0,
#                                                endAnchor = "era end")
#  
#  sccsIntervalData <- createSccsIntervalData(
#    studyPopulation = studyPop,
#    sccsData = sccsData,
#    eraCovariateSettings = covarDiclofenac
#  )
#  
#  summary(sccsIntervalData)

## ----echo=FALSE,message=FALSE-------------------------------------------------
if (folderExists) {
  sccsIntervalData <- loadSccsIntervalData(file.path(outputFolder, "intervalData1.zip"))
  summary(sccsIntervalData)
}

## ----eval=FALSE---------------------------------------------------------------
#  model <- fitSccsModel(sccsIntervalData)

## ----eval=FALSE---------------------------------------------------------------
#  model

## ----echo=FALSE,message=FALSE-------------------------------------------------
if (folderExists){
  model <- readRDS(file.path(outputFolder, "simpleModel.rds"))
  model
}

## ----eval=FALSE---------------------------------------------------------------
#  covarPreDiclofenac <- createEraCovariateSettings(label = "Pre-exposure",
#                                                   includeEraIds = diclofenac,
#                                                   start = -60,
#                                                   end = -1,
#                                                   endAnchor = "era start")
#  
#  sccsIntervalData <- createSccsIntervalData(
#    studyPopulation = studyPop,
#    sccsData = sccsData,
#    eraCovariateSettings = list(covarDiclofenac,
#                                covarPreDiclofenac)
#  )
#  
#  model <- fitSccsModel(sccsIntervalData)

## ----eval=FALSE---------------------------------------------------------------
#  model

## ----echo=FALSE,message=FALSE-------------------------------------------------
if (folderExists) {
  model <- readRDS(file.path(outputFolder, "preExposureModel.rds"))
  model
}

## ----eval=FALSE---------------------------------------------------------------
#  seasonalityCovariateSettings <- createSeasonalityCovariateSettings(seasonKnots = 5)
#  
#  calendarTimeSettings <- createCalendarTimeCovariateSettings(calendarTimeKnots = 5)
#  
#  sccsIntervalData <- createSccsIntervalData(
#    studyPopulation = studyPop,
#    sccsData = sccsData,
#    eraCovariateSettings = list(covarDiclofenac,
#                                covarPreDiclofenac),
#    seasonalityCovariateSettings = seasonalityCovariateSettings,
#    calendarTimeCovariateSettings = calendarTimeSettings
#  )
#  
#  model <- fitSccsModel(sccsIntervalData)

## ----eval=FALSE---------------------------------------------------------------
#  model

## ----echo=FALSE,message=FALSE-------------------------------------------------
if (folderExists) {
  model <- readRDS(file.path(outputFolder, "seasonCalendarTimeModel.rds"))
  model
}

## ----eval=FALSE---------------------------------------------------------------
#  plotSeasonality(model)

## ----echo=FALSE,message=FALSE-------------------------------------------------
if (folderExists) {
  plotSeasonality(model)
}

## ----eval=FALSE---------------------------------------------------------------
#  plotCalendarTimeEffect(model)

## ----echo=FALSE,message=FALSE-------------------------------------------------
if (folderExists) {
  plotCalendarTimeEffect(model)
}

## ----eval=FALSE---------------------------------------------------------------
#  sccsIntervalData <- createSccsIntervalData(
#    studyPopulation = studyPop,
#    sccsData = sccsData,
#    eraCovariateSettings = list(covarDiclofenac,
#                                covarPreDiclofenac),
#    eventDependentObservation = TRUE
#  )
#  
#  model <- fitSccsModel(sccsIntervalData)

## ----eval=FALSE---------------------------------------------------------------
#  model

## ----echo=FALSE,message=FALSE-------------------------------------------------
if (folderExists) {
  model <- readRDS(file.path(outputFolder, "eventDepModel.rds"))
  model
}

## ----eval=FALSE---------------------------------------------------------------
#  diclofenac <- 1124300
#  ppis <- c(911735, 929887, 923645, 904453, 948078, 19039926)
#  
#  sccsData <- getDbSccsData(connectionDetails = connectionDetails,
#                            cdmDatabaseSchema = cdmDatabaseSchema,
#                            outcomeDatabaseSchema = cohortDatabaseSchema,
#                            outcomeTable = outcomeTable,
#                            outcomeIds = 1,
#                            exposureDatabaseSchema = cdmDatabaseSchema,
#                            exposureTable = "drug_era",
#                            exposureIds = c(diclofenac, ppis),
#                            cdmVersion = cdmVersion)
#  sccsData

## ----echo=FALSE,message=FALSE,eval=TRUE---------------------------------------
ppis <- c(911735, 929887, 923645, 904453, 948078, 19039926)
if (folderExists) {
  sccsData <- loadSccsData(file.path(outputFolder, "data2.zip"))
} 

## ----echo=FALSE,message=FALSE-------------------------------------------------
if (folderExists) {
  sccsData
}

## ----eval=FALSE---------------------------------------------------------------
#  studyPop <- createStudyPopulation(sccsData = sccsData,
#                                    outcomeId = 1,
#                                    firstOutcomeOnly = FALSE,
#                                    naivePeriod = 180)
#  
#  covarPpis <- createEraCovariateSettings(label = "PPIs",
#                                          includeEraIds = ppis,
#                                          stratifyById = FALSE,
#                                          start = 1,
#                                          end = 0,
#                                          endAnchor = "era end")
#  
#  sccsIntervalData <- createSccsIntervalData(
#    studyPopulation = studyPop,
#    sccsData = sccsData,
#    eraCovariateSettings = list(covarDiclofenac,
#                                covarPreDiclofenac,
#                                covarPpis),
#    ageCovariateSettings = ageCovariateSettings,
#    seasonalityCovariateSettings = seasonalityCovariateSettings,
#    calendarTimeCovariateSettings = calendarTimeSettings
#  )
#  
#  model <- fitSccsModel(sccsIntervalData)

## ----eval=FALSE---------------------------------------------------------------
#  model

## ----echo=FALSE,message=FALSE-------------------------------------------------
if (folderExists) {
  model <- readRDS(file.path(outputFolder, "ppiModel.rds"))
  model
}

## ----eval=FALSE---------------------------------------------------------------
#  sccsData <- getDbSccsData(connectionDetails = connectionDetails,
#                            cdmDatabaseSchema = cdmDatabaseSchema,
#                            outcomeDatabaseSchema = cohortDatabaseSchema,
#                            outcomeTable = outcomeTable,
#                            outcomeIds = 1,
#                            exposureDatabaseSchema = cdmDatabaseSchema,
#                            exposureTable = "drug_era",
#                            exposureIds = c(),
#                            cdmVersion = cdmVersion)

## ----eval=FALSE---------------------------------------------------------------
#  studyPop <- createStudyPopulation(sccsData = sccsData,
#                                    outcomeId = 1,
#                                    firstOutcomeOnly = FALSE,
#                                    naivePeriod = 180)
#  
#  covarAllDrugs <- createEraCovariateSettings(label = "Other exposures",
#                                              excludeEraIds = diclofenac,
#                                              stratifyById = TRUE,
#                                              start = 1,
#                                              end = 0,
#                                              endAnchor = "era end",
#                                              allowRegularization = TRUE)
#  
#  sccsIntervalData <- createSccsIntervalData(
#    studyPopulation = studyPop,
#    sccsData = sccsData,
#    eraCovariateSettings = list(covarDiclofenac,
#                                covarPreDiclofenac,
#                                covarAllDrugs),
#    seasonalityCovariateSettings = seasonalityCovariateSettings,
#    calendarTimeCovariateSettings = calendarTimeSettings
#  )
#  
#  model <- fitSccsModel(sccsIntervalData)

## ----eval=FALSE---------------------------------------------------------------
#    estimates <- getModel(model)
#    estimates[estimates$originalEraId == diclofenac, ]

## ----echo=FALSE,message=FALSE-------------------------------------------------
if (folderExists) {
  model <- readRDS(file.path(outputFolder, "allDrugsModel.rds"))
  estimates <- getModel(model)
  estimates[estimates$originalEraId == diclofenac, ]
}

## ----eval=FALSE---------------------------------------------------------------
#  estimates[estimates$originalEraId %in% ppis, ]

## ----echo=FALSE,message=FALSE-------------------------------------------------
if (folderExists) {
  estimates[estimates$originalEraId %in% ppis, ]
}

## ----eval=FALSE---------------------------------------------------------------
#  computeMdrr(sccsIntervalData,
#              exposureCovariateId = 1000,
#              alpha = 0.05,
#              power = 0.8,
#              twoSided = TRUE,
#              method = "binomial")

## ----echo=FALSE,message=FALSE-------------------------------------------------
if (folderExists) {
  computeMdrr(sccsIntervalData,
              exposureCovariateId = 1000,
              alpha = 0.05,
              power = 0.8,
              twoSided = TRUE,
              method = "binomial")
}

## ----eval=FALSE---------------------------------------------------------------
#  plotExposureCentered(studyPop, sccsData, exposureEraId = diclofenac)

## ----echo=FALSE,message=FALSE,fig.width=6.5, fig.height=5---------------------
if (folderExists) {
  plotExposureCentered(studyPop, sccsData, exposureEraId = diclofenac)
}

## ----eval=FALSE---------------------------------------------------------------
#  computePreExposureGainP(sccsData, studyPopulation, exposureEraId = diclofenac)

## ----echo=FALSE,message=FALSE,fig.width=6.5, fig.height=5---------------------
if (folderExists) {
  computePreExposureGainP(sccsData, studyPop, exposureEraId = diclofenac) 
}

## ----eval=FALSE---------------------------------------------------------------
#  plotAgeSpans(studyPop)

## ----echo=FALSE,message=FALSE-------------------------------------------------
if (folderExists) {
  plotAgeSpans(studyPop)
}

## ----eval=FALSE---------------------------------------------------------------
#  plotEventObservationDependence(studyPop)

## ----echo=FALSE,message=FALSE-------------------------------------------------
if (folderExists) {
  sccsData <- loadSccsData(file.path(outputFolder, "data1.zip"))
  plotEventObservationDependence(studyPop)
}

## ----eval=FALSE---------------------------------------------------------------
#  plotEventToCalendarTime(studyPop)

## ----echo=FALSE,message=FALSE-------------------------------------------------
if (folderExists) {
  plotEventToCalendarTime(studyPop)
}

## ----eval=FALSE---------------------------------------------------------------
#  plotEventToCalendarTime(studyPop, model)

## ----echo=FALSE,message=FALSE-------------------------------------------------
if (folderExists) {
  model <- readRDS(file.path(outputFolder, "seasonCalendarTimeModel.rds"))
  plotEventToCalendarTime(studyPop, model)
}

## ----eval=FALSE---------------------------------------------------------------
#  diagnostic <- computeTimeStability(studyPop, model)
#  head(diagnostic[, c("monthStartDate", "monthEndDate", "p", "alpha", "stable")])

## ----echo=FALSE,message=FALSE-------------------------------------------------
if (folderExists) {
  diagnostic <- computeTimeStability(studyPop, model)
  head(diagnostic[, c("monthStartDate", "monthEndDate", "p", "alpha", "stable")])
}

## ----eval=TRUE----------------------------------------------------------------
citation("SelfControlledCaseSeries")

## ----eval=TRUE----------------------------------------------------------------
citation("Cyclops")

