#' @param newCohortId   The cohort id of the result cohort.
