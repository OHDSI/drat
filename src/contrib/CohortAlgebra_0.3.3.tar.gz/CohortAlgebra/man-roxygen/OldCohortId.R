#' @param oldCohortId   The cohort id of the cohort that needs to be modified.
