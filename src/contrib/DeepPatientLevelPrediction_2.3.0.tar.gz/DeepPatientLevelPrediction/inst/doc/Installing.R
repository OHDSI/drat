## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)

## ----echo = TRUE, message = FALSE, warning = FALSE,tidy=FALSE,eval=FALSE------
# reticulate::py_config()

## ----echo = TRUE, message = FALSE, warning = FALSE,tidy=FALSE,eval=FALSE------
# install.packages("remotes")
# remotes::install_github("OHDSI/DeepPatientLevelPrediction")

## ----echo = TRUE, message = FALSE, warning = FALSE,tidy=FALSE,eval=FALSE------
# library(PatientLevelPrediction)
# library(DeepPatientLevelPrediction)
# 
# data(plpDataSimulationProfile)
# sampleSize <- 1e3
# plpData <- simulatePlpData(
#   plpDataSimulationProfile,
#   n = sampleSize
# )
# 
# populationSettings <- PatientLevelPrediction::createStudyPopulationSettings(
#                                                           requireTimeAtRisk = F,
#                                                           riskWindowStart = 1,
#                                                           riskWindowEnd = 365)
# # a very simple resnet
# modelSettings <- setResNet(numLayers = 2L,
#                            sizeHidden = 64L,
#                            hiddenFactor = 1L,
#                            residualDropout = 0,
#                            hiddenDropout = 0.2,
#                            sizeEmbedding = 64L,
#                            estimatorSettings = setEstimator(learningRate = 3e-4,
#                                                             weightDecay = 1e-6,
#                                                             device='cpu',
#                                                             batchSize=128L,
#                                                             epochs=3L,
#                                                             seed = 42),
#                            hyperParamSearch = 'random',
#                            randomSample = 1L)
# 
# plpResults <- PatientLevelPrediction::runPlp(plpData = plpData,
#                outcomeId = 3,
#                modelSettings = modelSettings,
#                analysisId = 'Test',
#                analysisName = 'Testing DeepPlp',
#                populationSettings = populationSettings,
#                splitSettings = createDefaultSplitSetting(),
#                sampleSettings = createSampleSettings(),
#                featureEngineeringSettings = createFeatureEngineeringSettings(),
#                preprocessSettings = createPreprocessSettings(),
#                logSettings = createLogSettings(),
#                executeSettings = createExecuteSettings(runSplitData = TRUE,
#                                                       runSampleData = FALSE,
#                                                       runFeatureEngineering = FALSE,
#                                                       runPreprocessData = TRUE,
#                                                       runModelDevelopment = TRUE,
#                                                       runCovariateSummary = TRUE
#                                                       ))

## ----tidy=TRUE,eval=TRUE------------------------------------------------------
citation("DeepPatientLevelPrediction")

