# @file HelperFunctions.R
#
# Copyright 2023 Observational Health Data Sciences and Informatics
#
# This file is part of DeepPatientLevelPrediction
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#' Convert a camel case string to snake case
#'
#' @param string   The string to be converted
#'
#' @return
#' A string
#'
camelCaseToSnakeCase <- function(string) {
  string <- gsub("([A-Z])", "_\\1", string)
  string <- tolower(string)
  string <- gsub("([a-z])([0-9])", "\\1_\\2", string)
  return(string)
}

#' Convert a camel case string to snake case
#'
#' @param string   The string to be converted
#'
#' @return
#' A string
#'
snakeCaseToCamelCase <- function(string) {
  string <- tolower(string)
  for (letter in letters) {
    string <- gsub(paste("_", letter, sep = ""), toupper(letter), string)
  }
  string <- gsub("_([0-9])", "\\1", string)
  return(string)
}

#' Convert the names of an object from snake case to camel case
#'
#' @param object   The object of which the names should be converted
#'
#' @return
#' The same object, but with converted names.
snakeCaseToCamelCaseNames <- function(object) {
  names(object) <- snakeCaseToCamelCase(names(object))
  return(object)
}

#' Convert the names of an object from camel case to snake case
#'
#' @param object   The object of which the names should be converted
#'
#' @return
#' The same object, but with converted names.
camelCaseToSnakeCaseNames <- function(object) {
  names(object) <- camelCaseToSnakeCase(names(object))
  return(object)
}

#' helper function to check class of input
#'
#' @param parameter the input parameter to check
#' @param classes which classes it should belong to (one or more)
checkIsClass <- function(parameter, classes) {
  name <- deparse(substitute(parameter))
  if (!inherits(x = parameter, what = classes)) {
    ParallelLogger::logError(paste0(name, " should be of class:", classes, " "))
    stop(paste0(name, " is wrong class"))
  }
  return(TRUE)
}

#' helper function to check that input is higher than a certain value
#'
#' @param parameter the input parameter to check, can be a vector
#' @param value which value it should be higher than
checkHigher <- function(parameter, value) {
  name <- deparse(substitute(parameter))
  if (!is.numeric(parameter) || all(parameter <= value)) {
    ParallelLogger::logError(paste0(name, " needs to be > ", value))
    stop(paste0(name, " needs to be > ", value))
  }
  return(TRUE)
}

#' helper function to check that input is higher or equal than a certain value
#'
#' @param parameter the input parameter to check, can be a vector
#' @param value which value it should be higher or equal than
checkHigherEqual <- function(parameter, value) {
  name <- deparse(substitute(parameter))
  if (!is.numeric(parameter) || all(parameter < value)) {
    ParallelLogger::logError(paste0(name, " needs to be >= ", value))
    stop(paste0(name, " needs to be >= ", value))
  }
  return(TRUE)
}

#' helper function to check if a file exists
#' @param file the file to check
checkFileExists <- function(file) {
  if (!file.exists(file)) {
    ParallelLogger::logError(paste0("File ", file, " does not exist"))
    stop(paste0("File ", file, " does not exist"))
  }
  return(TRUE)
}

checkInStringVector <- function(parameter, values) {
  name <- deparse(substitute(parameter))
  if (!parameter %in% values) {
    ParallelLogger::logError(paste0(
      name, " should be ",
      paste0(as.character(values),
        collapse = "or "
      )
    ))
    stop(paste0(name, " has incorrect value"))
  }
  return(TRUE)
}

# is included from R4.4.0
if (!exists("%||%", "package:base")) `%||%` <- function(x, y) if (is.null(x)) y else x

#' Use polars instead of pandas for default conversion from R to Python
#' @exportS3Method reticulate::r_to_py data.frame
#' @param x A data.frame object in R
#' @param convert Logical, whether to convert the data types to Python types
#' @return A polars DataFrame object in Python
r_to_py.data.frame <- function(x, convert = FALSE) {
  if (!requireNamespace("reticulate", quietly = TRUE)) {
    stop("package \"reticulate\" is required")
  }

  if (reticulate::py_module_available("polars")) {
    pl <- reticulate::import("polars", convert = FALSE)
    toPyCol <- function(col) {

        if (is.factor(col))
          col <- as.character(col)

        if (is.atomic(col)) {
          col <- lapply(col, function(v) if (is.na(v)) NULL else v)
        }

        reticulate::r_to_py(col, convert = FALSE)
      }
    columns <- lapply(x, toPyCol)
    names(columns) <- names(x)

    pdf <- pl$DataFrame(columns)

    return(pdf)
  } else {
    stop("package \"polars\" is required")
  }
}

#' Use polars instead of pandas for default conversion from python to R
#' @exportS3Method reticulate::py_to_r polars.dataframe.frame.DataFrame
#' @param x A polars DataFrame object
#' @return The same data.frame in R
py_to_r.polars.dataframe.frame.DataFrame <- function(x) {
  lst <- py_to_r(x$to_dict(as_series = FALSE))
  dtypes <- py_to_r(x$dtypes)
  lst <- noneToNA(lst, dtypes)
  df <- data.frame(lst)
  return(df)
}

# Convert a list with NULL values to correct NA values
noneToNA <- function(x, dtypes) {
  Map(function(col, dtype) {
    if (is.atomic(col)) {
      return(col)
    }
    dtype <- as.character(dtype)

    proto <- if (dtype %in% c("Float32", "Float64", "f32", "f64")) {
      NA_real_
    } else if (dtype %in% c("Int32", "Int64", "i32", "i64")) {
      NA_integer_
    } else if (dtype %in% c("Boolean", "bool")) {
      NA
    } else {
      NA_character_
    }
    vapply(col, function(v) {
      if (is.null(v)) proto else v
    }, proto)
  },
  col = x,
  dtype = dtypes)
}

#' Expand a Component's Hyperparameter Grid
#'
#' This function takes a user-defined setting for a configurable component
#' (like a positional encoding) and expands it
#' into a flat list of all possible configurations. This list can then be
#' used directly within a `paramGrid` for `PatientLevelPrediction::listCartesian`.
#'
#' @param componentSetting The user's setting for the component. This can be:
#'   - A single string (e.g., "AdamW").
#'   - A single named list representing one configuration (e.g., `list(name = "AdamW", lr = 0.001)`).
#'   - A list of named lists, where each list is a template for configurations.
#'     Vectors within these templates will be expanded (e.g., `lr = c(0.001, 0.0001)`).
#'
#' @return A list where each element is a fully-specified, named list for one
#'         component configuration.
expandComponentGrid <- function(componentSetting) {
  if (!is.list(componentSetting)) {
    return(list(list(name = componentSetting)))
  } else if ("name" %in% names(componentSetting)) {
    return(.expandSingleTemplate(componentSetting))
  } else {
    expandedConfigs <- lapply(componentSetting, .expandSingleTemplate)
    return(do.call(c, expandedConfigs))
  }
}

.expandSingleTemplate <- function(configTemplate) {
  
  isSubGrid <- sapply(configTemplate, is.list)
  
  subGrids <- configTemplate[isSubGrid]
  mainParams <- configTemplate[!isSubGrid]
  mainGrid <- PatientLevelPrediction::listCartesian(mainParams)
  mainGrid <- lapply(mainGrid, function(cfg) {
    cfg[] <- lapply(cfg, function(v) if (is.factor(v)) as.character(v) else v)
    cfg
  })
  
  expandedSubGrids <- lapply(subGrids, expandComponentGrid)
  
  if (length(expandedSubGrids) == 0) {
    return(mainGrid)
  }
  
  allGridsForCartesian <- c(
    list(mainGrid = mainGrid), 
    expandedSubGrids
  )
  
  combinedGrid <- PatientLevelPrediction::listCartesian(allGridsForCartesian)
  
  finalGrid <- lapply(combinedGrid, function(item) {
    c(item$mainGrid, item[names(item) != "mainGrid"])
  })
  
  return(finalGrid)
}

keepDefaults <- function(defaultSettings, userSettings) {
  if (!is.null(userSettings) && !is.list(userSettings)) {
    stop("Settings argument must be a list.")
  }
  userSettingsNames <- names(userSettings)
  defaultSettings[userSettingsNames] <- userSettings

  return(defaultSettings)
}

