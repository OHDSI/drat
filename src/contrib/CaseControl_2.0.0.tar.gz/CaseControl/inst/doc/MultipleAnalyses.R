## ---- echo = FALSE, message = FALSE, warning = FALSE--------------------------
library(CaseControl)
outputFolder <- "s:/temp/vignetteCaseControl2"
knitr::opts_chunk$set(
  cache = FALSE,
  comment = "#>",
  error = FALSE,
  tidy = FALSE)

## ----tidy=FALSE,eval=FALSE----------------------------------------------------
#  connectionDetails <- createConnectionDetails(dbms = "postgresql",
#                                               server = "localhost/ohdsi",
#                                               user = "joe",
#                                               password = "supersecret")
#  
#  outputFolder <- "/home/caseControlOutput"
#  
#  cdmDatabaseSchema <- "my_cdm_data"
#  cohortDatabaseSchema <- "my_work_schema"
#  cohortTable <- "vignette_cohorts"

## ----tidy=FALSE,eval=FALSE----------------------------------------------------
#  library(SqlRender)
#  sql <- readSql("vignette.sql")
#  sql <- render(sql,
#                cdmDatabaseSchema = cdmDatabaseSchema,
#                cohortDatabaseSchema = cohortDatabaseSchema,
#                cohortTable = cohortTable)
#  sql <- translate(sql, targetDialect = connectionDetails$dbms)
#  
#  connection <- connect(connectionDetails)
#  executeSql(connection, sql)

## ----tidy=FALSE,eval=FALSE----------------------------------------------------
#  negativeControls <- c(705178,
#                        705944,
#                        710650,
#                        714785,
#                        719174,
#                        719311,
#                        735340,
#                        742185,
#                        780369,
#                        781182,
#                        924724,
#                        990760,
#                        1110942,
#                        1111706,
#                        1136601,
#                        1317967,
#                        1501309,
#                        1505346,
#                        1551673,
#                        1560278,
#                        1584910,
#                        19010309,
#                        40163731)
#  diclofenac <- 1124300
#  giBleed <- 1
#  rheumatoidArthritis <- 2
#  
#  exposureOutcomeNcList <- list()
#  for (exposureId in c(diclofenac, negativeControls)) {
#    exposureOutcomeNc <- createExposureOutcomeNestingCohort(exposureId = exposureId,
#                                                            outcomeId = giBleed,
#                                                            nestingCohortId = rheumatoidArthritis)
#    exposureOutcomeNcList[[length(exposureOutcomeNcList) + 1]] <- exposureOutcomeNc
#  }
#  

## ----tidy=FALSE,eval=TRUE-----------------------------------------------------
getDbCaseDataArgs1 <- createGetDbCaseDataArgs(useNestingCohort = FALSE,
                                              getVisits = FALSE)

matchingCriteria1 <- createMatchingCriteria(controlsPerCase = 2,
                                           matchOnAge = TRUE,
                                           ageCaliper = 2,
                                           matchOnGender = TRUE,
                                           matchOnProvider = FALSE,
                                           matchOnVisitDate = FALSE)

selectControlsArgs1 <- createSelectControlsArgs(firstOutcomeOnly = FALSE,
                                                washoutPeriod = 180,
                                                controlSelectionCriteria = matchingCriteria1)

getDbExposureDataArgs1 <- createGetDbExposureDataArgs()

createCaseControlDataArgs1 <- createCreateCaseControlDataArgs(firstExposureOnly = FALSE,
                                                              riskWindowStart = 0,
                                                              riskWindowEnd = 0)

fitCaseControlModelArgs1 <- createFitCaseControlModelArgs()

## ----tidy=FALSE,eval=TRUE-----------------------------------------------------
ccAnalysis1 <- createCcAnalysis(analysisId = 1,
                                description = "Matching on age and gender",
                                getDbCaseDataArgs = getDbCaseDataArgs1,
                                selectControlsArgs = selectControlsArgs1,
                                getDbExposureDataArgs = getDbExposureDataArgs1,
                                createCaseControlDataArgs = createCaseControlDataArgs1,
                                fitCaseControlModelArgs = fitCaseControlModelArgs1)

## ----tidy=FALSE,eval=TRUE-----------------------------------------------------
getDbCaseDataArgs2 <- createGetDbCaseDataArgs(useNestingCohort = TRUE,
                                              getVisits = TRUE)

ccAnalysis2 <- createCcAnalysis(analysisId = 2,
                                description = "Matching on age and gender, nesting in indication",
                                getDbCaseDataArgs = getDbCaseDataArgs2,
                                selectControlsArgs = selectControlsArgs1,
                                getDbExposureDataArgs = getDbExposureDataArgs1,
                                createCaseControlDataArgs = createCaseControlDataArgs1,
                                fitCaseControlModelArgs = fitCaseControlModelArgs1)

covariateSettings <- createCovariateSettings(useCharlsonIndex = TRUE,
                                             useChads2 = TRUE,
                                             useDcsi = TRUE)

getDbExposureDataArgs2 <- createGetDbExposureDataArgs(covariateSettings = covariateSettings)

fitCaseControlModelArgs2 <- createFitCaseControlModelArgs(useCovariates = TRUE,
                                                          prior = createPrior("none"))

ccAnalysis3 <- createCcAnalysis(analysisId = 3,
                                description = "Matching on age and gender, nesting in indication, using covars",
                                getDbCaseDataArgs = getDbCaseDataArgs2,
                                selectControlsArgs = selectControlsArgs1,
                                getDbExposureDataArgs = getDbExposureDataArgs2,
                                createCaseControlDataArgs = createCaseControlDataArgs1,
                                fitCaseControlModelArgs = fitCaseControlModelArgs2)

matchingCriteria2 <- createMatchingCriteria(controlsPerCase = 2,
                                            matchOnAge = TRUE,
                                            ageCaliper = 2,
                                            matchOnGender = TRUE,
                                            matchOnProvider = FALSE,
                                            matchOnVisitDate = TRUE,
                                            visitDateCaliper = 30)

selectControlsArgs2 <- createSelectControlsArgs(firstOutcomeOnly = FALSE,
                                                washoutPeriod = 180,
                                                controlSelectionCriteria = matchingCriteria2)

ccAnalysis4 <- createCcAnalysis(analysisId = 4,
                                description = "Matching on age, gender and visit, nesting in indication, using covars",
                                getDbCaseDataArgs = getDbCaseDataArgs2,
                                selectControlsArgs = selectControlsArgs2,
                                getDbExposureDataArgs = getDbExposureDataArgs2,
                                createCaseControlDataArgs = createCaseControlDataArgs1,
                                fitCaseControlModelArgs = fitCaseControlModelArgs2)

samplingCriteria <- createSamplingCriteria(controlsPerCase = 2)

selectControlsArgs3 <- createSelectControlsArgs(firstOutcomeOnly = FALSE,
                                                washoutPeriod = 180,
                                                controlSelectionCriteria = samplingCriteria)

covariateSettings <- createCovariateSettings(useDemographicsAgeGroup = TRUE,
                                             useDemographicsGender = TRUE)

getDbExposureDataArgs3 <- createGetDbExposureDataArgs(covariateSettings = covariateSettings)

ccAnalysis5 <- createCcAnalysis(analysisId = 5,
                                description = "Sampling controls, adjusting for age and gender",
                                getDbCaseDataArgs = getDbCaseDataArgs1,
                                selectControlsArgs = selectControlsArgs3,
                                getDbExposureDataArgs = getDbExposureDataArgs3,
                                createCaseControlDataArgs = createCaseControlDataArgs1,
                                fitCaseControlModelArgs = fitCaseControlModelArgs2)

ccAnalysis6 <- createCcAnalysis(analysisId = 6,
                                description = "Sampling controls, adjusting for age and gender, nesting in indication",
                                getDbCaseDataArgs = getDbCaseDataArgs2,
                                selectControlsArgs = selectControlsArgs3,
                                getDbExposureDataArgs = getDbExposureDataArgs3,
                                createCaseControlDataArgs = createCaseControlDataArgs1,
                                fitCaseControlModelArgs = fitCaseControlModelArgs2)

## ----tidy=FALSE,eval=TRUE-----------------------------------------------------
ccAnalysisList <- list(ccAnalysis1, ccAnalysis2, ccAnalysis3, ccAnalysis4, ccAnalysis5, ccAnalysis6)

## ----tidy=FALSE,eval=TRUE-----------------------------------------------------
outcomeIds = list(narrowDefinition = 1,
                  broadDefinition = 11)

exposureOutcomeNc <- createExposureOutcomeNestingCohort(exposureId = 1124300,
                                                        outcomeId = outcomeIds,
                                                        nestingCohortId = 2)

## ----tidy=FALSE,eval=TRUE-----------------------------------------------------
ccAnalysis1A <- createCcAnalysis(analysisId = 1,
                                description = "Matching on age and gender, using narrow def.",
                                outcomeType = "narrowDefinition",
                                getDbCaseDataArgs = getDbCaseDataArgs1,
                                selectControlsArgs = selectControlsArgs1,
                                getDbExposureDataArgs = getDbExposureDataArgs1,
                                createCaseControlDataArgs = createCaseControlDataArgs1,
                                fitCaseControlModelArgs = fitCaseControlModelArgs1)

ccAnalysis1B <- createCcAnalysis(analysisId = 2,
                                description = "Matching on age and gender, using broad def.",
                                outcomeType = "broadDefinition",
                                getDbCaseDataArgs = getDbCaseDataArgs1,
                                selectControlsArgs = selectControlsArgs1,
                                getDbExposureDataArgs = getDbExposureDataArgs1,
                                createCaseControlDataArgs = createCaseControlDataArgs1,
                                fitCaseControlModelArgs = fitCaseControlModelArgs1)

ccAnalysisList2 <- list(ccAnalysis1A, ccAnalysis1B)

## ----tidy=FALSE,eval=FALSE----------------------------------------------------
#  result <- runCcAnalyses(connectionDetails = connectionDetails,
#                          cdmDatabaseSchema = cdmDatabaseSchema,
#                          oracleTempSchema = cdmDatabaseSchema,
#                          exposureDatabaseSchema = cdmDatabaseSchema,
#                          exposureTable = "drug_era",
#                          outcomeDatabaseSchema = cohortDatabaseSchema,
#                          outcomeTable = cohortTable,
#                          nestingCohortDatabaseSchema = cohortDatabaseSchema,
#                          nestingCohortTable = cohortTable,
#                          outputFolder = outputFolder,
#                          exposureOutcomeNestingCohortList = exposureOutcomeNcList,
#                          ccAnalysisList = ccAnalysisList,
#                          getDbCaseDataThreads = 1,
#                          selectControlsThreads = 2,
#                          getDbExposureDataThreads = 3,
#                          createCaseControlDataThreads = 5,
#                          fitCaseControlModelThreads = 5,
#                          cvThreads = 3)

## ----tidy=FALSE,eval=FALSE----------------------------------------------------
#  ccModelFile <- result$modelFile[result$exposureId == 1124300 &
#                                    result$outcomeId == 1 &
#                                    result$analysisId == 1]
#  ccModel <- readRDS(file.path(outputFolder, ccModelFile))
#  summary(ccModel)

## ----echo=FALSE,message=FALSE-------------------------------------------------
if (file.exists("s:/temp/vignetteCaseControl2/outcomeModelReference.rds")) {
  result <- readRDS("s:/temp/vignetteCaseControl2/outcomeModelReference.rds")
  ccModelFile <- result$modelFile[result$exposureId == 1124300 & 
                                    result$outcomeId == 1 &
                                    result$analysisId == 1]
  ccModel <- readRDS(file.path(outputFolder, ccModelFile))
  summary(ccModel)
}

## ----tidy=FALSE,eval=FALSE----------------------------------------------------
#  analysisSum <- summarizeCcAnalyses(result, outputFolder)
#  head(analysisSum)

## ----echo=FALSE,message=FALSE-------------------------------------------------
if (file.exists("s:/temp/vignetteCaseControl2/outcomeModelReference.rds")) {
  analysisSum <- summarizeCcAnalyses(result, outputFolder)
  head(analysisSum)
}

## ----tidy=FALSE,eval=FALSE----------------------------------------------------
#  library(EmpiricalCalibration)
#  
#  # Analysis 1: Simplest model
#  negCons <- analysisSum[analysisSum$analysisId == 1 & analysisSum$exposureId != 1124300, ]
#  ei <-  analysisSum[analysisSum$analysisId == 1 & analysisSum$exposureId == 1124300, ]
#  null <- fitNull(negCons$logRr, negCons$seLogRr)
#  plotCalibrationEffect(logRrNegatives = negCons$logRr,
#                        seLogRrNegatives = negCons$seLogRr,
#                        logRrPositives = ei$logRr,
#                        seLogRrPositives = ei$seLogRr,
#                        null)

## ----echo=FALSE,message=FALSE,eval=TRUE---------------------------------------
if (file.exists("s:/temp/vignetteCaseControl2/outcomeModelReference.rds")) {
  library(EmpiricalCalibration)
  negCons <- analysisSum[analysisSum$analysisId == 1 & analysisSum$exposureId != 1124300, ]
  ei <-  analysisSum[analysisSum$analysisId == 1 & analysisSum$exposureId == 1124300, ]
  null <- fitNull(negCons$logRr, negCons$seLogRr)
  plotCalibrationEffect(logRrNegatives = negCons$logRr, 
                        seLogRrNegatives = negCons$seLogRr, 
                        logRrPositives = ei$logRr, 
                        seLogRrPositives = ei$seLogRr, 
                        null)
}

## ----tidy=FALSE,eval=FALSE----------------------------------------------------
#  # Analysis 2: Nesting in rheumatoid arthritis
#  negCons <- analysisSum[analysisSum$analysisId == 2 & analysisSum$exposureId != 1124300, ]
#  ei <-  analysisSum[analysisSum$analysisId == 2 & analysisSum$exposureId == 1124300, ]
#  null <- fitNull(negCons$logRr, negCons$seLogRr)
#  plotCalibrationEffect(logRrNegatives = negCons$logRr,
#                        seLogRrNegatives = negCons$seLogRr,
#                        logRrPositives = ei$logRr,
#                        seLogRrPositives = ei$seLogRr,
#                        null)

## ----echo=FALSE,message=FALSE,eval=TRUE---------------------------------------
if (file.exists("s:/temp/vignetteCaseControl2/outcomeModelReference.rds")) {
  library(EmpiricalCalibration)
  negCons <- analysisSum[analysisSum$analysisId == 2 & analysisSum$exposureId != 1124300, ]
  ei <-  analysisSum[analysisSum$analysisId == 2 & analysisSum$exposureId == 1124300, ]
  null <- fitNull(negCons$logRr, negCons$seLogRr)
  plotCalibrationEffect(logRrNegatives = negCons$logRr, 
                        seLogRrNegatives = negCons$seLogRr, 
                        logRrPositives = ei$logRr, 
                        seLogRrPositives = ei$seLogRr, 
                        null)
}

## ----tidy=FALSE,eval=FALSE----------------------------------------------------
#  # Analysis 3: Nesting and including covariates
#  negCons <- analysisSum[analysisSum$analysisId == 3 & analysisSum$exposureId != 1124300, ]
#  ei <-  analysisSum[analysisSum$analysisId == 3 & analysisSum$exposureId == 1124300, ]
#  null <- fitNull(negCons$logRr, negCons$seLogRr)
#  plotCalibrationEffect(logRrNegatives = negCons$logRr,
#                        seLogRrNegatives = negCons$seLogRr,
#                        logRrPositives = ei$logRr,
#                        seLogRrPositives = ei$seLogRr,
#                        null)

## ----echo=FALSE,message=FALSE,eval=TRUE---------------------------------------
if (file.exists("s:/temp/vignetteCaseControl2/outcomeModelReference.rds")) {
  library(EmpiricalCalibration)
  negCons <- analysisSum[analysisSum$analysisId == 3 & analysisSum$exposureId != 1124300, ]
  ei <-  analysisSum[analysisSum$analysisId == 3 & analysisSum$exposureId == 1124300, ]
  null <- fitNull(negCons$logRr, negCons$seLogRr)
  plotCalibrationEffect(logRrNegatives = negCons$logRr, 
                        seLogRrNegatives = negCons$seLogRr, 
                        logRrPositives = ei$logRr, 
                        seLogRrPositives = ei$seLogRr, 
                        null)
}

## ----tidy=FALSE,eval=FALSE----------------------------------------------------
#  # Analysis 4: Nesting, including covariates, and matching on visit
#  negCons <- analysisSum[analysisSum$analysisId == 4 & analysisSum$exposureId != 1124300, ]
#  ei <-  analysisSum[analysisSum$analysisId == 4 & analysisSum$exposureId == 1124300, ]
#  null <- fitNull(negCons$logRr, negCons$seLogRr)
#  plotCalibrationEffect(logRrNegatives = negCons$logRr,
#                        seLogRrNegatives = negCons$seLogRr,
#                        logRrPositives = ei$logRr,
#                        seLogRrPositives = ei$seLogRr,
#                        null)

## ----echo=FALSE,message=FALSE,eval=TRUE---------------------------------------
if (file.exists("s:/temp/vignetteCaseControl2/outcomeModelReference.rds")) {
  library(EmpiricalCalibration)
  negCons <- analysisSum[analysisSum$analysisId == 4 & analysisSum$exposureId != 1124300, ]
  ei <-  analysisSum[analysisSum$analysisId == 4 & analysisSum$exposureId == 1124300, ]
  null <- fitNull(negCons$logRr, negCons$seLogRr)
  plotCalibrationEffect(logRrNegatives = negCons$logRr, 
                        seLogRrNegatives = negCons$seLogRr, 
                        logRrPositives = ei$logRr, 
                        seLogRrPositives = ei$seLogRr, 
                        null)
}

## ----tidy=FALSE,eval=FALSE----------------------------------------------------
#  # Analysis 5: Sampling controls, adjusting for age and gender
#  negCons <- analysisSum[analysisSum$analysisId == 5 & analysisSum$exposureId != 1124300, ]
#  ei <-  analysisSum[analysisSum$analysisId == 5 & analysisSum$exposureId == 1124300, ]
#  null <- fitNull(negCons$logRr, negCons$seLogRr)
#  plotCalibrationEffect(logRrNegatives = negCons$logRr,
#                        seLogRrNegatives = negCons$seLogRr,
#                        logRrPositives = ei$logRr,
#                        seLogRrPositives = ei$seLogRr,
#                        null)

## ----echo=FALSE,message=FALSE,eval=TRUE---------------------------------------
if (file.exists("s:/temp/vignetteCaseControl2/outcomeModelReference.rds")) {
  library(EmpiricalCalibration)
  negCons <- analysisSum[analysisSum$analysisId == 5 & analysisSum$exposureId != 1124300, ]
  ei <-  analysisSum[analysisSum$analysisId == 5 & analysisSum$exposureId == 1124300, ]
  null <- fitNull(negCons$logRr, negCons$seLogRr)
  plotCalibrationEffect(logRrNegatives = negCons$logRr, 
                        seLogRrNegatives = negCons$seLogRr, 
                        logRrPositives = ei$logRr, 
                        seLogRrPositives = ei$seLogRr, 
                        null)
}

## ----tidy=FALSE,eval=FALSE----------------------------------------------------
#  # Analysis 6: Sampling controls, adjusting for age and gender, nesting in indication
#  negCons <- analysisSum[analysisSum$analysisId == 6 & analysisSum$exposureId != 1124300, ]
#  ei <-  analysisSum[analysisSum$analysisId == 6 & analysisSum$exposureId == 1124300, ]
#  null <- fitNull(negCons$logRr, negCons$seLogRr)
#  plotCalibrationEffect(logRrNegatives = negCons$logRr,
#                        seLogRrNegatives = negCons$seLogRr,
#                        logRrPositives = ei$logRr,
#                        seLogRrPositives = ei$seLogRr,
#                        null)

## ----echo=FALSE,message=FALSE,eval=TRUE---------------------------------------
if (file.exists("s:/temp/vignetteCaseControl2/outcomeModelReference.rds")) {
  library(EmpiricalCalibration)
  negCons <- analysisSum[analysisSum$analysisId == 6 & analysisSum$exposureId != 1124300, ]
  ei <-  analysisSum[analysisSum$analysisId == 6 & analysisSum$exposureId == 1124300, ]
  null <- fitNull(negCons$logRr, negCons$seLogRr)
  plotCalibrationEffect(logRrNegatives = negCons$logRr, 
                        seLogRrNegatives = negCons$seLogRr, 
                        logRrPositives = ei$logRr, 
                        seLogRrPositives = ei$seLogRr, 
                        null)
}

## ----tidy=TRUE,eval=TRUE------------------------------------------------------
citation("CaseControl")

## ----tidy=TRUE,eval=TRUE------------------------------------------------------
citation("Cyclops")

