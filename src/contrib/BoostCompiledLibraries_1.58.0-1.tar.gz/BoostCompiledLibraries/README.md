# BoostCompiledLibraries: Boost libraries for R 

## About

This package provides [R](http://www.r-project.org) with access to several
[Boost](http://www.boost.org/) compile-time linked libraries.  
[Boost](http://www.boost.org/)
provides free peer-reviewed portable C++ source libraries.  
The [BH](http://dirk.eddelbuettel.com/code/bh.html) package provides a useful subset of 
[Boost](http://www.boost.org/) header-file only libraries.  

## List of libraries 

## Linking instructions

## License

This package is provided under the same license as Boost itself, the BSL-1.0