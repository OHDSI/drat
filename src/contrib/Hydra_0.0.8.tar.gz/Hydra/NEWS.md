Hydra 0.0.5
===========

Bugfixes:

1. Several bugfixes in the ComparativeEffectStudy Shiny app