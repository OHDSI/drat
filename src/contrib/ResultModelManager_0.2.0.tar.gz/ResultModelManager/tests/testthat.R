library(testthat)
library(ResultModelManager)

test_check("ResultModelManager")
