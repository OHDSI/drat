library(testthat)
library(MethodEvaluation)

test_check("MethodEvaluation")
