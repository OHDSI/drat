## ----echo = FALSE, message = FALSE, warning = FALSE---------------------------
library(SelfControlledCaseSeries)
outputFolder <- "s:/temp/sccsVignette2"

## ----eval=TRUE,eval=FALSE-----------------------------------------------------
#  connectionDetails <- createConnectionDetails(dbms = "postgresql",
#                                               server = "localhost/ohdsi",
#                                               user = "joe",
#                                               password = "supersecret")
#  
#  outputFolder <- "s:/temp/sccsVignette2"
#  
#  cdmDatabaseSchema <- "my_cdm_data"
#  cohortDatabaseSchema <- "my_cohorts"
#  options(sqlRenderTempEmulationSchema = NULL)
#  cdmVersion <- "5"

## ----eval=FALSE---------------------------------------------------------------
#  library(SqlRender)
#  sql <- readSql("vignette.sql")
#  sql <- render(sql,
#                cdmDatabaseSchema = cdmDatabaseSchema,
#                cohortDatabaseSchema = cohortDatabaseSchema)
#  sql <- translate(sql, targetDialect = connectionDetails$dbms)
#  
#  connection <- connect(connectionDetails)
#  executeSql(connection, sql)

## ----eval=FALSE---------------------------------------------------------------
#  negativeControls <- c(705178, 705944, 710650, 714785, 719174, 719311, 735340, 742185,
#                        780369, 781182, 924724, 990760, 1110942, 1111706, 1136601,
#                        1317967, 1501309, 1505346, 1551673, 1560278, 1584910, 19010309,
#                        40163731)
#  diclofenac <- 1124300
#  ppis <- c(911735, 929887, 923645, 904453, 948078, 19039926)
#  
#  exposureOutcomeList <- list()
#  for (exposureId in c(diclofenac, negativeControls)){
#    exposureOutcome <- createExposureOutcome(exposureId = exposureId,
#                                             outcomeId = 1,
#                                             prophylactics = ppis)
#    exposureOutcomeList[[length(exposureOutcomeList) + 1]] <- exposureOutcome
#  }

## ----eval=TRUE----------------------------------------------------------------
getDbSccsDataArgs1 <- createGetDbSccsDataArgs(
  useCustomCovariates = FALSE,
  deleteCovariatesSmallCount = 100,
  studyStartDate = "",
  studyEndDate = "",
  exposureIds = c(),
  maxCasesPerOutcome = 1000)

createStudyPopulationArgs1 <- createCreateStudyPopulationArgs(
  naivePeriod = 180,
  firstOutcomeOnly = FALSE)

covarExposureOfInt <- createEraCovariateSettings(
  label = "Exposure of interest",
  includeEraIds = "exposureId",
  start = 1,
  end = 0,
  endAnchor = "era end")

createSccsIntervalDataArgs1 <- createCreateSccsIntervalDataArgs(
  eraCovariateSettings = covarExposureOfInt)

fitSccsModelArgs <- createFitSccsModelArgs()

## ----eval=TRUE----------------------------------------------------------------
sccsAnalysis1 <- createSccsAnalysis(analysisId = 1,
                                    description = "Simplest model",
                                    getDbSccsDataArgs = getDbSccsDataArgs1,
                                    createStudyPopulationArgs = createStudyPopulationArgs1,
                                    createSccsIntervalDataArgs = createSccsIntervalDataArgs1,
                                    fitSccsModelArgs = fitSccsModelArgs)

## ----eval=TRUE----------------------------------------------------------------
covarProphylactics <- createEraCovariateSettings(
  label = "Prophylactics",
  includeEraIds = "prophylactics",
  start = 1,
  end = 0,
  endAnchor = "era end")

createSccsIntervalDataArgs2 <- createCreateSccsIntervalDataArgs(
  eraCovariateSettings = list(covarExposureOfInt,
                             covarProphylactics))

sccsAnalysis2 <- createSccsAnalysis(
  analysisId = 2,
  description = "Including prophylactics",
  getDbSccsDataArgs = getDbSccsDataArgs1,
  createStudyPopulationArgs = createStudyPopulationArgs1,
  createSccsIntervalDataArgs = createSccsIntervalDataArgs2,
  fitSccsModelArgs = fitSccsModelArgs)

ageSettings <- createAgeCovariateSettings(ageKnots = 5)

seasonalitySettings <- createSeasonalityCovariateSettings(seasonKnots = 5)

covarPreExp <- createEraCovariateSettings(
  label = "Pre-exposure",
  includeEraIds = "exposureId",
  start = -30,
  end = -1,
  endAnchor = "era start")

createSccsIntervalDataArgs3 <- createCreateSccsIntervalDataArgs(
  eraCovariateSettings = list(covarExposureOfInt,
                              covarPreExp,
                              covarProphylactics),
  ageCovariateSettings = ageSettings,
  seasonalityCovariateSettings = seasonalitySettings,
  eventDependentObservation = TRUE)

sccsAnalysis3 <- createSccsAnalysis(
  analysisId = 3,
  description = "Including prophylactics, age, season, pre-exposure, and censoring",
  getDbSccsDataArgs = getDbSccsDataArgs1,
  createStudyPopulationArgs = createStudyPopulationArgs1,
  createSccsIntervalDataArgs = createSccsIntervalDataArgs3,
  fitSccsModelArgs = fitSccsModelArgs)

covarAllDrugs <- createEraCovariateSettings(
  label = "Other exposures",
  excludeEraIds = "exposureId",
  stratifyById = TRUE,
  start = 1,
  end = 0,
  endAnchor = "era end",
  allowRegularization = TRUE)

createSccsIntervalDataArgs4 <- createCreateSccsIntervalDataArgs(
  eraCovariateSettings = list(covarExposureOfInt,
                              covarPreExp,
                              covarAllDrugs),
  ageCovariateSettings = ageSettings,
  seasonalityCovariateSettings = seasonalitySettings,
  eventDependentObservation = TRUE)

sccsAnalysis4 <- createSccsAnalysis(
  analysisId = 4,
  description = "Including all other drugs",
  getDbSccsDataArgs = getDbSccsDataArgs1,
  createStudyPopulationArgs = createStudyPopulationArgs1,
  createSccsIntervalDataArgs = createSccsIntervalDataArgs4,
  fitSccsModelArgs = fitSccsModelArgs)

## ----eval=TRUE----------------------------------------------------------------
sccsAnalysisList <- list(sccsAnalysis1, sccsAnalysis2, sccsAnalysis3, sccsAnalysis4)

## ----eval=TRUE----------------------------------------------------------------
outcomeIds = list(narrowDefinition = 1,
                  broadDefinition = 2)

exposureOutcome <- createExposureOutcome(
  exposureId = 1124300,
  outcomeId = outcomeIds)

## ----eval=TRUE----------------------------------------------------------------
sccsAnalysisA <- createSccsAnalysis(
  analysisId = 1,
  description = "Simplest model, using narrow def.",
  outcomeType = "narrowDefinition",
  getDbSccsDataArgs = getDbSccsDataArgs1,
  createStudyPopulationArgs = createStudyPopulationArgs1,
  createSccsIntervalDataArgs = createSccsIntervalDataArgs1,
  fitSccsModelArgs = fitSccsModelArgs)

sccsAnalysisB <- createSccsAnalysis(
  analysisId = 2,
  description = "Simplest model, using broad def.",
  outcomeType = "broadDefinition",
  getDbSccsDataArgs = getDbSccsDataArgs1,
  createStudyPopulationArgs = createStudyPopulationArgs1,
  createSccsIntervalDataArgs = createSccsIntervalDataArgs1,
  fitSccsModelArgs = fitSccsModelArgs)

sccsAnalysisList2 <- list(sccsAnalysisA, sccsAnalysisB)

## ----eval=FALSE---------------------------------------------------------------
#  result <- runSccsAnalyses(
#    connectionDetails = connectionDetails,
#    cdmDatabaseSchema = cdmDatabaseSchema,
#    exposureDatabaseSchema = cdmDatabaseSchema,
#    exposureTable = "drug_era",
#    outcomeDatabaseSchema = cohortDatabaseSchema,
#    outcomeTable = outcomeTable,
#    cdmVersion = cdmVersion,
#    outputFolder = outputFolder,
#    combineDataFetchAcrossOutcomes = TRUE,
#    exposureOutcomeList = exposureOutcomeList,
#    sccsAnalysisList = sccsAnalysisList,
#    getDbSccsDataThreads = 1,
#    createStudyPopulationThreads = 3,
#    createSccsIntervalDataThreads = 3,
#    fitSccsModelThreads = 4,
#    cvThreads = 10)
#  

## ----eval=FALSE---------------------------------------------------------------
#  sccsModelFile <- result$sccsModelFile[result$exposureId == 1124300 &
#                                        result$outcomeId == 1 &
#                                        result$analysisId == 1]
#  sccsModel <- readRDS(file.path(outputFolder, sccsModelFile))
#  sccsModel

## ----echo=FALSE,message=FALSE-------------------------------------------------
if (file.exists(file.path(outputFolder, "outcomeModelReference.rds"))) {
  result <- readRDS(file.path(outputFolder, "outcomeModelReference.rds"))
  sccsModelFile <- result$sccsModelFile[result$exposureId == 1124300 & 
                                          result$outcomeId == 1 &
                                          result$analysisId == 1]
  sccsModel <- readRDS(file.path(outputFolder, sccsModelFile))
  sccsModel
}

## ----eval=FALSE---------------------------------------------------------------
#  analysisSum <- summarizeSccsAnalyses(result, outputFolder)
#  analysisSum

## ----echo=FALSE,message=FALSE-------------------------------------------------
if (file.exists(file.path(outputFolder, "outcomeModelReference.rds"))) {
  analysisSum <- readRDS(file.path(outputFolder, "analysisSummary.rds"))
  analysisSum
}

## ----eval=FALSE---------------------------------------------------------------
#  install.packages("EmpiricalCalibration")
#  library(EmpiricalCalibration)
#  
#  # Analysis 1: Simplest model
#  negCons <- analysisSum[analysisSum$analysisId == 1 & analysisSum$exposureId != 1124300, ]
#  ei <-  analysisSum[analysisSum$analysisId == 1 & analysisSum$exposureId == 1124300, ]
#  null <- fitNull(negCons$`logRr(Exposure of interest)`,
#                  negCons$`seLogRr(Exposure of interest)`)
#  plotCalibrationEffect(logRrNegatives = negCons$`logRr(Exposure of interest)`,
#                        seLogRrNegatives = negCons$`seLogRr(Exposure of interest)`,
#                        logRrPositives = ei$`logRr(Exposure of interest)`,
#                        seLogRrPositives = ei$`seLogRr(Exposure of interest)`,
#                        null)

## ----echo=FALSE,message=FALSE,eval=TRUE---------------------------------------
if (file.exists(file.path(outputFolder, "outcomeModelReference.rds"))) {
  library(EmpiricalCalibration)
  negCons <- analysisSum[analysisSum$analysisId == 1 & analysisSum$exposureId != 1124300, ]
  ei <-  analysisSum[analysisSum$analysisId == 1 & analysisSum$exposureId == 1124300, ]
  null <- fitNull(negCons$`logRr(Exposure of interest)`, 
                  negCons$`seLogRr(Exposure of interest)`)
  plotCalibrationEffect(logRrNegatives = negCons$`logRr(Exposure of interest)`, 
                        seLogRrNegatives = negCons$`seLogRr(Exposure of interest)`, 
                        logRrPositives = ei$`logRr(Exposure of interest)`, 
                        seLogRrPositives = ei$`seLogRr(Exposure of interest)`, 
                        null)
}

## ----eval=FALSE---------------------------------------------------------------
#  # Analysis 2: Including prophylactics
#  negCons <- analysisSum[analysisSum$analysisId == 2 & analysisSum$exposureId != 1124300, ]
#  ei <-  analysisSum[analysisSum$analysisId == 2 & analysisSum$exposureId == 1124300, ]
#  null <- fitNull(negCons$`logRr(Exposure of interest)`,
#                  negCons$`seLogRr(Exposure of interest)`)
#  plotCalibrationEffect(logRrNegatives = negCons$`logRr(Exposure of interest)`,
#                        seLogRrNegatives = negCons$`seLogRr(Exposure of interest)`,
#                        logRrPositives = ei$`logRr(Exposure of interest)`,
#                        seLogRrPositives = ei$`seLogRr(Exposure of interest)`,
#                        null)

## ----echo=FALSE,message=FALSE,eval=TRUE---------------------------------------
if (file.exists(file.path(outputFolder, "outcomeModelReference.rds"))) {
  negCons <- analysisSum[analysisSum$analysisId == 2 & analysisSum$exposureId != 1124300, ]
  ei <-  analysisSum[analysisSum$analysisId == 2 & analysisSum$exposureId == 1124300, ]
  null <- fitNull(negCons$`logRr(Exposure of interest)`, 
                  negCons$`seLogRr(Exposure of interest)`)
  plotCalibrationEffect(logRrNegatives = negCons$`logRr(Exposure of interest)`, 
                        seLogRrNegatives = negCons$`seLogRr(Exposure of interest)`, 
                        logRrPositives = ei$`logRr(Exposure of interest)`, 
                        seLogRrPositives = ei$`seLogRr(Exposure of interest)`, 
                        null)
}

## ----eval=FALSE---------------------------------------------------------------
#  # Analysis 3: Including prophylactics, age, season, pre-exposure, and censoring
#  negCons <- analysisSum[analysisSum$analysisId == 3 & analysisSum$exposureId != 1124300, ]
#  ei <-  analysisSum[analysisSum$analysisId == 3 & analysisSum$exposureId == 1124300, ]
#  null <- fitNull(negCons$`logRr(Exposure of interest)`,
#                  negCons$`seLogRr(Exposure of interest)`)
#  plotCalibrationEffect(logRrNegatives = negCons$`logRr(Exposure of interest)`,
#                        seLogRrNegatives = negCons$`seLogRr(Exposure of interest)`,
#                        logRrPositives = ei$`logRr(Exposure of interest)`,
#                        seLogRrPositives = ei$`seLogRr(Exposure of interest)`,
#                        null)

## ----echo=FALSE,message=FALSE,eval=TRUE---------------------------------------
if (file.exists(file.path(outputFolder, "outcomeModelReference.rds"))) {
  negCons <- analysisSum[analysisSum$analysisId == 3 & analysisSum$exposureId != 1124300, ]
  ei <-  analysisSum[analysisSum$analysisId == 3 & analysisSum$exposureId == 1124300, ]
  null <- fitNull(negCons$`logRr(Exposure of interest)`, 
                  negCons$`seLogRr(Exposure of interest)`)
  plotCalibrationEffect(logRrNegatives = negCons$`logRr(Exposure of interest)`, 
                        seLogRrNegatives = negCons$`seLogRr(Exposure of interest)`, 
                        logRrPositives = ei$`logRr(Exposure of interest)`, 
                        seLogRrPositives = ei$`seLogRr(Exposure of interest)`, 
                        null)
}

## ----eval=FALSE---------------------------------------------------------------
#  # Analysis 4: Including all other drugs (as well as prophylactics, age, season, pre-
#  # exposure, and censoring)
#  negCons <- analysisSum[analysisSum$analysisId == 4 & analysisSum$exposureId != 1124300, ]
#  ei <-  analysisSum[analysisSum$analysisId == 4 & analysisSum$exposureId == 1124300, ]
#  null <- fitNull(negCons$`logRr(Exposure of interest)`,
#                  negCons$`seLogRr(Exposure of interest)`)
#  plotCalibrationEffect(logRrNegatives = negCons$`logRr(Exposure of interest)`,
#                        seLogRrNegatives = negCons$`seLogRr(Exposure of interest)`,
#                        logRrPositives = ei$`logRr(Exposure of interest)`,
#                        seLogRrPositives = ei$`seLogRr(Exposure of interest)`,
#                        null)

## ----echo=FALSE,message=FALSE,eval=TRUE---------------------------------------
if (file.exists(file.path(outputFolder, "outcomeModelReference.rds"))) {
  negCons <- analysisSum[analysisSum$analysisId == 4 & analysisSum$exposureId != 1124300, ]
  ei <-  analysisSum[analysisSum$analysisId == 4 & analysisSum$exposureId == 1124300, ]
  null <- fitNull(negCons$`logRr(Exposure of interest)`, 
                  negCons$`seLogRr(Exposure of interest)`)
  plotCalibrationEffect(logRrNegatives = negCons$`logRr(Exposure of interest)`, 
                        seLogRrNegatives = negCons$`seLogRr(Exposure of interest)`, 
                        logRrPositives = ei$`logRr(Exposure of interest)`, 
                        seLogRrPositives = ei$`seLogRr(Exposure of interest)`, 
                        null)
}

## ----eval=TRUE----------------------------------------------------------------
citation("SelfControlledCaseSeries")

## ----eval=TRUE----------------------------------------------------------------
citation("Cyclops")

