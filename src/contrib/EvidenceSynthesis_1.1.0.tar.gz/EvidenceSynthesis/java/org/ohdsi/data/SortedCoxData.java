/*******************************************************************************
 * Copyright 2025 Observational Health Data Sciences and Informatics
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *   http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 ******************************************************************************/
package org.ohdsi.data;

/**
 * @author Marc A. Suchard
 */
public class SortedCoxData {

    public int[] y;
    public double[] x; // Assumes row-major
    public int[] strata;
    public int[] n;
    public double[] weight;

    public SortedCoxData(int[] y, double[] x, int[] strata, double[] weight) {
        this(y, x, strata, null, weight);
    }

    public SortedCoxData(int[] y, double[] x, int[] strata, int[] n, double[] weight) {
        this.y = y;
        this.x = x;
        this.strata = strata;
        this.n = n;
        this.weight = weight;
    }

    public int getCovariateDimension() {
        return x.length / y.length;
    }
}
