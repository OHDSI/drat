cat("This is libxml2 version", xml2:::libxml2_version(), "\n")
