select cast(%d as int) as tar_id, 
	cast ('%s' as varchar(10)) as tar_start_with, cast (%d as int) as tar_start_offset,
	cast ('%s' as varchar(10)) as tar_end_with, cast (%d as int) as tar_end_offset