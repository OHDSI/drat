package org.ohdsi.cohortincidence;

import java.util.List;

/**
 *
 * @author cknoll1
 */
public class TestParams {
	public String resultSchema;
	public String[] prepDataSets;
	public String designJson;
	public String[] verifyDataSets;
	public List<String> verifyCols;
	public boolean useTempTables;
}
