## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)

## ----eval=FALSE---------------------------------------------------------------
# temporalCovariateSettings <-
#   FeatureExtraction::createTemporalSequenceCovariateSettings(
#     useDemographicsAge = TRUE,
#     useDemographicsGender = TRUE,
#     useConditionOccurrence = TRUE,
#     sequenceStartDay = -365,
#     sequenceEndDay = -1
#   )
# 
# temporalPlpData <- PatientLevelPrediction::getPlpData(
#   databaseDetails = databaseDetails,
#   restrictPlpDataSettings =
#     PatientLevelPrediction::createRestrictPlpDataSettings(),
#   covariateSettings = temporalCovariateSettings
# )

## -----------------------------------------------------------------------------
modelSettings <- DeepPatientLevelPrediction::setTransformer(
  numBlocks = 1L,
  dimToken = 8L,
  dimOut = 1L,
  numHeads = 2L,
  attDropout = 0.0,
  ffnDropout = 0.2,
  dimHidden = 32L,
  temporal = TRUE,
  temporalSettings = list(
    positionalEncoding = list(
      name = "SinusoidalPE",
      dropout = 0.1
    ),
    maxSequenceLength = 256L,
    truncation = "tail",
    timeTokens = FALSE
  ),
  estimatorSettings = DeepPatientLevelPrediction::setEstimator(
    learningRate = 3e-4,
    weightDecay = 1e-6,
    batchSize = 64L,
    epochs = 3L,
    device = "cpu"
  ),
  randomSample = 1L
)

## ----eval=FALSE---------------------------------------------------------------
# temporalTransformerResult <- PatientLevelPrediction::runPlp(
#   plpData = temporalPlpData,
#   outcomeId = 3,
#   modelSettings = modelSettings,
#   analysisId = "TemporalTransformer",
#   analysisName = "Testing temporal transformer",
#   populationSettings = populationSettings,
#   splitSettings = PatientLevelPrediction::createDefaultSplitSetting(
#     splitSeed = 42
#   ),
#   preprocessSettings = PatientLevelPrediction::createPreprocessSettings(),
#   executeSettings = PatientLevelPrediction::createExecuteSettings(
#     runSplitData = TRUE,
#     runSampleData = FALSE,
#     runFeatureEngineering = FALSE,
#     runPreprocessData = TRUE,
#     runModelDevelopment = TRUE,
#     runCovariateSummary = FALSE
#   ),
#   saveDirectory = file.path(tempdir(), "TemporalTransformer")
# )

## ----tidy=TRUE,eval=TRUE------------------------------------------------------
citation("DeepPatientLevelPrediction")

