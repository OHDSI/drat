## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)

## ----message=FALSE------------------------------------------------------------
library(DeepPatientLevelPrediction)

# Pick the model settings from DeepPatientLevelPrediction.
deepLearningModel <- DeepPatientLevelPrediction::setDefaultResNet()

## ----eval=FALSE---------------------------------------------------------------
# # load the data
# plpData <- PatientLevelPrediction::loadPlpData('locationOfData')
# 
# # use PatientLevelPrediction to fit model
# deepLearningResult <- PatientLevelPrediction::runPlp(
#     plpData = plpData,
#     outcomeId = 1230,
#     modelSettings = deepLearningModel,
#     analysisId = 'resNetTorch',
#     populationSettings = populationSettings,
#     saveDirectory = file.path(tempdir(), 'resNetTorch'),
#     ...
#   )
# 

## -----------------------------------------------------------------------------

modelSettings <- setMultiLayerPerceptron(
  numLayers = c(3L, 5L),
  sizeHidden = c(64L, 128L),
  dropout = c(0.2),
  sizeEmbedding = c(32L, 64L),
  estimatorSettings = setEstimator(
    learningRate = c(1e-3, 1e-4),
    weightDecay = c(1e-5),
    batchSize = c(128L),
    epochs=c(5L),
    seed=12L
  ),
  randomSample=10L
)

## ----eval=FALSE---------------------------------------------------------------
# mlpResult <- PatientLevelPrediction::runPlp(
#     plpData = plpData,
#     outcomeId = 3,
#     modelSettings = modelSettings,
#     analysisId = 'MLP',
#     analysisName = 'Testing Deep Learning',
#     populationSettings = populationSettings,
#     splitSettings = PatientLevelPrediction::createDefaultSplitSetting(),
#     preprocessSettings = PatientLevelPrediction::createPreprocessSettings(),
#     executeSettings = PatientLevelPrediction::createExecuteSettings(
#       runSplitData = TRUE,
#       runSampleData = FALSE,
#       runFeatureEngineering = FALSE,
#       runPreprocessData = TRUE,
#       runModelDevelopment = TRUE,
#       runCovariateSummary = FALSE
#     ),
#     saveDirectory = file.path(tempdir(), 'MLP')
#   )
# 

## -----------------------------------------------------------------------------

resnetSettings <- setResNet(
  numLayers = c(2L),
  sizeHidden = c(32L),
  hiddenFactor = c(2L),
  residualDropout = c(0.1),
  hiddenDropout = c(0.1),
  sizeEmbedding = c(32L),
  estimatorSettings = setEstimator(learningRate = c(3e-4),
                                   weightDecay = c(1e-6),
                                   #device='cuda:0', # uncomment to use GPU
                                   batchSize = 128L,
                                   epochs = 3L,
                                   seed = 42L),
  hyperParamSearch = 'random',
  randomSample = 1
)

## ----eval=FALSE---------------------------------------------------------------
# resResult <- PatientLevelPrediction::runPlp(
#     plpData = plpData,
#     outcomeId = 3,
#     modelSettings = resnetSettings,
#     analysisId = 'ResNet',
#     analysisName = 'Testing ResNet',
#     populationSettings = populationSettings,
#     splitSettings = PatientLevelPrediction::createDefaultSplitSetting(),
#     preprocessSettings = PatientLevelPrediction::createPreprocessSettings(),
#     executeSettings = PatientLevelPrediction::createExecuteSettings(
#       runSplitData = TRUE,
#       runSampleData = FALSE,
#       runFeatureEngineering = FALSE,
#       runPreprocessData = TRUE,
#       runModelDevelopment = TRUE,
#       runCovariateSummary = FALSE
#     ),
#     saveDirectory = file.path(tempdir(), 'ResNet')
#   )
# 

## -----------------------------------------------------------------------------

modelSettings <- setRealMLP(
  numLayers = 3L,
  sizeHidden = 256L,
  dropout = 0.15,
  device = "cpu"
)

## ----eval=FALSE---------------------------------------------------------------
# realMlpResult <- PatientLevelPrediction::runPlp(
#     plpData = plpData,
#     outcomeId = 3,
#     modelSettings = modelSettings,
#     analysisId = 'RealMLP',
#     analysisName = 'Testing RealMLP',
#     populationSettings = populationSettings,
#     splitSettings = PatientLevelPrediction::createDefaultSplitSetting(),
#     preprocessSettings = PatientLevelPrediction::createPreprocessSettings(),
#     executeSettings = PatientLevelPrediction::createExecuteSettings(
#       runSplitData = TRUE,
#       runSampleData = FALSE,
#       runFeatureEngineering = FALSE,
#       runPreprocessData = TRUE,
#       runModelDevelopment = TRUE,
#       runCovariateSummary = FALSE
#     ),
#     saveDirectory = file.path(tempdir(), 'RealMLP')
#   )

## -----------------------------------------------------------------------------

modelSettings <- setRealMLP(
  numLayers = c(2L, 3L),
  sizeHidden = c(128L, 256L),
  dropout = c(0.1, 0.2),
  numericEmbeddingMode = c("scale", "pbld"),
  hyperParamSearch = "random",
  randomSample = 4L,
  randomSampleSeed = 42L,
  device = "cpu"
)

## -----------------------------------------------------------------------------

modelSettings <- setTransformer(numBlocks = 3L,
                                dimToken = 32L,
                                dimOut = 1,
                                numHeads = 4L,
                                attDropout = 0.25,
                                ffnDropout = 0.25,
                                dimHidden = 128L,
                                estimatorSettings = setEstimator(
                                  learningRate = 3e-4,
                                  weightDecay = 1e-6,
                                  batchSize = 128L,
                                  epochs = 10L,
                                  device = 'cpu'
                                ),
                                randomSample=1L)

## ----eval=FALSE---------------------------------------------------------------
# TransformerResult <- PatientLevelPrediction::runPlp(
#     plpData = plpData,
#     outcomeId = 3,
#     modelSettings = modelSettings,
#     analysisId = 'Transformer',
#     analysisName = 'Testing transformer',
#     populationSettings = populationSettings,
#     splitSettings = PatientLevelPrediction::createDefaultSplitSetting(),
#     preprocessSettings = PatientLevelPrediction::createPreprocessSettings(),
#     executeSettings = PatientLevelPrediction::createExecuteSettings(
#       runSplitData = TRUE,
#       runSampleData = FALSE,
#       runFeatureEngineering = FALSE,
#       runPreprocessData = TRUE,
#       runModelDevelopment = TRUE,
#       runCovariateSummary = FALSE
#     ),
#     saveDirectory = file.path(tempdir(), 'Transformer')
#   )

## ----tidy=TRUE,eval=TRUE------------------------------------------------------
citation("DeepPatientLevelPrediction")

