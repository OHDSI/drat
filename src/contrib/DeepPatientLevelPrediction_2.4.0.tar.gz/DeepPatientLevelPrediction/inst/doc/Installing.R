## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)

## ----echo = TRUE, message = FALSE, warning = FALSE, tidy=FALSE, eval=FALSE----
# install.packages("DeepPatientLevelPrediction")

## ----echo = TRUE, message = FALSE, warning = FALSE, tidy=FALSE, eval=FALSE----
# install.packages("remotes")
# remotes::install_github("OHDSI/DeepPatientLevelPrediction@develop")

## ----echo = TRUE, message = FALSE, warning = FALSE,tidy=FALSE,eval=FALSE------
# library(DeepPatientLevelPrediction)
# reticulate::py_config()

## ----echo = TRUE, message = FALSE, warning = FALSE, tidy=FALSE, eval=FALSE----
# library(DeepPatientLevelPrediction)
# torch$randn(10L)

## ----echo = TRUE, message = FALSE, warning = FALSE,tidy=FALSE,eval=FALSE------
# library(DeepPatientLevelPrediction)
# 
# torch$randn(10L)

## ----echo = TRUE, message = FALSE, warning = FALSE, tidy=FALSE----------------
modelSettings <- DeepPatientLevelPrediction::setResNet(
  numLayers = 2L,
  sizeHidden = 64L,
  hiddenFactor = 1L,
  residualDropout = 0,
  hiddenDropout = 0.2,
  sizeEmbedding = 64L,
  estimatorSettings = DeepPatientLevelPrediction::setEstimator(
    learningRate = 3e-4,
    weightDecay = 1e-6,
    device = "cpu",
    batchSize = 128L,
    epochs = 3L,
    seed = 42L
  ),
  hyperParamSearch = "random",
  randomSample = 1L
)

stopifnot(inherits(modelSettings, "modelSettings"))

## ----tidy=TRUE,eval=TRUE------------------------------------------------------
citation("DeepPatientLevelPrediction")

