## ----tidy=TRUE,eval=FALSE-----------------------------------------------------
# remotes::install_github("ohdsi/Characterization")

## ----tidy=TRUE,eval=TRUE------------------------------------------------------
library(Characterization)
library(dplyr)

## ----tidy=TRUE,eval=TRUE------------------------------------------------------
connectionDetails <- Characterization::exampleOmopConnectionDetails()

## ----eval=TRUE----------------------------------------------------------------
exampleTargetIds <- c(1, 2, 4)

## ----eval=TRUE----------------------------------------------------------------
exampleCovariateSettings <- FeatureExtraction::createCovariateSettings(
  useDemographicsGender = TRUE,
  useDemographicsAge = TRUE,
  useCharlsonIndex = TRUE
)

## ----eval=TRUE----------------------------------------------------------------
exampleTargetBaselineSettings <- createTargetBaselineSettings(
  targetIds = exampleTargetIds,
  limitToFirstInNDays = 99999,
  minPriorObservation = 365,
  covariateSettings = exampleCovariateSettings
)

## ----eval=FALSE,results='hide',error=FALSE,warning=FALSE,message=FALSE--------
# runCharacterizationAnalyses(
#   connectionDetails = connectionDetails,
#   cdmDatabaseSchema = "main",
#   targetDatabaseSchema = "main",
#   targetTable = "cohort",
#   outcomeDatabaseSchema = "main",
#   outcomeTable = "cohort",
#   characterizationSettings = createCharacterizationSettings(
#     targetBaselineSettings = exampleTargetBaselineSettings
#   ),
#   databaseId = "Eunomia",
#   outputDatabaseSchema = "main",
#   outputTable = 'example_char_cohort',
#   minCharacterizationMean = 0.01,
#   outputDirectory = file.path(tempdir(), "example_char", "results"),
#   executionPath = file.path(tempdir(), "example_char", "execution"),
#   minCellCount = 10,
#   incremental = FALSE,
#   nTargetJobs = 1,
#   threads = 1
# )

## ----eval=TRUE----------------------------------------------------------------
exampleTargetIds <- c(1, 2, 4)
exampleOutcomeIds <- 3

## ----eval=TRUE----------------------------------------------------------------
exampleCovariateSettings <- FeatureExtraction::createCovariateSettings(
  useDemographicsGender = TRUE,
  useDemographicsAge = TRUE,
  useCharlsonIndex = TRUE
)

## ----eval=TRUE----------------------------------------------------------------
exampleRiskFactorSettings <- createRiskFactorSettings(
  targetIds = exampleTargetIds,
  outcomeIds = exampleOutcomeIds,
  limitToFirstInNDays = 99999, # limit to first target exposure
  riskWindowStart = 1, startAnchor = "cohort start",
  riskWindowEnd = 365, endAnchor = "cohort start",
  outcomeWashoutDays = 9999,
  minPriorObservation = 365,
  covariateSettings = exampleCovariateSettings 
)

## ----eval=FALSE,results='hide',error=FALSE,warning=FALSE,message=FALSE--------
# runCharacterizationAnalyses(
#   connectionDetails = connectionDetails,
#   cdmDatabaseSchema = "main",
#   targetDatabaseSchema = "main",
#   targetTable = "cohort",
#   outcomeDatabaseSchema = "main",
#   outcomeTable = "cohort",
#   outputDatabaseSchema = 'main',
#   outputTable = 'example_char_cohort',
#   characterizationSettings = createCharacterizationSettings(
#     riskFactorSettings = exampleRiskFactorSettings
#   ),
#   databaseId = "Eunomia",
#   minSMD = 0.1, # only keep moderate to strongly associated covariates
#   minCharacterizationMean = 0.01,
#   outputDirectory = file.path(tempdir(), "example_char", "results"),
#   executionPath = file.path(tempdir(), "example_char", "execution"),
#   minCellCount = 10,
#   incremental = FALSE,
#   nTargetJobs = 1,
#   threads = 1,
#   mode = 'CohortIncidence' # can also pick 'Efficient' and 'PatientLevelPrediction'
# )

## ----eval=TRUE----------------------------------------------------------------
exampleTargetIds <- c(1, 2, 4)
exampleOutcomeIds <- 3

## ----eval=TRUE----------------------------------------------------------------
exampleCaseCovariateSettings <- Characterization::createDuringCovariateSettings(
  useConditionOccurrenceDuring = TRUE, 
  useVisitCountDuring = TRUE
  )

## ----eval=TRUE----------------------------------------------------------------
exampleCaseSeriesSettings <- createCaseSeriesSettings(
  targetIds = exampleTargetIds,
  outcomeIds = exampleOutcomeIds,
  limitToFirstInNDays = 99999, # limit to first target index
  riskWindowStart = 1, startAnchor = "cohort start",
  riskWindowEnd = 365, endAnchor = "cohort start",
  outcomeWashoutDays = 9999,
  minPriorObservation = 365,
  caseCovariateSettings = exampleCaseCovariateSettings,
  casePreTargetDuration = 90,
  casePostOutcomeDuration = 90
)

## ----eval=FALSE,results='hide',error=FALSE,warning=FALSE,message=FALSE--------
# runCharacterizationAnalyses(
#   connectionDetails = connectionDetails,
#   cdmDatabaseSchema = "main",
#   targetDatabaseSchema = "main",
#   targetTable = "cohort",
#   outcomeDatabaseSchema = "main",
#   outcomeTable = "cohort",
# 
#   outputDatabaseSchema = "main",
#   outputTable = 'example_char_cohort',
#   characterizationSettings = createCharacterizationSettings(
#     caseSeriesSettings = exampleCaseSeriesSettings
#   ),
#   databaseId = "Eunomia",
#   minCharacterizationMean = 0.01,
#   minCovariateCount = 2,
#   outputDirectory = file.path(tempdir(), "example_char", "results"),
#   executionPath = file.path(tempdir(), "example_char", "execution"),
#   minCellCount = 10,
#   incremental = FALSE,
#   nTargetJobs = 1,
#   threads = 1
# )

## ----eval=TRUE----------------------------------------------------------------
exampleTargetIds <- c(1, 2, 4)
exampleOutcomeIds <- 3

## ----eval=TRUE----------------------------------------------------------------
exampleDechallengeRechallengeSettings <- createDechallengeRechallengeSettings(
  targetIds = exampleTargetIds,
  outcomeIds = exampleOutcomeIds,
  dechallengeStopInterval = 30,
  dechallengeEvaluationWindow = 31
)

## ----eval=FALSE---------------------------------------------------------------
# dc <- computeDechallengeRechallengeAnalyses(
#   connectionDetails = connectionDetails,
#   targetDatabaseSchema = "main",
#   targetTable = "cohort",
#   settings = exampleDechallengeRechallengeSettings,
#   databaseId = "Eunomia",
#   outcomeFolder = file.path(tempdir(), "example_char", "results"),
#   minCellCount = 5
# )

## ----eval=FALSE---------------------------------------------------------------
# failed <- computeRechallengeFailCaseSeriesAnalyses(
#   connectionDetails = connectionDetails,
#   targetDatabaseSchema = "main",
#   targetTable = "cohort",
#   settings = exampleDechallengeRechallengeSettings,
#   outcomeDatabaseSchema = "main",
#   outcomeTable = "cohort",
#   databaseId = "Eunomia",
#   outcomeFolder = file.path(tempdir(), "example_char", "results"),
#   minCellCount = 5
# )

## ----eval=TRUE----------------------------------------------------------------
exampleTimeToEventSettings <- createTimeToEventSettings(
  targetIds = exampleTargetIds,
  outcomeIds = exampleOutcomeIds
)

## ----eval=FALSE---------------------------------------------------------------
# tte <- computeTimeToEventAnalyses(
#   connectionDetails = connectionDetails,
#   cdmDatabaseSchema = "main",
#   targetDatabaseSchema = "main",
#   targetTable = "cohort",
#   settings = exampleTimeToEventSettings,
#   databaseId = "Eunomia",
#   outcomefolder = file.path(tempdir(), "example_char", "results"),
#   minCellCount = 5
# )

## ----eval=FALSE,results='hide',error=FALSE,warning=FALSE,message=FALSE--------
# characterizationSettings <- createCharacterizationSettings(
#   timeToEventSettings = list(
#     exampleTimeToEventSettings
#   ),
#   dechallengeRechallengeSettings = list(
#     exampleDechallengeRechallengeSettings
#   ),
#   aggregateCovariateSettings = exampleAggregateCovariateSettings
# )
# 
# # save the settings using
# saveCharacterizationSettings(
#   settings = characterizationSettings,
#   saveDirectory = file.path(tempdir(), "saveSettings")
# )
# 
# # the settings can be loaded
# characterizationSettings <- loadCharacterizationSettings(
#   saveDirectory = file.path(tempdir(), "saveSettings")
# )
# 
# runCharacterizationAnalyses(
#   connectionDetails = connectionDetails,
#   cdmDatabaseSchema = "main",
#   targetDatabaseSchema = "main",
#   targetTable = "cohort",
#   outcomeDatabaseSchema = "main",
#   outcomeTable = "cohort",
#   characterizationSettings = characterizationSettings,
#   outputDirectory = file.path(tempdir(), "example", "results"),
#   executionPath = file.path(tempdir(), "example", "execution"),
#   csvFilePrefix = "c_",
#   databaseId = "1",
#   incremental = F,
#   minCharacterizationMean = 0.01,
#   minCellCount = 5
# )

## ----eval=FALSE---------------------------------------------------------------
# viewCharacterization(
#   resultFolder = file.path(tempdir(), "example", "results"),
#   cohortDefinitionSet = NULL
# )

