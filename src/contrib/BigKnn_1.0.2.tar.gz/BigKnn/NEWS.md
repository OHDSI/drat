BigKnn 1.0.2
============

Changes:

1. Added support for upcoming Andromeda version (using arrow).


BigKnn 1.0.1
============

Changes:

1. Added unit tests.


BigKnn 1.0.0
============

Changes:

1. Switching from ff to Andromeda.

2. Upgrading to latest version of Lucene.

3, No longer requiring sorting of input.


BigKnn 0.0.3
============

Changes:

1. Updating to the year 2020.