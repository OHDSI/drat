library(testthat)
test_check("BigKnn")
