library(testthat)
library(DataQualityDashboard)

test_check("DataQualityDashboard")
