#' SkeletonStudy.
#'
#' @name SkeletonStudy
#' @docType package
#' @import RJDBC
#' @import SqlRender
#' @import DatabaseConnector
NULL
