#' SkeletonStudy.
#'
#' @name SkeletonStudy
#' @docType package
#' @import DBI
#' @import SqlRender
#' @import DatabaseConnector
NULL
