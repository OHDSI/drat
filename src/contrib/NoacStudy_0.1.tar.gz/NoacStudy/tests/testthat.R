library(testthat)
test_check("NoacStudy") # Change to package name
