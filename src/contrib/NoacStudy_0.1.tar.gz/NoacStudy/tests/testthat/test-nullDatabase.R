library(testthat)

# test_that("Fail to connect", {
#
#     expect_error(execute(dbms = "",
#                          user = "",
#                          password = "",
#                          server = "",
#                          cdmSchema = "",
#                          resultsScheme = ""), regexp = "Failed to connect")
# })
