library(testthat)

test_that("Generic test", {
    expect_equal(1,1)
})