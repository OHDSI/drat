## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  eval = FALSE
)

## -----------------------------------------------------------------------------
#  library(Capr)
#  
#  GIBleed <- cs(descendants(192671))
#  
#  GIBleed

## -----------------------------------------------------------------------------
#  giBleedCohort <- cohort(condition(GIBleed))
#  
#  giBleedCohort

## -----------------------------------------------------------------------------
#  
#  
#  connectionDetails <- Eunomia::getEunomiaConnectionDetails()
#  
#  
#  sql <- CirceR::buildCohortQuery(CirceR::cohortExpressionFromJson(as.json(giBleedCohort)),
#                                  CirceR::createGenerateOptions(
#                                    generateStats = FALSE
#                                  ))
#  
#  cohortsToCreate <- tibble::tibble(
#    cohortId = 1,
#    cohortName = "GI Bleed",
#    sql = sql
#  )
#  
#  
#  cohortTableNames <- CohortGenerator::getCohortTableNames(cohortTable = "my_cohort_table")
#  CohortGenerator::createCohortTables(connectionDetails = connectionDetails,
#                                                          cohortDatabaseSchema = "main",
#                                                          cohortTableNames = cohortTableNames)
#  # Generate the cohorts
#  cohortsGenerated <- CohortGenerator::generateCohortSet(connectionDetails = connectionDetails,
#                                                         cdmDatabaseSchema = "main",
#                                                         cohortDatabaseSchema = "main",
#                                                         cohortTableNames = cohortTableNames,
#                                                         cohortDefinitionSet = cohortsToCreate)
#  
#  # Get the cohort counts
#  cohortCounts <- CohortGenerator::getCohortCounts(connectionDetails = connectionDetails,
#                                                   cohortDatabaseSchema = "main",
#                                                   cohortTable = cohortTableNames$cohortTable)
#  print(cohortCounts)
#  sql <- SqlRender::render(sql)
#  sql <- SqlRender::translate(sql, "sqlite")
#  
#  con <- DatabaseConnector::connect(connectionDetails)
#  
#  DatabaseConnector::executeSql(con, sql)
#  
#  
#  
#  

