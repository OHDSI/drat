FeatureExtraction 2.2.1
=======================

Changes:

1. Added option to specify number of digits for continuous variables in createTable1 function.

Bugfixes:

1. Added missing space cause SQL error when both include and exclude concept are specified.


FeatureExtraction 2.2.0
=======================

Changes:

1. Added the Hospital Frailty Risk Score.