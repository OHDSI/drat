library(testthat)
options(dbms = "oracle")
test_check("CohortExplorer")
