DROP TABLE @schemaName.incidence_summary;
DROP TABLE @schemaName.target_def;
DROP TABLE @schemaName.outcome_def;
DROP TABLE @schemaName.tar_def;
DROP TABLE @schemaName.age_group_def;
DROP TABLE @schemaName.subgroup_def;
