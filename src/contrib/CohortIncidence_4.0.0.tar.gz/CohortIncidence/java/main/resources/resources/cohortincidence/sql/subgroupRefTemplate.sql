select cast(%d as int) as subgroup_id, 
	cast ('%s' as varchar(250)) as subgroup_name