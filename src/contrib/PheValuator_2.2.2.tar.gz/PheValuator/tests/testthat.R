library("testthat")
library("PheValuator")
library(Eunomia)

test_check("PheValuator")
