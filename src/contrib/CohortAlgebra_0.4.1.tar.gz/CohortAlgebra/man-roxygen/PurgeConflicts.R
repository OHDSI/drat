#'
#' @param purgeConflicts      If there are conflicts in the target cohort table i.e. the target cohort table
#'                            already has records with newCohortId, do you want to purge and replace them 
#'                            with transformed. By default - it will not be replaced, and an error message is thrown.
