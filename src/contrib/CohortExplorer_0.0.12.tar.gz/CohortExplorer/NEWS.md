CohortExplorer 0.0.12
======================

Minor bug fixes

CohortExplorer 0.0.11
======================

Minor bug fixes

CohortExplorer 0.0.10
======================

Minor bug fixes

CohortExplorer 0.0.9
======================

Skipped

CohortExplorer 0.0.8
======================

Skipped

CohortExplorer 0.0.7
======================

Ability to use the observation period as the cohort table

CohortExplorer 0.0.6
======================

Remove rouge browser()

CohortExplorer 0.0.5
======================

Add vignette.
Minor optimization to how shiny app is created.

CohortExplorer 0.0.4
======================

Bug fix to shiny.

CohortExplorer 0.0.3
======================

Resolving minor issues in github checks. 
Indentation.

CohortExplorer 0.0.2
======================

Make HADES conformant. 

CohortExplorer 0.0.1
======================

This is a unreleased package. 
