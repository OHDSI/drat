library(testthat)
library(CohortIncidence)

test_check("CohortIncidence")
