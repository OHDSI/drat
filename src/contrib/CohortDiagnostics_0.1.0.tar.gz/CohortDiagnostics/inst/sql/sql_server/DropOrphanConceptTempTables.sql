DROP TABLE #starting_concepts;
DROP TABLE #concept_synonyms;
DROP TABLE #search_strings;
DROP TABLE #search_str_top1000;
DROP TABLE #search_string_subset;
DROP TABLE #recommended_concepts;
