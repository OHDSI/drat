HADES 1.14.0
============

- Adding Keeper to HADES


HADES 1.13.1
============

- CirceR, Eunomia, and FeatureExtraction are now in CRAN. Removing reference to Github repos.

HADES 1.13.0
============

- Adding Achilles to HADES

HADES 1.12.0
============

- Adding BrokenAdaptiveRidge to HADES

HADES 1.11.0
============

Changes

- Adding DataQualityDashboard to HADES

HADES 1.10.0
============

Changes

- Adding ShinyAppBuilder to HADES

HADES 1.9.0
===========

Changes

- Adding Characterization to HADES

HADES 1.8.0
===========

Changes

- Adding ResultModelManager to HADES

HADES 1.7.0
===========

Changes

- Adding OhdsiShinyModules to HADES

HADES 1.6.0
===========

Changes

- Adding PheValuator to HADES

HADES 1.5.0
===========

Changes

- Adding CohortExplorer to HADES

HADES 1.4.0
===========

Changes

- Adding PhenotypeLibrary to HADES

HADES 1.3.0
===========

Changes

- Adding EnsemblePatientLevelPrediction to HADES

HADES 1.2.0
===========

Changes

- Adding Capr to HADES

HADES 1.1.0
===========

Changes

- Adding CohortGenerator to HADES

HADES 1.0.1
===========

Changes

- Moving Eunomia from CRAN to GitHub


Hades 1.0.0
===========

Initial release