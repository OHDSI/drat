#' @param cdmVersion   The version of the OMOP CDM. Default 5. (Note: only 5 is supported.)
