## ---- echo = TRUE, message = FALSE, warning = FALSE,tidy=FALSE,eval=FALSE-----
#  install.packages("remotes")
#  remotes::install_github("OHDSI/Characterization")

## ----tidy=FALSE,eval=TRUE-----------------------------------------------------
citation("Characterization")

