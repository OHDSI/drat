CohortMethod 1.4.1
==================

Bugfixes:

1. Several workaround for issues with the ff package.

2. Fixed bug causing age to be read incorrectly when creating eras.

