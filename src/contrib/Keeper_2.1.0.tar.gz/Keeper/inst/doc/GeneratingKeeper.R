## ----echo = FALSE, message = FALSE, warning = FALSE---------------------------
library(Keeper)

## ----eval = FALSE-------------------------------------------------------------
# library(ellmer)
# client <- chat_openai()

## ----eval = FALSE-------------------------------------------------------------
# library(DatabaseConnector)
# connectionDetails <- createConnectionDetails(
#   dbms = "postgresql",
#   server = "localhost/ohdsi",
#   user = "joe",
#   password = "supersecret"
# )
# vocabularyDatabaseSchema <- "cdm"

## ----eval = FALSE-------------------------------------------------------------
# conceptSets <- generateKeeperConceptSets(
#   phenotype = "Type I Diabetes Mellitus (T1DM)",
#   client = client,
#   vocabConnectionDetails = connectionDetails,
#   vocabDatabaseSchema = vocabDatabaseSchema
# )
# conceptSets

## ----eval=TRUE, echo=FALSE, message=FALSE-------------------------------------
conceptSets <- read.csv(system.file("t1dmConceptSets.csv", package = "Keeper"))
conceptSets <- dplyr::as_tibble(conceptSets)
conceptSets

## ----eval = FALSE-------------------------------------------------------------
# library(Capr)
# 
# t1dmConceptIds <- c(201254, 435216)
# t1dmCs <- cs(
#   descendants(t1dmConceptIds),
#   name = "Type 1 Diabetes Mellitus"
# )
# 
# t1dmCohort <- cohort(
#   entry = entry(
#     conditionOccurrence(t1dmCs, firstOccurrence())
#   ),
#   exit = exit(
#     endStrategy = observationExit()
#   )
# )
# # Note: this will automatically assign cohort ID 1:
# cohortSet <- makeCohortSet(t1dmCohort)

## ----eval = FALSE-------------------------------------------------------------
# connectionDetails <- createConnectionDetails(
#   dbms = "postgresql",
#   server = "localhost/ohdsi",
#   user = "joe",
#   password = "supersecret"
# )
# cdmDatabaseSchema <- "cdm"
# cohortDatabaseSchema <- "cdm"
# cohortTable <- "cohort"
# options(sqlRenderTempEmulationSchema = NULL)

## ----eval = FALSE-------------------------------------------------------------
# library(CohortGenerator)
# connection <- connect(connectionDetails)
# createCohortTables(
#   connection = connection,
#   cohortTableNames = getCohortTableNames(cohortTable),
#   cohortDatabaseSchema = cohortDatabaseSchema
# )
# CohortGenerator::generateCohortSet(
#   connection = connection,
#   cdmDatabaseSchema = cdmDatabaseSchema,
#   cohortDatabaseSchema = cohortDatabaseSchema,
#   cohortTableNames = getCohortTableNames(cohortTable),
#   cohortDefinitionSet = cohortSet
# )
# disconnect(connection)

## ----eval = FALSE-------------------------------------------------------------
# keeper <- generateKeeper(
#   connection = connection,
#   cohortDatabaseSchema = cohortDatabaseSchema,
#   cdmDatabaseSchema = cdmDatabaseSchema,
#   cohortTable = cohortTable,
#   cohortDefinitionId = 1,
#   sampleSize = 20,
#   keeperConceptSets = conceptSets,
#   phenotypeName = "Type I Diabetes Mellitus (T1DM)",
#   removePii = TRUE
# )

## ----echo=FALSE,message=FALSE,eval=TRUE---------------------------------------
keeper <- readRDS(system.file("shuffledKeeper.rds", package = "Keeper"))

## -----------------------------------------------------------------------------
keeperTable <- convertKeeperToTable(keeper)
keeperTable

## ----eval = FALSE-------------------------------------------------------------
# readr::write_csv(keeperTable, "e:/temp/KeeperT1dm.csv")

## ----eval = FALSE-------------------------------------------------------------
# launchReviewerApp(
#   keeper = keeper,
#   keeperConceptSets = conceptSets,
#   decisionsFileName = "decisions.csv"
# )

