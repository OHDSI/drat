## ----echo = FALSE, message = FALSE, warning = FALSE---------------------------
library(Keeper)

## ----echo=FALSE,message=FALSE,eval=TRUE---------------------------------------
keeper <- readRDS(system.file("shuffledKeeper.rds", package = "Keeper"))

## -----------------------------------------------------------------------------
keeper

## ----eval = FALSE-------------------------------------------------------------
# library(ellmer)
# client <- chat_openai()

## ----eval = FALSE-------------------------------------------------------------
# promptSettings <- createPromptSettings()
# llmReviews <- reviewCases(
#   keeper = keeper,
#   settings = promptSettings,
#   phenotypeName = "Type I Diabetes Mellitus (T1DM)",
#   client = client,
#   cacheFolder = "cache"
# )

## ----echo=FALSE,eval=TRUE-----------------------------------------------------
message("Reviewing person 1 of 20\n...\nReviewing person 20 of 20\nReviewing cases took 3.9 mins and cost $0.50")

## ----echo=FALSE,message=FALSE,eval=TRUE---------------------------------------
llmReviews <- readRDS(system.file("llmReviews.rds", package = "Keeper"))

## -----------------------------------------------------------------------------
# Revmove non-ASCII:
llmReviews$justification <- gsub("[^\u0001-\u007F]+|<U\\+\\w+>","", llmReviews$justification)
llmReviews

## -----------------------------------------------------------------------------
mean(llmReviews$isCase == "yes")

## ----eval = FALSE-------------------------------------------------------------
# createSensitiveCohort(
#   connectionDetails = connectionDetails,
#   cdmDatabaseSchema = cdmDatabaseSchema,
#   cohortDatabaseSchema = cohortDatabaseSchema,
#   cohortTable = cohortTable,
#   cohortDefinitionId = 2,
#   createCohortTable = FALSE,
#   keeperConceptSets = conceptSets
# )

## ----eval = FALSE-------------------------------------------------------------
# keeperHsc <- generateKeeper(
#   connectionDetails = connectionDetails,
#   cohortDatabaseSchema = cohortDatabaseSchema,
#   cdmDatabaseSchema = cdmDatabaseSchema,
#   cohortTable = cohortTable,
#   cohortDefinitionId = 2,
#   sampleSize = 10000,
#   phenotypeName = "Type I Diabetes Mellitus (T1DM)",
#   keeperConceptSets = conceptSets,
#   removePii = FALSE
# )

## ----eval = FALSE-------------------------------------------------------------
# promptSettings <- createPromptSettings()
# llmReviewsHsc <- reviewCases(
#   keeper = keeperHsc,
#   settings = promptSettings,
#   client = client,
#   cacheFolder = "cacheVignetteHsc"
# )

## ----eval = FALSE-------------------------------------------------------------
# referenceCohortDatabaseSchema <- "cdm"
# referenceCohortTable <- "reference_cohort"
# 
# uploadReferenceCohort(
#   connectionDetails = connectionDetails,
#   referenceCohortDatabaseSchema = referenceCohortDatabaseSchema,
#   referenceCohortTableNames = createReferenceCohortTableNames(referenceCohortTable),
#   referenceCohortDefinitionId = 1,
#   createReferenceCohortTables = TRUE,
#   reviews = llmReviewsHsc
# )

## ----eval = FALSE-------------------------------------------------------------
# metrics <- computeCohortOperatingCharacteristics(
#   connectionDetails = connectionDetails,
#   cohortDatabaseSchema = cohortDatabaseSchema,
#   cohortTable = cohortTable,
#   cohortDefinitionId = 1,
#   referenceCohortDatabaseSchema = referenceCohortDatabaseSchema,
#   referenceCohortTableNames = createReferenceCohortTableNames(referenceCohortTable),
#   referenceCohortDefinitionId = 1
# )

## ----echo=FALSE,message=FALSE,eval=TRUE---------------------------------------
metrics <- readRDS(system.file("metrics.rds", package = "Keeper"))

## -----------------------------------------------------------------------------
metrics

