Eunomia 1.0.3
=============

Changes

- Supporting DatabaseConnector > 6.0.0

Eunomia 1.0.2
=============

Changes

- switch to readr::write_csv for proper concept_id handling
- added gender concepts to concept table

Eunomia 1.0.1
=============

Changes

- Using xz compression to further reduce package size.


Eunomia 1.0.0
=============

Initial release
