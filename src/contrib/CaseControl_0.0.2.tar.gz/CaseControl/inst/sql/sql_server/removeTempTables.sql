TRUNCATE TABLE #nesting_cohort;
DROP TABLE #nesting_cohort;

TRUNCATE TABLE #cases;
DROP TABLE #cases;

