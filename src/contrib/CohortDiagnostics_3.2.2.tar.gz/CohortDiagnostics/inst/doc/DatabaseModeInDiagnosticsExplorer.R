## ---- echo = FALSE, message = FALSE-------------------------------------------
library(SqlRender)
knitr::opts_chunk$set(
  cache = FALSE,
  comment = "#>",
  error = FALSE,
  tidy = FALSE
)

## ----eval = FALSE-------------------------------------------------------------
#  launchDiagnosticsExplorer(
#    shinyConfigPath = "path/to/config.yml",
#    makePublishable = TRUE,
#    publishDir = file.path(getwd(), "MyStudyDiagnosticsExplorer"),
#    overwritePublishDir = TRUE
#  )

