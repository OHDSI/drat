DROP TABLE IF EXISTS @table_name;
CREATE TABLE @table_name (concept_id INT);
