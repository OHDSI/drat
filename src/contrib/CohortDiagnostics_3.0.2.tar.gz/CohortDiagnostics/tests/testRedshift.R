library(testthat)
options(dbms = "redshift")
test_check("CohortDiagnostics")
