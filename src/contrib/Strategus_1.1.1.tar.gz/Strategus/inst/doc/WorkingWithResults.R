## ----setup, include=FALSE, echo=FALSE, warning=FALSE--------------------------------------------------------------------------------------------------------------------------------------------------
library(Strategus)
options(width = 200)

## ----eval=F-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# resultsConnectionDetails <- DatabaseConnector::createConnectionDetails(
#   dbms = "postgresql",
#   user = "user",
#   password = "password",
#   server = "127.0.0.1/strategus_results"
# )
# 
# resultsDataModelSettings <- Strategus::createResultsDataModelSettings(
#   resultsDatabaseSchema = "study_results",
#   resultsFolder = "path/to/results",
# )
# 
# Strategus::createResultDataModel(
#   analysisSpecifications = analysisSpecifications,
#   resultsDataModelSettings = resultsDataModelSettings,
#   resultsConnectionDetails = resultsConnectionDetails
# )

## ----eval=F-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# Strategus::uploadResults(
#   analysisSpecifications = analysisSpecifications,
#   resultsDataModelSettings = resultsDataModelSettings,
#   resultsConnectionDetails = resultsConnectionDetails
# )

## ----eval=F-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# library(ShinyAppBuilder)
# library(OhdsiShinyModules)
# 
# # ADD OR REMOVE MODULES TAILORED TO YOUR STUDY
# shinyConfig <- initializeModuleConfig() |>
#   addModuleConfig(
#     createDefaultAboutConfig()
#   ) |>
#   addModuleConfig(
#     createDefaultDatasourcesConfig()
#   ) |>
#   addModuleConfig(
#     createDefaultCohortGeneratorConfig()
#   ) |>
#   addModuleConfig(
#     createDefaultCohortDiagnosticsConfig()
#   ) |>
#   addModuleConfig(
#     createDefaultCharacterizationConfig()
#   ) |>
#   addModuleConfig(
#     createDefaultPredictionConfig()
#   ) |>
#   addModuleConfig(
#     createDefaultEstimationConfig()
#   )
# 
# # now create the shiny app based on the config file and view the results
# # based on the connection
# ShinyAppBuilder::createShinyApp(
#   config = shinyConfig,
#   connectionDetails = resultsConnectionDetails,
#   resultDatabaseSettings = createDefaultResultDatabaseSettings(schema = "study_results"),
#   title = "Celecoxib vs. Diclofinac for the risk of GI Bleed",
#   studyDescription = "This study is showcasing the capabilities of running Strategus on Eunomia."
# )

