TRUNCATE TABLE #cohort_person;

DROP TABLE #cohort_person;

{@sampled} ? {
TRUNCATE TABLE #cohort_sample;

DROP TABLE #cohort_sample;
}
