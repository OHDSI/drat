# @file RunAnalyses.R
#
# Copyright 2016 Observational Health Data Sciences and Informatics
#
# This file is part of CohortMethod
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

#' Run a list of analyses
#'
#' @details
#' Run a list of analyses for the drug-comparator-outcomes of interest. This function will run all
#' specified analyses against all hypotheses of interest, meaning that the total number of outcome
#' models is `length(cmAnalysisList) * length(drugComparatorOutcomesList)` (if all analyses specify an
#' outcome model should be fitted). When you provide several analyses it will determine whether any of
#' the analyses have anything in common, and will take advantage of this fact. For example, if we
#' specify several analyses that only differ in the way the outcome model is fitted, then this
#' function will extract the data and fit the propensity model only once, and re-use this in all the
#' analysis.
#'
#' @param connectionDetails                     An R object of type \code{connectionDetails} created
#'                                              using the function \code{createConnectionDetails} in
#'                                              the \code{DatabaseConnector} package.
#' @param cdmDatabaseSchema                     The name of the database schema that contains the OMOP
#'                                              CDM instance. Requires read permissions to this
#'                                              database. On SQL Server, this should specifiy both the
#'                                              database and the schema, so for example
#'                                              'cdm_instance.dbo'.
#' @param cdmVersion                            Define the OMOP CDM version used: currently support "4" and "5".
#' @param oracleTempSchema                      For Oracle only: the name of the database schema where
#'                                              you want all temporary tables to be managed. Requires
#'                                              create/insert permissions to this database.
#' @param exposureDatabaseSchema                The name of the database schema that is the location
#'                                              where the exposure data used to define the exposure
#'                                              cohorts is available. If exposureTable = DRUG_ERA,
#'                                              exposureDatabaseSchema is not used by assumed to be
#'                                              cdmSchema.  Requires read permissions to this database.
#' @param exposureTable                         The tablename that contains the exposure cohorts.  If
#'                                              exposureTable <> DRUG_ERA, then expectation is
#'                                              exposureTable has format of COHORT table:
#'                                              COHORT_DEFINITION_ID, SUBJECT_ID, COHORT_START_DATE,
#'                                              COHORT_END_DATE.
#' @param outcomeDatabaseSchema                 The name of the database schema that is the location
#'                                              where the data used to define the outcome cohorts is
#'                                              available. If exposureTable = CONDITION_ERA,
#'                                              exposureDatabaseSchema is not used by assumed to be
#'                                              cdmSchema.  Requires read permissions to this database.
#' @param outcomeTable                          The tablename that contains the outcome cohorts.  If
#'                                              outcomeTable <> CONDITION_OCCURRENCE, then expectation
#'                                              is outcomeTable has format of COHORT table:
#'                                              COHORT_DEFINITION_ID, SUBJECT_ID, COHORT_START_DATE,
#'                                              COHORT_END_DATE.
#' @param outputFolder                          Name of the folder where all the outputs will written
#'                                              to.
#' @param cmAnalysisList                        A list of objects of type \code{cmAnalysis} as created
#'                                              using the \code{\link{createCmAnalysis}} function.
#' @param drugComparatorOutcomesList            A list of objects of type \code{drugComparatorOutcomes}
#'                                              as created using the
#'                                              \code{\link{createDrugComparatorOutcomes}} function.
#' @param refitPsForEveryOutcome                Should the propensity model be fitted for every outcome
#'                                              (i.e. after people who already had the outcome are
#'                                              removed)? If false, a single propensity model will be
#'                                              fitted, and people who had the outcome previously will
#'                                              be removed afterwards.
#' @param underSampleComparatorToTreatedRatio   If the comparator group size exceeds the treated group
#'                                              size by this factor, the comparator group will be
#'                                              down-sampled before fitting the PS model. This can be
#'                                              useful when the comparator group is extremely large.
#' @param getDbCohortMethodDataThreads          The number of parallel threads to use for building the
#'                                              cohortMethod data objects.
#' @param createPsThreads                       The number of parallel threads to use for fitting the
#'                                              propensity models.
#' @param psCvThreads                           The number of parallel threads to use for the cross-
#'                                              validation when estimating the hyperparameter for the
#'                                              propensity model. Note that the total number of CV
#'                                              threads at one time could be `createPsThreads *
#'                                              psCvThreads`.
#' @param computeCovarBalThreads                The number of parallel threads to use for computing the
#'                                              covariate balance.
#' @param trimMatchStratifyThreads              The number of parallel threads to use for trimming,
#'                                              matching and stratifying.
#' @param fitOutcomeModelThreads                The number of parallel threads to use for fitting the
#'                                              outcome models.
#' @param outcomeCvThreads                      The number of parallel threads to use for the cross-
#'                                              validation when estimating the hyperparameter for the
#'                                              outcome model. Note that the total number of CV threads
#'                                              at one time could be `fitOutcomeModelThreads *
#'                                              outcomeCvThreads`.
#'
#' @return
#' A data frame with the following columns:
#' \tabular{ll}{
#' \verb{analysisId} \tab The unique identifier for a set of analysis choices.\cr
#' \verb{targetId} \tab The ID of the target drug.\cr
#' \verb{comparatorId} \tab The ID of the comparator group.\cr
#' \verb{indicationConceptIds} \tab The ID(s) of indications in which to nest to study. \cr
#' \verb{exclusionConceptIds} \tab The ID(s) of concepts used to exclude subjects. \cr
#' \verb{excludedCovariateConceptIds} \tab The ID(s) of concepts that cannot be used to construct covariates. \cr
#' \verb{includedCovariateConceptIds} \tab The ID(s) of concepts that should be used to construct covariates. \cr
#' \verb{cohortMethodDataFolder} \tab The ID of the outcome.\cr
#' \verb{sharedPsFile}                \tab The name of the file containing the propensity scores of the shared \cr
#'                                    \tab propensity model. This model is used to create the outcome-specific \cr
#'                                    \tab propensity scores by removing people with prior outcomes.\cr
#' \verb{psFile}                      \tab The name of file containing the propensity scores for a specific \cr
#'                                    \tab outcomes (ie after people with prior outcomes have been removed).\cr
#' \verb{subPopFile}                  \tab The name of the file containing the identifiers of the population \cr
#'                                    \tab after any trimming, matching or stratifying, including their strata.\cr
#' \verb{covariateBalanceFile}        \tab The name of the file containing the covariate balance (ie. the \cr
#'                                    \tab output of the \code{computeCovariateBalance} function.\cr
#' \verb{outcomeModelFile} \tab The name of the file containing the outcome model.\cr
#' }
#'
#' @export
runCmAnalyses <- function(connectionDetails,
                          cdmDatabaseSchema,
                          oracleTempSchema = cdmDatabaseSchema,
                          exposureDatabaseSchema = cdmDatabaseSchema,
                          exposureTable = "drug_era",
                          outcomeDatabaseSchema = cdmDatabaseSchema,
                          outcomeTable = "condition_occurrence",
                          cdmVersion = 4,
                          outputFolder = "./CohortMethodOutput",
                          cmAnalysisList,
                          drugComparatorOutcomesList,
                          refitPsForEveryOutcome = FALSE,
                          underSampleComparatorToTreatedRatio = 0,
                          getDbCohortMethodDataThreads = 1,
                          createPsThreads = 1,
                          psCvThreads = 1,
                          trimMatchStratifyThreads = 1,
                          computeCovarBalThreads = 1,
                          fitOutcomeModelThreads = 1,
                          outcomeCvThreads = 1) {
  for (drugComparatorOutcomes in drugComparatorOutcomesList) {
    stopifnot(class(drugComparatorOutcomes) == "drugComparatorOutcomes")
  }
  for (cmAnalysis in cmAnalysisList) {
    stopifnot(class(cmAnalysis) == "cmAnalysis")
  }
  uniquedrugComparatorOutcomesList <- unique(OhdsiRTools::selectFromList(drugComparatorOutcomesList,
                                                                         c("targetId",
                                                                           "comparatorId",
                                                                           "outcomeIds",
                                                                           "indicationConceptIds")))
  if (length(uniquedrugComparatorOutcomesList) != length(drugComparatorOutcomesList)) {
    stop("Duplicate drug-comparator-indication-outcomes combinations are not allowed")
  }
  uniqueAnalysisIds <- unlist(unique(OhdsiRTools::selectFromList(cmAnalysisList, "analysisId")))
  if (length(uniqueAnalysisIds) != length(cmAnalysisList)) {
    stop("Duplicate analysis IDs are not allowed")
  }
  if (!file.exists(outputFolder))
    dir.create(outputFolder)

  ### Create reference table ###
  allButFitOutcomeModelArgsList <- unique(OhdsiRTools::excludeFromList(cmAnalysisList,
                                                                       c("analysisId",
                                                                         "description",
                                                                         "fitOutcomeModel",
                                                                         "fitOutcomeModelArgs")))
  outcomeReference <- data.frame()
  loadingArgsList <- unique(OhdsiRTools::selectFromList(cmAnalysisList,
                                                        c("getDbCohortMethodDataArgs",
                                                          "targetType",
                                                          "comparatorType",
                                                          "indicationType")))
  for (i in 1:length(loadingArgsList)) {
    loadingArgs <- loadingArgsList[[i]]
    drugComparatorList <- unique(OhdsiRTools::selectFromList(drugComparatorOutcomesList,
                                                             c("targetId",
                                                               "comparatorId",
                                                               "indicationConceptIds",
                                                               "exclusionConceptIds",
                                                               "excludedCovariateConceptIds",
                                                               "includedCovariateConceptIds")))
    for (drugComparator in drugComparatorList) {
      drugComparatorOutcomes <- OhdsiRTools::matchInList(drugComparatorOutcomesList, drugComparator)
      outcomeIds <- unique(unlist(OhdsiRTools::selectFromList(drugComparatorOutcomes,
                                                              "outcomeIds")))
      targetId <- .selectByType(loadingArgs$targetType, drugComparator$targetId, "target")
      comparatorId <- .selectByType(loadingArgs$comparatorType,
                                    drugComparator$comparatorId,
                                    "comparator")
      indicationConceptIds <- .selectByType(loadingArgs$indicationType,
                                            drugComparator$indicationConceptIds,
                                            "indication")
      cohortMethodDataFolder <- .createCohortMethodDataFileName(outputFolder,
                                                                i,
                                                                targetId,
                                                                comparatorId,
                                                                indicationConceptIds)
      cmAnalysisSubset <- OhdsiRTools::matchInList(cmAnalysisList, loadingArgs)
      createPsArgsList <- unique(OhdsiRTools::selectFromList(cmAnalysisSubset,
                                                             c("createPs", "createPsArgs")))
      for (j in 1:length(createPsArgsList)) {
        createPsArgs <- createPsArgsList[[j]]
        if (createPsArgs$createPs) {
          sharedPsFile <- .createPsFileName(outputFolder,
                                            i,
                                            targetId,
                                            comparatorId,
                                            indicationConceptIds,
                                            j)
        } else {
          sharedPsFile <- ""
        }
        allButFitOutcomeModelArgsSubset <- OhdsiRTools::matchInList(OhdsiRTools::matchInList(allButFitOutcomeModelArgsList,
                                                                                             loadingArgs), createPsArgs)
        for (k in 1:length(allButFitOutcomeModelArgsSubset)) {
          allButFitOutcomeModelArgs <- allButFitOutcomeModelArgsSubset[[k]]
          cmAnalysisSubset <- OhdsiRTools::matchInList(cmAnalysisList, allButFitOutcomeModelArgs)
          for (cmAnalysisArgs in cmAnalysisSubset) {
            analysisFolder <- file.path(outputFolder,
                                        paste("Analysis_", cmAnalysisArgs$analysisId, sep = ""))
            if (!file.exists(analysisFolder))
              dir.create(analysisFolder)
            for (outcomeId in outcomeIds) {
              if (cmAnalysisArgs$createPs) {
                psFileName <- .createPsOutcomeFileName(outputFolder,
                                                       i,
                                                       drugComparator$targetId,
                                                       drugComparator$comparatorId,
                                                       drugComparator$indicationConceptIds,
                                                       j,
                                                       outcomeId)
              } else {
                psFileName <- ""
              }
              if (cmAnalysisArgs$trimByPs || cmAnalysisArgs$trimByPsToEquipoise || cmAnalysisArgs$matchOnPs ||
                  cmAnalysisArgs$matchOnPsAndCovariates || cmAnalysisArgs$stratifyByPs || cmAnalysisArgs$stratifyByPsAndCovariates) {
                subPopFileName <- .createSubPopFileName(outputFolder,
                                                        i,
                                                        drugComparator$targetId,
                                                        drugComparator$comparatorId,
                                                        drugComparator$indicationConceptIds,
                                                        j,
                                                        k,
                                                        outcomeId)
                if (cmAnalysisArgs$computeCovariateBalance) {
                  covarBalFileName <- .createCovariateBalanceFileName(outputFolder,
                                                                      i,
                                                                      drugComparator$targetId,
                                                                      drugComparator$comparatorId,
                                                                      drugComparator$indicationConceptIds,
                                                                      j,
                                                                      k,
                                                                      outcomeId)
                } else {
                  covarBalFileName <- ""
                }
              } else {
                subPopFileName <- ""
                covarBalFileName <- ""
              }
              if (cmAnalysisArgs$fitOutcomeModel) {
                outcomeModelFileName <- .createOutcomeModelFileName(analysisFolder,
                                                                    drugComparator$targetId,
                                                                    drugComparator$comparatorId,
                                                                    drugComparator$indicationConceptIds,
                                                                    outcomeId)
              } else {
                outcomeModelFileName <- ""
              }
              outcomeReferenceRow <- data.frame(analysisId = cmAnalysisArgs$analysisId,
                                                targetId = drugComparator$targetId,
                                                comparatorId = drugComparator$comparatorId,
                                                indicationConceptIds = paste(drugComparator$indicationConceptIds,
                                                                             collapse = ","),
                                                exclusionConceptIds = paste(drugComparator$exclusionConceptIds,
                                                                            collapse = ","),
                                                excludedCovariateConceptIds = paste(drugComparator$excludedCovariateConceptIds,
                                                                                    collapse = ","),
                                                includedCovariateConceptIds = paste(drugComparator$includedCovariateConceptIds,
                                                                                    collapse = ","),
                                                outcomeId = outcomeId,
                                                cohortMethodDataFolder = cohortMethodDataFolder,
                                                sharedPsFile = sharedPsFile,
                                                psFile = psFileName,
                                                subPopFile = subPopFileName,
                                                covariateBalanceFile = covarBalFileName,
                                                outcomeModelFile = outcomeModelFileName,
                                                stringsAsFactors = FALSE)
              outcomeReference <- rbind(outcomeReference, outcomeReferenceRow)
            }
          }
        }
      }
    }
  }
  saveRDS(outcomeReference, file.path(outputFolder, "outcomeModelReference.rds"))

  writeLines("*** Creating cohortMethodData objects ***")
  objectsToCreate <- list()
  for (cohortMethodDataFolder in unique(outcomeReference$cohortMethodDataFolder)) {
    if (cohortMethodDataFolder != "" && !file.exists((cohortMethodDataFolder))) {
      refRow <- outcomeReference[outcomeReference$cohortMethodDataFolder == cohortMethodDataFolder, ][1, ]
      analysisRow <- OhdsiRTools::matchInList(cmAnalysisList,
                                              list(analysisId = refRow$analysisId))[[1]]
      getDbCohortMethodDataArgs <- analysisRow$getDbCohortMethodDataArgs
      indicationConceptIds <- as.numeric(unlist(strsplit(refRow$indicationConceptIds, ",")))
      exclusionConceptIds <- unique(c(as.numeric(unlist(strsplit(refRow$exclusionConceptIds, ","))),
                                      getDbCohortMethodDataArgs$exclusionConceptIds))
      excludedCovariateConceptIds <- unique(c(as.numeric(unlist(strsplit(refRow$excludedCovariateConceptIds,
                                                                         ","))),
                                              getDbCohortMethodDataArgs$covariateSettings$excludedCovariateConceptIds))
      includedCovariateConceptIds <- unique(c(as.numeric(unlist(strsplit(refRow$includedCovariateConceptIds,
                                                                         ","))),
                                              getDbCohortMethodDataArgs$covariateSettings$includedCovariateConceptIds))
      outcomeIds <- unique(outcomeReference$outcomeId[outcomeReference$cohortMethodDataFolder ==
                                                        cohortMethodDataFolder])
      args <- list(connectionDetails = connectionDetails,
                   cdmDatabaseSchema = cdmDatabaseSchema,
                   exposureDatabaseSchema = exposureDatabaseSchema,
                   exposureTable = exposureTable,
                   outcomeDatabaseSchema = outcomeDatabaseSchema,
                   outcomeTable = outcomeTable,
                   cdmVersion = cdmVersion,
                   outcomeIds = outcomeIds,
                   targetId = refRow$targetId,
                   comparatorId = refRow$comparatorId,
                   indicationConceptIds = indicationConceptIds,
                   exclusionConceptIds = exclusionConceptIds)
      getDbCohortMethodDataArgs$exclusionConceptIds <- NULL
      getDbCohortMethodDataArgs$covariateSettings$excludedCovariateConceptIds <- excludedCovariateConceptIds
      getDbCohortMethodDataArgs$covariateSettings$includedCovariateConceptIds <- includedCovariateConceptIds
      args <- append(args, getDbCohortMethodDataArgs)
      objectsToCreate[[length(objectsToCreate) + 1]] <- list(args = args,
                                                             cohortMethodDataFolder = cohortMethodDataFolder)
    }
  }
  createCmDataObject <- function(params) {
    cohortMethodData <- do.call("getDbCohortMethodData", params$args)
    saveCohortMethodData(cohortMethodData, params$cohortMethodDataFolder)
  }
  if (length(objectsToCreate) != 0) {
    cluster <- OhdsiRTools::makeCluster(getDbCohortMethodDataThreads)
    OhdsiRTools::clusterRequire(cluster, "CohortMethod")
    dummy <- OhdsiRTools::clusterApply(cluster, objectsToCreate, createCmDataObject)
    OhdsiRTools::stopCluster(cluster)
  }

  writeLines("*** Fitting propensity score models ***")
  modelsToFit <- list()
  if (refitPsForEveryOutcome) {
    # Refit PS model for every outcome
    for (psFile in unique(outcomeReference$psFile)) {
      if (psFile != "" && !file.exists((psFile))) {
        refRow <- outcomeReference[outcomeReference$psFile == psFile, ][1, ]
        analysisRow <- OhdsiRTools::matchInList(cmAnalysisList,
                                                list(analysisId = refRow$analysisId))[[1]]
        outcomeId <- unique(outcomeReference$outcomeId[outcomeReference$psFile == psFile])
        args <- analysisRow$createPsArgs
        args$control$threads <- psCvThreads
        args$outcomeId <- outcomeId
        modelsToFit[[length(modelsToFit) + 1]] <- list(args = args, psFile = psFile)
      }
    }
  } else {
    # Don't refit PS model for every outcome
    for (sharedPsFile in unique(outcomeReference$sharedPsFile)) {
      if (sharedPsFile != "") {
        refRow <- outcomeReference[outcomeReference$sharedPsFile == sharedPsFile, ][1, ]
        analysisRow <- OhdsiRTools::matchInList(cmAnalysisList,
                                                list(analysisId = refRow$analysisId))[[1]]
        idToFile <- unique(outcomeReference[outcomeReference$sharedPsFile == sharedPsFile,
                                            c("outcomeId", "psFile")])
        idToFile <- idToFile[!file.exists(idToFile$psFile), ]
        if (nrow(idToFile) != 0) {
          args <- analysisRow$createPsArg
          args$control$threads <- psCvThreads
          modelsToFit[[length(modelsToFit) + 1]] <- list(cohortMethodDataFolder = refRow$cohortMethodDataFolder,
                                                         args = args,
                                                         idToFile = idToFile,
                                                         sharedPsFile = sharedPsFile)
        }
      }
    }
  }
  fitPSModel <- function(params, refitPsForEveryOutcome, underSampleComparatorToTreatedRatio) {

    fitModel <- function(cohortMethodData, args, underSampleComparatorToTreatedRatio) {
      underSample <- FALSE
      if (underSampleComparatorToTreatedRatio != 0) {
        treatedSize <- sum(cohortMethodData$cohorts$treatment)
        comparatorSize <- nrow(cohortMethodData$cohorts) - treatedSize
        if (comparatorSize/treatedSize > underSampleComparatorToTreatedRatio) {
          underSample <- TRUE
        }
      }
      if (underSample) {
        cohortMethodDataSample <- sampleComparator(cohortMethodData,
                                                   underSampleComparatorToTreatedRatio)
        args$cohortMethodData <- cohortMethodDataSample
        psSample <- do.call("createPs", args)
        ps <- recomputePsForFullData(psSample, cohortMethodDataSample, cohortMethodData)
      } else {
        args$cohortMethodData <- cohortMethodData
        ps <- do.call("createPs", args)
      }
      return(ps)
    }

    cohortMethodData <- loadCohortMethodData(params$cohortMethodDataFolder, readOnly = TRUE)
    if (refitPsForEveryOutcome) {
      args <- params$args
      args$outcomeId <- params$outcomeId
      ps <- fitModel(cohortMethodData, args, underSampleComparatorToTreatedRatio)
      saveRDS(ps, params$psFile)
    } else {
      # Fit model once for all outcomes:
      if (file.exists(params$sharedPsFile)) {
        ps <- readRDS(params$sharedPsFile)
      } else {
        ps <- fitModel(cohortMethodData, params$args, underSampleComparatorToTreatedRatio)
        saveRDS(ps, params$sharedPsFile)
      }
      # For every outcome, filter people with prior outcomes:
      for (i in 1:nrow(params$idToFile)) {
        outcomeId <- params$idToFile$outcomeId[i]
        psFile <- params$idToFile$psFile[i]
        if (!file.exists(psFile)) {
          if (ffbase::any.ff(cohortMethodData$exclude$outcomeId == outcomeId)) {
            filteredPs <- ps[!(ps$rowId %in% ff::as.ram(cohortMethodData$exclude$rowId[cohortMethodData$exclude$outcomeId ==
                                                                                         outcomeId])), ]
          } else {
            filteredPs <- ps
          }
          saveRDS(filteredPs, psFile)
        }
      }
    }
  }
  if (length(modelsToFit) != 0) {
    cluster <- OhdsiRTools::makeCluster(createPsThreads)
    OhdsiRTools::clusterRequire(cluster, "CohortMethod")
    dummy <- OhdsiRTools::clusterApply(cluster,
                                       modelsToFit,
                                       fitPSModel,
                                       refitPsForEveryOutcome,
                                       underSampleComparatorToTreatedRatio)
    OhdsiRTools::stopCluster(cluster)
  }

  writeLines("*** Trimming/Matching/Stratifying ***")
  tasks <- list()
  for (subPopFile in unique(outcomeReference$subPopFile)) {
    if (subPopFile != "" && !file.exists((subPopFile))) {
      refRow <- outcomeReference[outcomeReference$subPopFile == subPopFile, ][1, ]
      analysisRow <- OhdsiRTools::matchInList(cmAnalysisList,
                                              list(analysisId = refRow$analysisId))[[1]]
      outcomeId <- unique(outcomeReference$outcomeId[outcomeReference$subPopFile == subPopFile])
      tasks[[length(tasks) + 1]] <- list(psFile = refRow$psFile,
                                         args = analysisRow,
                                         subPopFile = subPopFile)
    }
  }
  trimMatchStratify <- function(params) {
    ps <- readRDS(params$psFile)
    if (params$args$trimByPs) {
      args <- list(data = ps)
      args <- append(args, params$args$trimByPsArgs)
      ps <- do.call("trimByPs", args)
    } else if (params$args$trimByPsToEquipoise) {
      args <- list(data = ps)
      args <- append(args, params$args$trimByPsToEquipoisesArgs)
      ps <- do.call("trimByPsToEquipoise", args)
    }
    if (params$args$matchOnPs) {
      args <- list(data = ps)
      args <- append(args, params$args$matchOnPsArgs)
      ps <- do.call("matchOnPs", args)
    } else if (params$args$matchOnPsAndCovariates) {
      args <- list(data = ps)
      args <- append(args, params$args$matchOnPsAndCovariatesArgs)
      ps <- do.call("matchOnPsAndCovariates", args)
    } else if (params$args$stratifyByPs) {
      args <- list(data = ps)
      args <- append(args, params$args$stratifyByPsArgs)
      ps <- do.call("stratifyByPs", args)
    } else if (params$args$stratifyByPsAndCovariates) {
      args <- list(data = ps)
      args <- append(args, params$args$stratifyByPsAndCovariatesArgs)
      ps <- do.call("stratifyByPsAndCovariates", args)
    }
    saveRDS(ps, params$subPopFile)
  }
  if (length(tasks) != 0) {
    cluster <- OhdsiRTools::makeCluster(trimMatchStratifyThreads)
    OhdsiRTools::clusterRequire(cluster, "CohortMethod")
    dummy <- OhdsiRTools::clusterApply(cluster, tasks, trimMatchStratify)
    OhdsiRTools::stopCluster(cluster)
  }

  writeLines("*** Computing covariate balance ***")
  tasks <- list()
  for (covariateBalanceFile in unique(outcomeReference$covariateBalanceFile)) {
    if (covariateBalanceFile != "" && !file.exists((covariateBalanceFile))) {
      refRow <- outcomeReference[outcomeReference$covariateBalanceFile == covariateBalanceFile, ][1, ]
      analysisRow <- OhdsiRTools::matchInList(cmAnalysisList,
                                              list(analysisId = refRow$analysisId))[[1]]
      tasks[[length(tasks) + 1]] <- list(subPopFile = refRow$subPopFile,
                                         outcomeId = refRow$outcomeId,
                                         cohortMethodDataFolder = refRow$cohortMethodDataFolder,
                                         covariateBalanceFile = refRow$covariateBalanceFile)
    }
  }
  computeCovarBal <- function(params) {
    cohortMethodData <- loadCohortMethodData(params$cohortMethodDataFolder, readOnly = TRUE)
    subPop <- readRDS(params$subPopFile)
    balance <- computeCovariateBalance(subPop, cohortMethodData, params$outcomeId)
    saveRDS(balance, params$covariateBalanceFile)
  }
  if (length(tasks) != 0) {
    cluster <- OhdsiRTools::makeCluster(computeCovarBalThreads)
    OhdsiRTools::clusterRequire(cluster, "CohortMethod")
    dummy <- OhdsiRTools::clusterApply(cluster, tasks, computeCovarBal)
    OhdsiRTools::stopCluster(cluster)
  }
  ################

  writeLines("*** Fitting outcome models ***")
  modelsToFit <- list()
  for (outcomeModelFile in unique(outcomeReference$outcomeModelFile)) {
    if (outcomeModelFile != "" && !file.exists((outcomeModelFile))) {
      refRow <- outcomeReference[outcomeReference$outcomeModelFile == outcomeModelFile, ][1, ]
      analysisRow <- OhdsiRTools::matchInList(cmAnalysisList,
                                              list(analysisId = refRow$analysisId))[[1]]
      outcomeId <- unique(outcomeReference$outcomeId[outcomeReference$outcomeModelFile == outcomeModelFile])
      args <- analysisRow$fitOutcomeModelArgs
      args$control$threads <- outcomeCvThreads
      args$outcomeId <- outcomeId
      modelsToFit[[length(modelsToFit) + 1]] <- list(cohortMethodDataFolder = refRow$cohortMethodDataFolder,
                                                     args = args,
                                                     subPopFile = refRow$subPopFile,
                                                     outcomeModelFile = outcomeModelFile)
    }
  }
  doFitOutcomeModel <- function(params) {
    cohortMethodData <- loadCohortMethodData(params$cohortMethodDataFolder, readOnly = TRUE)
    if (params$subPopFile != "") {
      subPopulation <- readRDS(params$subPopFile)
    } else {
      subPopulation <- NULL
    }
    args <- list(cohortMethodData = cohortMethodData, subPopulation = subPopulation)
    args <- append(args, params$args)
    outcomeModel <- do.call("fitOutcomeModel", args)
    saveRDS(outcomeModel, params$outcomeModelFile)
  }
  if (length(modelsToFit) != 0) {
    cluster <- OhdsiRTools::makeCluster(fitOutcomeModelThreads)
    OhdsiRTools::clusterRequire(cluster, "CohortMethod")
    dummy <- OhdsiRTools::clusterApply(cluster, modelsToFit, doFitOutcomeModel)
    OhdsiRTools::stopCluster(cluster)
  }
  invisible(outcomeReference)
}

.createCohortMethodDataFileName <- function(folder,
                                            argsId,
                                            targetId,
                                            comparatorId,
                                            indicationConceptIds) {
  name <- paste("CmData_a", argsId, "_t", targetId, "_c", comparatorId, sep = "")
  if (!is.null(indicationConceptIds) && length(indicationConceptIds) != 0) {
    name <- paste(name, "_i", indicationConceptIds[1], sep = "")
    if (length(indicationConceptIds) > 1) {
      name <- paste(name, "etc", sep = "")
    }
  }
  return(file.path(folder, name))
}

.createPsFileName <- function(folder,
                              argsId,
                              targetId,
                              comparatorId,
                              indicationConceptIds,
                              psArgsId) {
  name <- paste("ps_a", argsId, "_t", targetId, "_c", comparatorId, sep = "")
  if (!is.null(indicationConceptIds) && length(indicationConceptIds) != 0) {
    name <- paste(name, "_i", indicationConceptIds[1], sep = "")
    if (length(indicationConceptIds) > 1) {
      name <- paste(name, "etc", sep = "")
    }
  }
  name <- paste(name, "_p", psArgsId, sep = "")
  name <- paste(name, ".rds", sep = "")
  return(file.path(folder, name))
}

.createPsOutcomeFileName <- function(folder,
                                     argsId,
                                     targetId,
                                     comparatorId,
                                     indicationConceptIds,
                                     psArgsId,
                                     outcomeId) {
  name <- paste("ps_a", argsId, "_t", targetId, "_c", comparatorId, sep = "")
  if (!is.null(indicationConceptIds) && length(indicationConceptIds) != 0) {
    name <- paste(name, "_i", indicationConceptIds[1], sep = "")
    if (length(indicationConceptIds) > 1) {
      name <- paste(name, "etc", sep = "")
    }
  }
  name <- paste(name, "_p", psArgsId, sep = "")
  name <- paste(name, "_o", outcomeId, sep = "")
  name <- paste(name, ".rds", sep = "")
  return(file.path(folder, name))
}

.createSubPopFileName <- function(folder,
                                  argsId,
                                  targetId,
                                  comparatorId,
                                  indicationConceptIds,
                                  psArgsId,
                                  strataArgsId,
                                  outcomeId) {
  name <- paste("sub_a", argsId, "_t", targetId, "_c", comparatorId, sep = "")
  if (!is.null(indicationConceptIds) && length(indicationConceptIds) != 0) {
    name <- paste(name, "_i", indicationConceptIds[1], sep = "")
    if (length(indicationConceptIds) > 1) {
      name <- paste(name, "etc", sep = "")
    }
  }
  name <- paste(name, "_p", psArgsId, sep = "")
  name <- paste(name, "_s", strataArgsId, sep = "")
  name <- paste(name, "_o", outcomeId, sep = "")
  name <- paste(name, ".rds", sep = "")
  return(file.path(folder, name))
}

.createCovariateBalanceFileName <- function(folder,
                                            argsId,
                                            targetId,
                                            comparatorId,
                                            indicationConceptIds,
                                            psArgsId,
                                            strataArgsId,
                                            outcomeId) {
  name <- paste("bal_a", argsId, "_t", targetId, "_c", comparatorId, sep = "")
  if (!is.null(indicationConceptIds) && length(indicationConceptIds) != 0) {
    name <- paste(name, "_i", indicationConceptIds[1], sep = "")
    if (length(indicationConceptIds) > 1) {
      name <- paste(name, "etc", sep = "")
    }
  }
  name <- paste(name, "_p", psArgsId, sep = "")
  name <- paste(name, "_s", strataArgsId, sep = "")
  name <- paste(name, "_o", outcomeId, sep = "")
  name <- paste(name, ".rds", sep = "")
  return(file.path(folder, name))
}

.createOutcomeModelFileName <- function(folder,
                                        targetId,
                                        comparatorId,
                                        indicationConceptIds,
                                        outcomeId) {
  name <- paste("om_t", targetId, "_c", comparatorId, sep = "")
  if (!is.null(indicationConceptIds) && length(indicationConceptIds) != 0) {
    name <- paste(name, "_i", indicationConceptIds[1], sep = "")
    if (length(indicationConceptIds) > 1) {
      name <- paste(name, "etc", sep = "")
    }
  }
  name <- paste(name, "_o", outcomeId, sep = "")
  name <- paste(name, ".rds", sep = "")
  return(file.path(folder, name))
}

.selectByType <- function(type, value, label) {
  if (is.null(type)) {
    if (is.list(value)) {
      stop(paste("Multiple ",
                 label,
                 "s specified, but none selected in analyses (comparatorType).",
                 sep = ""))
    }
    return(value)
  } else {
    if (!is.list(value) || is.null(value[type])) {
      stop(paste(label, "type not found:", type))
    }
    return(value[type])
  }
}

#' Create a summary report of the analyses
#'
#' @param outcomeReference   A data.frame as created by the \code{\link{runCmAnalyses}} function.
#'
#' @return
#' A data frame with the following columns:
#' \tabular{ll}{
#' \verb{analysisId} \tab The unique identifier for a set of analysis choices.\cr
#' \verb{targetId} \tab The ID of the target drug.\cr
#' \verb{comparatorId} \tab The ID of the comparator group.\cr
#' \verb{indicationConceptIds} \tab The ID(s) of indications in which to nest to study. \cr
#' \verb{outcomeId} \tab The ID of the outcome.\cr
#' \verb{rr} \tab The estimated effect size.\cr
#' \verb{ci95lb} \tab The lower bound of the 95 percent confidence interval.\cr
#' \verb{ci95ub} \tab The upper bound of the 95 percent confidence interval.\cr
#' \verb{treated} \tab The number of subjects in the treated group (after any trimming and matching).\cr
#' \verb{comparator} \tab The number of subjects in the comparator group (after any trimming and matching).\cr
#' \verb{eventsTreated} \tab The number of outcomes in the treated group (after any trimming and matching).\cr
#' \verb{eventsComparator} \tab The number of outcomes in the comparator group (after any trimming and \cr
#' \tab matching).\cr
#' \verb{logRr} \tab The log of the estimated relative risk.\cr
#' \verb{seLogRr} \tab The standard error of the log of the estimated relative risk.\cr
#' }
#'
#' @export
summarizeAnalyses <- function(outcomeReference) {
  columns <- c("analysisId", "targetId", "comparatorId")
  if (!is.null(outcomeReference$indicationConceptIds)) {
    columns <- c(columns, "indicationConceptIds")
  }
  columns <- c(columns, "outcomeId")
  result <- outcomeReference[, columns]
  result$rr <- 0
  result$ci95lb <- 0
  result$ci95ub <- 0
  result$p <- 1
  result$treated <- 0
  result$comparator <- 0
  result$treatedDays <- NA
  result$comparatorDays <- NA
  result$eventsTreated <- 0
  result$eventsComparator <- 0
  result$logRr <- 0
  result$seLogRr <- 0
  for (i in 1:nrow(outcomeReference)) {
    outcomeModel <- readRDS(outcomeReference$outcomeModelFile[i])
    result$rr[i] <- if (is.null(coef(outcomeModel)))
      NA else exp(coef(outcomeModel))
    result$ci95lb[i] <- if (is.null(coef(outcomeModel)))
      NA else exp(confint(outcomeModel)[1])
    result$ci95ub[i] <- if (is.null(coef(outcomeModel)))
      NA else exp(confint(outcomeModel)[2])
    if (is.null(coef(outcomeModel))) {
      result$p[i] <- NA
    } else {
      z <- coef(outcomeModel)/outcomeModel$treatmentEstimate$seLogRr
      result$p[i] <- 2 * pmin(pnorm(z), 1 - pnorm(z))
    }
    result$treated[i] <- sum(outcomeModel$data$treatment == 1)
    result$comparator[i] <- sum(outcomeModel$data$treatment == 0)
    if (outcomeModel$modelType != "clr" && outcomeModel$modelType != "lr") {
      result$treatedDays[i] <- sum(outcomeModel$data$time[outcomeModel$data$treatment == 1])
      result$comparatorDays[i] <- sum(outcomeModel$data$time[outcomeModel$data$treatment == 0])
    }
    result$eventsTreated[i] <- sum(outcomeModel$data$y[outcomeModel$data$treatment == 1])
    result$eventsComparator[i] <- sum(outcomeModel$data$y[outcomeModel$data$treatment == 0])
    result$logRr[i] <- if (is.null(coef(outcomeModel)))
      NA else coef(outcomeModel)
    result$seLogRr[i] <- if (is.null(coef(outcomeModel)))
      NA else outcomeModel$treatmentEstimate$seLogRr
  }
  return(result)
}
