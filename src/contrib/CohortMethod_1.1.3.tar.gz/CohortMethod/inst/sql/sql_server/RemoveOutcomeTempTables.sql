TRUNCATE TABLE #cohort_outcome;

DROP TABLE #cohort_outcome;

TRUNCATE TABLE #cohort_excluded_person;

DROP TABLE #cohort_excluded_person;