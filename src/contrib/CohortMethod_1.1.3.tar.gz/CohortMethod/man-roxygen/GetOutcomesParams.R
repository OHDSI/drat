#' @param outcomeDatabaseSchema            The name of the database schema that is the location where
#'                                         the data used to define the outcome cohorts is available. If
#'                                         exposureTable = CONDITION_ERA, exposureDatabaseSchema is not
#'                                         used by assumed to be cdmSchema.  Requires read permissions
#'                                         to this database.
#' @param outcomeTable                     The tablename that contains the outcome cohorts.  If
#'                                         outcomeTable <> CONDITION_OCCURRENCE, then expectation is
#'                                         outcomeTable has format of COHORT table:
#'                                         COHORT_DEFINITION_ID, SUBJECT_ID, COHORT_START_DATE,
#'                                         COHORT_END_DATE.
#' @param outcomeIds                       A list of CONCEPT_IDs used to define outcomes.  If
#'                                         outcomeTable = CONDITION_OCCURRENCE, the list is a set of
#'                                         ancestor CONCEPT_IDs, and all occurrences of all descendant
#'                                         concepts will be selected.  If outcomeTable <>
#'                                         CONDITION_OCCURRENCE, the list contains records found in
#'                                         COHORT_DEFINITION_ID field.
#' @param outcomeConditionTypeConceptIds   A list of TYPE_CONCEPT_ID values that will restrict
#'                                         condition occurrences.  Only applicable if outcomeTable =
#'                                         CONDITION_OCCURRENCE.
