library("testthat")

# todo: Write test for simple outcome models, using random drawing from exponential distributions
