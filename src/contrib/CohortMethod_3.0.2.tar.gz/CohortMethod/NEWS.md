CohortMethod 3.0.2
==================

Changes:

1. (Much) faster variable ratio matching
