library(testthat)
test_check("Characterization")
