## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)

## ----eval=FALSE---------------------------------------------------------------
#  connectionDetails <- Eunomia::getEunomiaConnectionDetails()
#  Eunomia::createCohorts(connectionDetails)
#  
#  databaseDetails <- PatientLevelPrediction::createDatabaseDetails(
#    connectionDetails = connectionDetails,
#    cdmDatabaseSchema = "main", cdmDatabaseId = 'eunomia',
#    cohortDatabaseSchema = "main",
#    cohortTable = "cohort",
#    cohortId = 4,
#    outcomeIds = 3,
#    outcomeDatabaseSchema = "main",
#    outcomeTable =  "cohort",
#    cdmDatabaseName = 'eunomia'
#  )

## ----eval=FALSE---------------------------------------------------------------
#  # example model design 1
#  
#  # 1. specify the cohort_definition_id for the target cohort
#  targetId <- 4
#  
#  # 2. specify the cohort_definition_id for the outcome
#  outcomeId <- 3
#  
#  # 3. specify the covariates
#  # we include gender, age, race, ethnicity, age in 5 year groups,
#  # conditions groups (using the vocabulary hierarchy) in the past
#  # 365 days and drug ingredients in the past 365 days
#  # we do not include conditions/drugs that occur at index
#  covSet <- FeatureExtraction::createCovariateSettings(
#    useDemographicsGender = T,
#    useDemographicsAge = T,
#    useDemographicsRace = T,
#    useDemographicsEthnicity = T,
#    useDemographicsAgeGroup = T,
#    useConditionGroupEraLongTerm = T,
#    useDrugEraStartLongTerm  = T,
#    endDays = -1
#  )
#  
#  # 4. specify inclusion for data extraction
#  # we restrict to patients in the target cohort with >=365 days
#  # observation prior to index and only include patients once
#  # (the first cohort entry)
#  restrictPlpDataSettings <- PatientLevelPrediction::createRestrictPlpDataSettings(
#    firstExposureOnly = T,
#    washoutPeriod = 365
#  )
#  
#  # 5. specify inclusion and time-at-risk
#  # We are predicting the outcome occurring from 1 day after index until
#  # 730 days after index.  We keep patients who drop out during the
#  # time-at-risk.
#  populationSet <- PatientLevelPrediction::createStudyPopulationSettings(
#    requireTimeAtRisk = F,
#    riskWindowStart = 1,
#    riskWindowEnd = 730
#  )
#  
#  # 6. specify the model
#  # We train a default LASSO logistic regression model
#  modelSetting <- PatientLevelPrediction::setLassoLogisticRegression()
#  
#  # 7. specify the preprocessing
#  # We use default preprocessing (normalize data and remove rare/redundant covariates)
#  preprocessSettings <- PatientLevelPrediction::createPreprocessSettings()
#  
#  # input these into PatientLevelPrediction::createModelDesign
#  # this generates a modelDesign object
#  modelDesign1 <- PatientLevelPrediction::createModelDesign(
#    targetId = targetId,
#    outcomeId = outcomeId,
#    restrictPlpDataSettings = restrictPlpDataSettings,
#    covariateSettings = covSet,
#    runCovariateSummary = F,
#    modelSettings = modelSetting,
#    populationSettings = populationSet,
#    preprocessSettings = preprocessSettings
#  )

## ----eval=FALSE---------------------------------------------------------------
#  # example model design 2
#  
#  # 1. specify the cohort_definition_id for the target cohort
#  targetId <- 4
#  
#  # 2. specify the cohort_definition_id for the outcome
#  outcomeId <- 3
#  
#  # 3. specify the covariates
#  # we include gender, age, race, ethnicity, age in 5 year groups,
#  # conditions groups (using the vocabulary hierarchy) in the past
#  # 365 days and drug ingredients in the past 365 days
#  # we do not include conditions/drugs that occur at index
#  covSet <- FeatureExtraction::createCovariateSettings(
#    useDemographicsGender = T,
#    useDemographicsAge = T,
#    useDemographicsRace = T,
#    useDemographicsEthnicity = T,
#    useDemographicsAgeGroup = T,
#    useConditionGroupEraLongTerm = T,
#    useDrugEraStartLongTerm  = T,
#    endDays = -1
#  )
#  
#  # 4. specify inclusion for data extraction
#  # we restrict to patients in the target cohort with >=365 days
#  # observation prior to index and only include patients once
#  # (the first cohort entry)
#  restrictPlpDataSettings <- PatientLevelPrediction::createRestrictPlpDataSettings(
#    firstExposureOnly = T,
#    washoutPeriod = 365
#  )
#  
#  # 5. specify inclusion and time-at-risk
#  # We are predicting the outcome occurring from 1 day after index until
#  # 730 days after index.  We keep patients who drop out during the
#  # time-at-risk.
#  populationSet <- PatientLevelPrediction::createStudyPopulationSettings(
#    requireTimeAtRisk = F,
#    riskWindowStart = 1,
#    riskWindowEnd = 730
#  )
#  
#  # 6. specify the model
#  # We train a gradient boosting machine with default
#  # hyper-parameter search
#  modelSetting <- PatientLevelPrediction::setGradientBoostingMachine()
#  
#  # 7. specify the preprocessing
#  # We use default preprocessing (normalize data and remove rare/redundant covariates)
#  preprocessSettings <- PatientLevelPrediction::createPreprocessSettings()
#  
#  modelDesign2 <- PatientLevelPrediction::createModelDesign(
#    targetId = targetId,
#    outcomeId = outcomeId,
#    restrictPlpDataSettings = restrictPlpDataSettings,
#    covariateSettings = covSet,
#    runCovariateSummary = F,
#    modelSettings = modelSetting,
#    populationSettings = populationSet,
#    preprocessSettings = preprocessSettings
#  )

## ----eval=FALSE---------------------------------------------------------------
#  # example model design 3
#  
#  # 1. specify the cohort_definition_id for the target cohort
#  targetId <- 4
#  
#  # 2. specify the cohort_definition_id for the outcome
#  outcomeId <- 3
#  
#  # 3. specify the covariates
#  # we include gender, age, race, ethnicity, age in 5 year groups,
#  # conditions groups (using the vocabulary hierarchy) in the past
#  # 365 days and drug ingredients in the past 365 days
#  # we do not include conditions/drugs that occur at index
#  # we also include measurements indicators in the past 365 days
#  covSet <- FeatureExtraction::createCovariateSettings(
#    useDemographicsGender = T,
#    useDemographicsAge = T,
#    useDemographicsRace = T,
#    useDemographicsEthnicity = T,
#    useDemographicsAgeGroup = T,
#    useConditionGroupEraLongTerm = T,
#    useDrugEraStartLongTerm  = T,
#    useMeasurementLongTerm = T,
#    endDays = -1
#  )
#  
#  # 4. specify inclusion for data extraction
#  # we restrict to patients in the target cohort with >=365 days
#  # observation prior to index and only include patients once
#  # (the first cohort entry)
#  restrictPlpDataSettings <- PatientLevelPrediction::createRestrictPlpDataSettings(
#    firstExposureOnly = T,
#    washoutPeriod = 365
#  )
#  
#  # 5. specify inclusion and time-at-risk
#  # We are predicting the outcome occurring from 1 day after index until
#  # 730 days after index.  We keep patients who drop out during the
#  # time-at-risk.
#  populationSet <- PatientLevelPrediction::createStudyPopulationSettings(
#    requireTimeAtRisk = F,
#    riskWindowStart = 1,
#    riskWindowEnd = 730
#  )
#  
#  # 6. specify the model
#  # We train a LASSO logistic regression model but include the
#  # intercept in the regularization
#  modelSetting <- PatientLevelPrediction::setLassoLogisticRegression(
#    forceIntercept = T
#    )
#  
#  # 7. specify the preprocessing
#  # We use default preprocessing (normalize data and remove rare/redundant covariates)
#  preprocessSettings <- PatientLevelPrediction::createPreprocessSettings()
#  
#  modelDesign3 <- PatientLevelPrediction::createModelDesign(
#    targetId = targetId,
#    outcomeId = outcomeId,
#    restrictPlpDataSettings = restrictPlpDataSettings,
#    covariateSettings = covSet,
#    runCovariateSummary = F,
#    modelSettings = modelSetting,
#    populationSettings = populationSet,
#    preprocessSettings = preprocessSettings
#  )
#  

## ----eval=FALSE---------------------------------------------------------------
#  
#  splitSettings <- PatientLevelPrediction::createDefaultSplitSetting()
#  

## ----eval=FALSE---------------------------------------------------------------
#  
#  filterSettings <- list(
#      metric = 'AUROC',
#      evaluation = 'CV',
#      minValue = 0.5,
#      maxValue = 1
#      )

## ----eval=FALSE---------------------------------------------------------------
#  combinerSettings <- EnsemblePatientLevelPrediction::createFusionCombiner(
#      type = 'uniform',
#      scaleFunction = 'normalize'
#    )

## ----eval=FALSE---------------------------------------------------------------
#  ensembleSettings <- EnsemblePatientLevelPrediction::setEnsembleFromDesign(
#    modelDesignList = list(modelDesign1, modelDesign2, modelDesign3),
#    databaseDetails = databaseDetails,
#    splitSettings = splitSettings,
#    filterSettings = filterSettings,
#    combinerSettings = combinerSettings
#  )

## ----eval=FALSE---------------------------------------------------------------
#  ensemble <- EnsemblePatientLevelPrediction::runEnsemble(
#    ensembleSettings = ensembleSettings,
#    logSettings = PatientLevelPrediction::createLogSettings(logName = 'ensemble'),
#    saveDirectory = './testingEnsemble'
#  )
#  

## ----eval=FALSE---------------------------------------------------------------
#  
#  EnsemblePatientLevelPrediction::saveEnsemble(
#    ensemble,
#    'C:/any/location/here'
#  )
#  

## ----eval=FALSE---------------------------------------------------------------
#  connectionDetails <- Eunomia::getEunomiaConnectionDetails()
#  Eunomia::createCohorts(connectionDetails)
#  
#  databaseDetails <- PatientLevelPrediction::createDatabaseDetails(
#    connectionDetails = connectionDetails,
#    cdmDatabaseSchema = "main", cdmDatabaseId = 'eunomia',
#    cohortDatabaseSchema = "main",
#    cohortTable = "cohort",
#    cohortId = 4,
#    outcomeIds = 3,
#    outcomeDatabaseSchema = "main",
#    outcomeTable =  "cohort",
#    cdmDatabaseName = 'eunomia'
#  )

## ----eval=FALSE---------------------------------------------------------------
#  # example model design 1
#  
#  # 1. specify the cohort_definition_id for the target cohort
#  targetId <- 4
#  
#  # 2. specify the cohort_definition_id for the outcome
#  outcomeId <- 3
#  
#  # 3. specify the covariates
#  # we include gender, age, race, ethnicity, age in 5 year groups,
#  # conditions groups (using the vocabulary hierarchy) in the past
#  # 365 days and drug ingredients in the past 365 days
#  # we do not include conditions/drugs that occur at index
#  covSet <- FeatureExtraction::createCovariateSettings(
#    useDemographicsGender = T,
#    useDemographicsAge = T,
#    useDemographicsRace = T,
#    useDemographicsEthnicity = T,
#    useDemographicsAgeGroup = T,
#    useConditionGroupEraLongTerm = T,
#    useDrugEraStartLongTerm  = T,
#    endDays = -1
#  )
#  
#  # 4. specify inclusion for data extraction
#  # we restrict to patients in the target cohort with >=365 days
#  # observation prior to index and only include patients once
#  # (the first cohort entry)
#  restrictPlpDataSettings <- PatientLevelPrediction::createRestrictPlpDataSettings(
#    firstExposureOnly = T,
#    washoutPeriod = 365
#  )
#  
#  # 5. specify inclusion and time-at-risk
#  # We are predicting the outcome occurring from 1 day after index until
#  # 730 days after index.  We keep patients who drop out during the
#  # time-at-risk.
#  populationSet <- PatientLevelPrediction::createStudyPopulationSettings(
#    requireTimeAtRisk = F,
#    riskWindowStart = 1,
#    riskWindowEnd = 730
#  )
#  
#  # 6. specify the model
#  # We train a default LASSO logistic regression model
#  modelSetting <- PatientLevelPrediction::setLassoLogisticRegression()
#  
#  # 7. specify the preprocessing
#  # We use default preprocessing (normalize data and remove rare/redundant covariates)
#  preprocessSettings <- PatientLevelPrediction::createPreprocessSettings()
#  
#  # input these into PatientLevelPrediction::createModelDesign
#  # this generates a modelDesign object
#  modelDesign1 <- PatientLevelPrediction::createModelDesign(
#    targetId = targetId,
#    outcomeId = outcomeId,
#    restrictPlpDataSettings = restrictPlpDataSettings,
#    covariateSettings = covSet,
#    runCovariateSummary = F,
#    modelSettings = modelSetting,
#    populationSettings = populationSet,
#    preprocessSettings = preprocessSettings
#  )

## ----eval=FALSE---------------------------------------------------------------
#  # example model design 2
#  
#  # 1. specify the cohort_definition_id for the target cohort
#  targetId <- 4
#  
#  # 2. specify the cohort_definition_id for the outcome
#  outcomeId <- 3
#  
#  # 3. specify the covariates
#  # we include gender, age, race, ethnicity, age in 5 year groups,
#  # conditions groups (using the vocabulary hierarchy) in the past
#  # 365 days and drug ingredients in the past 365 days
#  # we do not include conditions/drugs that occur at index
#  covSet <- FeatureExtraction::createCovariateSettings(
#    useDemographicsGender = T,
#    useDemographicsAge = T,
#    useDemographicsRace = T,
#    useDemographicsEthnicity = T,
#    useDemographicsAgeGroup = T,
#    useConditionGroupEraLongTerm = T,
#    useDrugEraStartLongTerm  = T,
#    endDays = -1
#  )
#  
#  # 4. specify inclusion for data extraction
#  # we restrict to patients in the target cohort with >=365 days
#  # observation prior to index and only include patients once
#  # (the first cohort entry)
#  restrictPlpDataSettings <- PatientLevelPrediction::createRestrictPlpDataSettings(
#    firstExposureOnly = T,
#    washoutPeriod = 365
#  )
#  
#  # 5. specify inclusion and time-at-risk
#  # We are predicting the outcome occurring from 1 day after index until
#  # 730 days after index.  We keep patients who drop out during the
#  # time-at-risk.
#  populationSet <- PatientLevelPrediction::createStudyPopulationSettings(
#    requireTimeAtRisk = F,
#    riskWindowStart = 1,
#    riskWindowEnd = 730
#  )
#  
#  # 6. specify the model
#  # We train a gradient boosting machine with default
#  # hyper-parameter search
#  modelSetting <- PatientLevelPrediction::setGradientBoostingMachine()
#  
#  # 7. specify the preprocessing
#  # We use default preprocessing (normalize data and remove rare/redundant covariates)
#  preprocessSettings <- PatientLevelPrediction::createPreprocessSettings()
#  
#  modelDesign2 <- PatientLevelPrediction::createModelDesign(
#    targetId = targetId,
#    outcomeId = outcomeId,
#    restrictPlpDataSettings = restrictPlpDataSettings,
#    covariateSettings = covSet,
#    runCovariateSummary = F,
#    modelSettings = modelSetting,
#    populationSettings = populationSet,
#    preprocessSettings = preprocessSettings
#  )

## ----eval=FALSE---------------------------------------------------------------
#  # example model design 3
#  
#  # 1. specify the cohort_definition_id for the target cohort
#  targetId <- 4
#  
#  # 2. specify the cohort_definition_id for the outcome
#  outcomeId <- 3
#  
#  # 3. specify the covariates
#  # we include gender, age, race, ethnicity, age in 5 year groups,
#  # conditions groups (using the vocabulary hierarchy) in the past
#  # 365 days and drug ingredients in the past 365 days
#  # we do not include conditions/drugs that occur at index
#  # we also include measurements indicators in the past 365 days
#  covSet <- FeatureExtraction::createCovariateSettings(
#    useDemographicsGender = T,
#    useDemographicsAge = T,
#    useDemographicsRace = T,
#    useDemographicsEthnicity = T,
#    useDemographicsAgeGroup = T,
#    useConditionGroupEraLongTerm = T,
#    useDrugEraStartLongTerm  = T,
#    useMeasurementLongTerm = T,
#    endDays = -1
#  )
#  
#  # 4. specify inclusion for data extraction
#  # we restrict to patients in the target cohort with >=365 days
#  # observation prior to index and only include patients once
#  # (the first cohort entry)
#  restrictPlpDataSettings <- PatientLevelPrediction::createRestrictPlpDataSettings(
#    firstExposureOnly = T,
#    washoutPeriod = 365
#  )
#  
#  # 5. specify inclusion and time-at-risk
#  # We are predicting the outcome occurring from 1 day after index until
#  # 730 days after index.  We keep patients who drop out during the
#  # time-at-risk.
#  populationSet <- PatientLevelPrediction::createStudyPopulationSettings(
#    requireTimeAtRisk = F,
#    riskWindowStart = 1,
#    riskWindowEnd = 730
#  )
#  
#  # 6. specify the model
#  # We train a LASSO logistic regression model but include the
#  # intercept in the regularization
#  modelSetting <- PatientLevelPrediction::setLassoLogisticRegression(
#    forceIntercept = T
#    )
#  
#  # 7. specify the preprocessing
#  # We use default preprocessing (normalize data and remove rare/redundant covariates)
#  preprocessSettings <- PatientLevelPrediction::createPreprocessSettings()
#  
#  modelDesign3 <- PatientLevelPrediction::createModelDesign(
#    targetId = targetId,
#    outcomeId = outcomeId,
#    restrictPlpDataSettings = restrictPlpDataSettings,
#    covariateSettings = covSet,
#    runCovariateSummary = F,
#    modelSettings = modelSetting,
#    populationSettings = populationSet,
#    preprocessSettings = preprocessSettings
#  )
#  

## ----eval=FALSE---------------------------------------------------------------
#  
#  splitSettings <- PatientLevelPrediction::createDefaultSplitSetting(
#    testFraction = 0.5,
#    trainFraction = 0.5
#    )
#  

## ----eval=FALSE---------------------------------------------------------------
#  
#  filterSettings <- list(
#      metric = 'AUROC',
#      evaluation = 'CV',
#      minValue = 0.5,
#      maxValue = 1
#      )

## ----eval=FALSE---------------------------------------------------------------
#  combinerSettings <- EnsemblePatientLevelPrediction::createStackerCombiner(
#    levelTwoType = 'logisticRegressionStacker',
#    levelTwoDataSettings = list(
#      type = 'Test',
#      proportion = 0.5
#      )
#  )
#  
#  # if you have smaller data and you dont want to split the Test data into two, you can train the stacker on the CV predictions using:
#  
#  combinerSettings2 <- EnsemblePatientLevelPrediction::createStackerCombiner(
#    levelTwoType = 'logisticRegressionStacker',
#    levelTwoDataSettings = list(type = 'CV')
#  )
#  

## ----eval=FALSE---------------------------------------------------------------
#  ensembleSettings <- EnsemblePatientLevelPrediction::setEnsembleFromDesign(
#    modelDesignList = list(modelDesign1, modelDesign2, modelDesign3),
#    databaseDetails = databaseDetails,
#    splitSettings = splitSettings,
#    filterSettings = filterSettings,
#    combinerSettings = combinerSettings
#  )

## ----eval=FALSE---------------------------------------------------------------
#  ensemble <- EnsemblePatientLevelPrediction::runEnsemble(
#    ensembleSettings = ensembleSettings,
#    logSettings = PatientLevelPrediction::createLogSettings(logName = 'ensemble'),
#    saveDirectory = './testingEnsemble'
#  )
#  

## ----eval=FALSE---------------------------------------------------------------
#  
#  EnsemblePatientLevelPrediction::saveEnsemble(
#    ensemble,
#    'C:/any/location/here'
#  )
#  

## ----eval=FALSE---------------------------------------------------------------
#  
#  # if you have a runPLP result at runPlpLocation1, load it into R
#  result1 <- PatientLevelPrediction::loadPlpResult(runPlpLocation1)
#  
#  # if you have a runPLP result at runPlpLocation2, load it into R
#  result2 <- PatientLevelPrediction::loadPlpResult(runPlpLocation2)
#  
#  # if you have a runPLP result at runPlpLocation3, load it into R
#  result3 <- PatientLevelPrediction::loadPlpResult(runPlpLocation3)
#  
#  # if you have a runPLP result at runPlpLocation4, load it into R
#  result4 <- PatientLevelPrediction::loadPlpResult(runPlpLocation4)
#  
#  resultList <- list(
#    result1,
#    result2,
#    result3,
#    result4
#  )
#  

## ----eval=FALSE---------------------------------------------------------------
#  
#  filterSettings <- list(
#      metric = 'AUROC',
#      evaluation = 'CV',
#      minValue = 0.5,
#      maxValue = 1
#      )

## ----eval=FALSE---------------------------------------------------------------
#  combinerSettings <- EnsemblePatientLevelPrediction::createFusionCombiner(
#      type = 'AUROC',
#      evaluation = 'CV',
#      scaleFunction = 'normalize'
#    )

## ----eval=FALSE---------------------------------------------------------------
#  ensembleSettings <- EnsemblePatientLevelPrediction::setEnsembleFromResults(
#    resultList = resultList,
#    filterSettings = filterSettings,
#    combinerSettings = combinerSettings
#  )

## ----eval=FALSE---------------------------------------------------------------
#  ensemble <- EnsemblePatientLevelPrediction::runEnsemble(
#    ensembleSettings = ensembleSettings,
#    logSettings = PatientLevelPrediction::createLogSettings(logName = 'ensemble'),
#    saveDirectory = './testingEnsemble2'
#  )
#  

## ----tidy=TRUE,eval=FALSE-----------------------------------------------------
#  saveEnsemble(
#    ensembleResults,
#    dirPath = file.path(getwd(),'ensemble')
#    )
#  
#  ensembleResult <- loadEnsemble(file.path(getwd(),'ensemble'))

## ----tidy=TRUE,eval=FALSE-----------------------------------------------------
#  saveEnsembleModel(
#    ensembleResults$model,
#    dirPath = file.path(getwd(),'ensembleModel')
#    )
#  
#  ensembleModel <- loadEnsembleModel(file.path(getwd(),'ensembleModel'))

## ----eval=FALSE---------------------------------------------------------------
#  
#  newDatabaseDetails <- PatientLevelPrediction::createDatabaseDetails(
#    connectionDetails = 'add new connection details',
#  )
#  
#  ensembleModel <- EnsemblePatientLevelPrediction::loadEnsembleModel(
#    file.path(getwd(),'ensembleModel')
#  )
#  ensemblePrediction <- applyEnsemble(
#    ensembleModel = ensembleModel,
#    newDatabaseDetails = newDatabaseDetails,
#    logSettings = PatientLevelPrediction::createLogSettings(),
#    outputFolder = 'C:/locationToSaveBaseModelResults'
#  )
#  

## ----eval=FALSE---------------------------------------------------------------
#  # Run the Ensemble demo
#  demo("EnsembleModelDemo", package = "EnsemblePatientLevelPrediction")

## ----tidy=TRUE,eval=TRUE------------------------------------------------------
citation("PatientLevelPrediction")

