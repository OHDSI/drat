PhenotypeLibrary 3.1.2
======================

Added Vignette: Cohort Definitions in OHDSI Phenotype Library
Added new function: to get log of phenotype changes

PhenotypeLibrary 3.1.1
======================

Added Vignette: How to use Phenotype Library R Package
Added tests to conform to HADES
This package is now part of OHDSI HADES.

PhenotypeLibrary 3.1.0
======================

Cohorts in this release are all new. Source: atlas-phenotype.ohdsi.org

PhenotypeLibrary 3.0.0
======================

Initial version using new structure.
