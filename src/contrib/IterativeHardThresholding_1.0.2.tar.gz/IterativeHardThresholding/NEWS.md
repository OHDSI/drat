IterativeHardThresholding 1.0.2
=============

Changes: prepare for CRAN


IterativeHardThresholding 1.0.0
=============

Changes: initial HADES version
