cohortBaseUrl <- "https://atlas.ohdsi.org/#/cohortdefinition/"
conceptBaseUrl <- "https://athena.ohdsi.org/search-terms/terms/"
cohortDiagnosticModeDefaultTitle <- "Cohort Diagnostics"
phenotypeLibraryModeDefaultTitle <- "Phenotype Library"
