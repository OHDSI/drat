## ---- echo = FALSE, message = FALSE-------------------------------------------
library(SqlRender)
knitr::opts_chunk$set(
  cache = FALSE,
  comment = "#>",
  error = FALSE,
  tidy = FALSE
)

## ----tidy=FALSE,eval=FALSE----------------------------------------------------
#  createMergedResultsFile("C:/temp/allZipFiles", sqliteDbPath = "MyCohortDiagnosticsResulst.sqlite")

## ----tidy=FALSE,eval=FALSE----------------------------------------------------
#  launchDiagnosticsExplorer(sqliteDbPath = "MyCohortDiagnosticsResulst.sqlite")

## ----tidy=FALSE,eval=FALSE----------------------------------------------------
#  launchDiagnosticsExplorer(
#    sqliteDbPath = "MyCohortDiagnosticsResulst.sqlite",
#    makePublishable = TRUE,
#    publishDir = file.path(getwd(), "MyStudyDiagnosticsExplorer"),
#    overwritePublishDir = TRUE
#  )

## ----tidy=FALSE,eval=FALSE----------------------------------------------------
#  createDiagnosticsExplorerZip(outputZipfile = "MyCdProject.zip", sqliteDbPath = "MyCohortDiagnosticsResulst.sqlite")

