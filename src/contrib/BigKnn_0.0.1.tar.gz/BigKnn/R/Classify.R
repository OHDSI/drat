# Copyright 2016 Observational Health Data Sciences and Informatics
#
# This file is part of BigKnn
# 
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# 
#     http://www.apache.org/licenses/LICENSE-2.0
# 
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

#' Predict using a K-nearest neighbor (KNN) classifier
#'
#' @description
#' \code{predictKnn} uses a KNN classifier to generate predictions.
#'
#' @param covariates    A ffdf object containing the covariates with predefined columns (see below).
#' @param indexFolder   Path to a local folder where the KNN classifier index can be stored.
#' @param k             The number of nearest neighbors to use to predict the outcome.
#' @param weighted      Should the prediction be weigthed by the (inverse of the ) distance metric?
#' @param checkSorting  Check if the data are sorted appropriately, and if not, sort.
#' @param quiet         If true, (warning) messages are surpressed.
#' @param threads       Number of parallel threads to used for the computation.
#'
#' @details
#' These columns are expected in the covariates object:
#' \tabular{lll}{
#'   \verb{rowId}  	\tab(integer) \tab Row ID is used to link multiple covariates (x) to a single outcome (y) \cr
#'   \verb{covariateId}    \tab(integer) \tab A numeric identifier of a covariate  \cr
#'   \verb{covariateValue}    \tab(real) \tab The value of the specified covariate \cr
#' }
#'
#' Note: If checkSorting is turned off, the covariate table should be sorted by rowId.
#'
#' @return
#' A data.frame with two columns:
#' \tabular{lll}{
#'   \verb{rowId}  	\tab(integer) \tab Row ID is used to link multiple covariates (x) to a single outcome (y) \cr
#'   \verb{prediction}    \tab(real) \tab A number between 0 and 1 representing the probability of the outcome  \cr
#' }
#' 
#' @export
predictKnn <- function(covariates,
                       indexFolder, 
                       k = 1000,
                       weighted = TRUE,
                       checkSorting = TRUE,
                       quiet = FALSE,
                       threads = 1) {
  start <- Sys.time()
  if (checkSorting){
    if (!Cyclops::isSorted(covariates, c("rowId"))){
      if(!quiet) {
        writeLines("Sorting covariates by rowId")
      }
      rownames(covariates) <- NULL #Needs to be null or the ordering of ffdf will fail
      covariates <- covariates[ff::ffdforder(covariates[c("rowId")]),]
    }
  }
  predictionThread <- function(chunk, indexFolder, k, weighted, covariates, needToOpen) {
    if (needToOpen) {
      ff::open.ffdf(covariates, readonly = TRUE)
    }
    knn <- rJava::new(rJava::J("org.ohdsi.bigKnn.LuceneKnn"), indexFolder)
    knn$openForReading();
    knn$setK(as.integer(k))
    knn$setWeighted(weighted)
    result <- data.frame()
    for (i in bit::chunk(from = chunk[1], to = chunk[2], by = 100000)){
      prediction <- knn$predict(rJava::.jarray(covariates$rowId[i]), 
                                rJava::.jarray(covariates$covariateId[i]),
                                rJava::.jarray(covariates$covariateValue[i]))
      prediction <- lapply(prediction, rJava::.jevalArray)
      prediction <- data.frame(rowId = prediction[[1]], value = prediction[[2]])
      result <- rbind(result, prediction)
    }
    prediction <- knn$finalizePredict()
    prediction <- lapply(prediction, rJava::.jevalArray)
    prediction <- data.frame(rowId = prediction[[1]], value = prediction[[2]])
    result <- rbind(result, prediction)
    if (needToOpen) {
      ff::close.ffdf(covariates)
    }
    return(result)
  }
  cluster <- OhdsiRTools::makeCluster(threads)
  OhdsiRTools::clusterRequire(cluster, "BigKnn")
  chunks <- bit::chunk(covariates, length.out = threads)
  needToOpen <- (threads > 1)
  results <- OhdsiRTools::clusterApply(cluster = cluster, 
                                      x = chunks, 
                                      fun = predictionThread, 
                                      indexFolder = indexFolder, 
                                      k = k, 
                                      weighted = weighted, 
                                      covariates = covariates,
                                      needToOpen = needToOpen)
  OhdsiRTools::stopCluster(cluster)
  results <- do.call(rbind, results)
  delta <- Sys.time() - start
  writeLines(paste("Prediction took", signif(delta, 3), attr(delta, "units")))
  return(results)
}
