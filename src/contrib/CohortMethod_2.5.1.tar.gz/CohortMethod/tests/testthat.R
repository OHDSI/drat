library(testthat)
test_check("CohortMethod")
