## ----echo = FALSE, message = FALSE--------------------------------------------
knitr::opts_chunk$set(
  cache = FALSE,
  comment = "#>",
  error = FALSE,
  tidy = FALSE
)

library(reactable)

## ----tidy=FALSE,eval=TRUE, echo = FALSE---------------------------------------
camelCaseToTitleCase <- function(string) {
  errorMessages <- checkmate::makeAssertCollection()
  checkmate::assertCharacter(string, add = errorMessages)
  checkmate::reportAssertions(collection = errorMessages)

  string <- gsub("([A-Z])", " \\1", string)
  string <- gsub("([a-z])([0-9])", "\\1 \\2", string)
  substr(string, 1, 1) <- toupper(substr(string, 1, 1))
  return(string)
}

report <- PhenotypeLibrary::getPhenotypeLog()

colnames(report) <- camelCaseToTitleCase(colnames(report))

columnDefinitions <- list()

colnamesInReport <- colnames(report)

for (i in (1:length(colnamesInReport))) {
  columnDefinitions[[colnamesInReport[[i]]]] <-
    reactable::colDef(
      name = colnamesInReport[[i]],
      minWidth = nchar(colnamesInReport[[i]]) * 10,
      sortable = TRUE,
      resizable = TRUE,
      show = TRUE,
      html = TRUE,
      na = "",
      align = "left"
    )
}

columnDefinitions[["Cohort Name"]] <-
  reactable::colDef(
    name = "Cohort Name",
    minWidth = 500,
    sortable = TRUE,
    resizable = TRUE,
    show = TRUE,
    html = TRUE,
    na = "",
    align = "left"
  )

columnDefinitions[["Cohort Id"]] <-
  reactable::colDef(
    name = "Cohort Id",
    minWidth = 100,
    sticky = "left",
    sortable = TRUE,
    resizable = TRUE,
    show = TRUE,
    html = TRUE,
    na = "",
    align = "left"
  )

## ----tidy=FALSE,eval=TRUE, echo = FALSE---------------------------------------
reactable::reactable(
  data = report,
  columns = columnDefinitions,
  sortable = TRUE,
  filterable = TRUE,
  resizable = TRUE,
  searchable = TRUE,
  pagination = TRUE,
  showPagination = TRUE,
  showPageInfo = TRUE,
  striped = TRUE,
  compact = FALSE,
  wrap = FALSE,
  showSortIcon = TRUE,
  showSortable = TRUE,
  fullWidth = TRUE,
  showPageSizeOptions = TRUE,
  pageSizeOptions = c(10, 20, 50, 100, 1000, 1000000),
  defaultPageSize = 100
)

