## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)

## ----echo=FALSE---------------------------------------------------------------

inputsForConfig <- data.frame(
  Inputs = c('moduleId','tabName','shinyModulePackage',
      'moduleUiFunction', 'moduleServerFunction',
      'moduleInfoBoxFile',
      'moduleIcon'
),

Description = c("a unique id for the shiny app", "The menu text for the module", "The R package that contains the shiny module", "The name of the module's UI function", "The name of the module's server function", 
                "The function in the shinyModulePackage package that contains the helper information",
                "An icon to use in the menu for this module")
)

knitr::kable(inputsForConfig)


## ----eval=FALSE---------------------------------------------------------------
#  
#  aboutModule <- createModuleConfig(
#        moduleId = 'about',
#        tabName = "About",
#        shinyModulePackage = "OhdsiShinyModule",
#        moduleUiFunction = 'aboutViewer',
#        moduleServerFunction = 'aboutServer',
#        moduleInfoBoxFile =  "aboutHelperFile()",
#        moduleIcon = 'info'
#      )
#  

## ----eval=FALSE---------------------------------------------------------------
#  
#  aboutModule <- createDefaultAboutConfig()
#  

## ----eval=FALSE---------------------------------------------------------------
#  
#  predictionModule <- createModuleConfig(
#      moduleId = 'prediction',
#      tabName = "Prediction",
#      shinyModulePackage = 'OhdsiShinyModules',
#      moduleUiFunction = "predictionViewer",
#      moduleServerFunction = "predictionServer",
#      moduleInfoBoxFile =  "predictionHelperFile()",
#      moduleIcon = "chart-line"
#      )
#  

## ----eval=FALSE---------------------------------------------------------------
#  
#  predictionModule <- createDefaultPredictionConfig()
#  

## ----eval=FALSE---------------------------------------------------------------
#  
#  cohortMethodModule <- createDefaultEstimationConfig()
#  
#  cohortGeneratorModule <- createDefaultCohortGeneratorConfig()
#  

## ----eval=FALSE---------------------------------------------------------------
#  
#  library(dplyr)
#  shinyAppConfig <- initializeModuleConfig() %>%
#    addModuleConfig(aboutModule) %>%
#    addModuleConfig(cohortGeneratorModule) %>%
#    addModuleConfig(cohortMethodModule) %>%
#    addModuleConfig(predictionModule)
#  

## ----eval=FALSE---------------------------------------------------------------
#  # create a connection to the result database
#  connectionDetails <- DatabaseConnector::createConnectionDetails()
#  createShinyApp(shinyAppConfig, connectionDetails = connectionDetails)

## ----eval=FALSE---------------------------------------------------------------
#  # create a connection to the result database
#  connectionDetails <- DatabaseConnector::createConnectionDetails()
#  viewShiny(shinyAppConfig, connectionDetails = connectionDetails)

## ----eval=FALSE---------------------------------------------------------------
#  library(ShinyAppBuilder)
#  library(dplyr)
#  
#  aboutModule <- createModuleConfig(
#        moduleId = 'about',
#        tabName = "About",
#        shinyModulePackage = "OhdsiShinyModule",
#        moduleUiFunction = 'aboutViewer',
#        moduleServerFunction = 'aboutServer',
#        moduleInfoBoxFile =  "aboutHelperFile()",
#        moduleIcon = 'info'
#      )
#  
#  predictionModule <- createModuleConfig(
#      moduleId = 'prediction',
#      tabName = "Prediction",
#      shinyModulePackage = 'OhdsiShinyModules',
#      moduleUiFunction = "predictionViewer",
#      moduleServerFunction = "predictionServer",
#      moduleInfoBoxFile =  "predictionHelperFile()",
#      moduleIcon = "chart-line"
#      )
#  
#  cohortMethodModule <- createDefaultEstimationConfig()
#  
#  cohortGeneratorModule <- createDefaultCohortGeneratorConfig()
#  
#  
#  # add the modules into a single shiny config
#  shinyAppConfig <- initializeModuleConfig() %>%
#    addModuleConfig(aboutModule) %>%
#    addModuleConfig(cohortGeneratorModule) %>%
#    addModuleConfig(cohortMethodModule) %>%
#    addModuleConfig(predictionModule)
#  
#  
#  # add connection details to result database
#  connectionDetails <- DatabaseConnector::createConnectionDetails()
#  viewShiny(shinyAppConfig, connectionDetails = connectionDetails)
#  

