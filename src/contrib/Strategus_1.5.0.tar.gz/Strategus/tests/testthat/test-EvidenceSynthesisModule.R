library(testthat)
library(Strategus)

esTestDataConnectionDetails <- DatabaseConnector::createConnectionDetails(
  dbms = "sqlite",
  server = system.file("testdata/esmodule/results.sqlite", package = "Strategus")
)

workFolder <- tempfile("work")
dir.create(workFolder)
testResultsFolder <- tempfile("results")
dir.create(testResultsFolder)
# jobContext <- readRDS("tests/testJobContext.rds")
# jobContext$moduleExecutionSettings$workSubFolder <- workFolder
# jobContext$moduleExecutionSettings$resultsSubFolder <- testResultsFolder
# jobContext$moduleExecutionSettings$resultsConnectionDetails <- esTestDataConnectionDetails

createEsModuleSpecs <- function() {
  esModuleSettingsCreator <- EvidenceSynthesisModule$new()
  # Create EvidenceSynthesisModule settings ---------------------------------------

  evidenceSynthesisSourceCmNormal <- esModuleSettingsCreator$createEvidenceSynthesisSource(
    sourceMethod = "CohortMethod",
    databaseIds = c(1, 2, 4),
    analysisIds = c(1, 3),
    likelihoodApproximation = "normal"
  )

  # Note: even though the simulated data was approximated using "grid with gradients", we can also
  # use it for "adaptive grid". The grid is just not really adaptive, and the gradients will be
  # ignored. This is not recommended for real-world use, but fine for testing.
  evidenceSynthesisSourceCmAdaptiveGrid <- esModuleSettingsCreator$createEvidenceSynthesisSource(
    sourceMethod = "CohortMethod",
    likelihoodApproximation = "adaptive grid"
  )

  evidenceSynthesisSourceCmGridWithGradients <- esModuleSettingsCreator$createEvidenceSynthesisSource(
    sourceMethod = "CohortMethod",
    likelihoodApproximation = "grid with gradients"
  )

  evidenceSynthesisSourceSccsNormal <- esModuleSettingsCreator$createEvidenceSynthesisSource(
    sourceMethod = "SelfControlledCaseSeries",
    databaseIds = c(1, 2, 4),
    analysisIds = c(1, 3),
    likelihoodApproximation = "normal"
  )

  evidenceSynthesisSourceSccsAdaptiveGrid <- esModuleSettingsCreator$createEvidenceSynthesisSource(
    sourceMethod = "SelfControlledCaseSeries",
    likelihoodApproximation = "adaptive grid"
  )

  evidenceSynthesisSourceSccsGridWithGradients <- esModuleSettingsCreator$createEvidenceSynthesisSource(
    sourceMethod = "SelfControlledCaseSeries",
    likelihoodApproximation = "grid with gradients"
  )

  fixedEffectsMetaAnalysisCm <- esModuleSettingsCreator$createFixedEffectsMetaAnalysis(
    evidenceSynthesisAnalysisId = 1,
    evidenceSynthesisSource = evidenceSynthesisSourceCmNormal
  )

  randomEffectsMetaAnalysisCm <- esModuleSettingsCreator$createRandomEffectsMetaAnalysis(
    evidenceSynthesisAnalysisId = 2,
    evidenceSynthesisSource = evidenceSynthesisSourceCmNormal
  )

  bayesianMetaAnalysisCmAdaptiveGrid <- esModuleSettingsCreator$createBayesianMetaAnalysis(
    evidenceSynthesisAnalysisId = 3,
    evidenceSynthesisSource = evidenceSynthesisSourceCmAdaptiveGrid
  )

  bayesianMetaAnalysisCmGridWithGradients <- esModuleSettingsCreator$createBayesianMetaAnalysis(
    evidenceSynthesisAnalysisId = 4,
    evidenceSynthesisSource = evidenceSynthesisSourceCmGridWithGradients
  )

  fixedEffectsMetaAnalysisSccs <- esModuleSettingsCreator$createFixedEffectsMetaAnalysis(
    evidenceSynthesisAnalysisId = 5,
    evidenceSynthesisSource = evidenceSynthesisSourceSccsNormal
  )

  randomEffectsMetaAnalysisSccs <- esModuleSettingsCreator$createRandomEffectsMetaAnalysis(
    evidenceSynthesisAnalysisId = 6,
    evidenceSynthesisSource = evidenceSynthesisSourceSccsNormal
  )

  bayesianMetaAnalysisSccsAdaptiveGrid <- esModuleSettingsCreator$createBayesianMetaAnalysis(
    evidenceSynthesisAnalysisId = 7,
    evidenceSynthesisSource = evidenceSynthesisSourceSccsAdaptiveGrid
  )

  bayesianMetaAnalysisSccsGridWithGradients <- esModuleSettingsCreator$createBayesianMetaAnalysis(
    evidenceSynthesisAnalysisId = 8,
    evidenceSynthesisSource = evidenceSynthesisSourceSccsGridWithGradients
  )

  evidenceSynthesisModuleSpecs <- esModuleSettingsCreator$createModuleSpecifications(
    evidenceSynthesisAnalysisList = list(
      fixedEffectsMetaAnalysisCm,
      randomEffectsMetaAnalysisCm,
      bayesianMetaAnalysisCmAdaptiveGrid,
      bayesianMetaAnalysisCmGridWithGradients,
      fixedEffectsMetaAnalysisSccs,
      randomEffectsMetaAnalysisSccs,
      bayesianMetaAnalysisSccsAdaptiveGrid,
      bayesianMetaAnalysisSccsGridWithGradients
    )
  )

  analysisSpecifications <- createEmptyAnalysisSpecifications() %>%
    addModuleSpecifications(evidenceSynthesisModuleSpecs)

  return(analysisSpecifications)
}

test_that("Run module", {
  esAnalysisSpecifications <- createEsModuleSpecs()
  resultsExecutionSettings <- Strategus::createResultsExecutionSettings(
    resultsDatabaseSchema = "main",
    resultsFolder = testResultsFolder,
    workFolder = workFolder
  )
  Strategus::execute(
    analysisSpecifications = esAnalysisSpecifications,
    executionSettings = resultsExecutionSettings,
    connectionDetails = esTestDataConnectionDetails
  )
  resultsFiles <- list.files(file.path(testResultsFolder, "EvidenceSynthesisModule"))
  expect_true("es_analysis.csv" %in% resultsFiles)
  expect_true("es_cm_result.csv" %in% resultsFiles)
  expect_true("es_cm_diagnostics_summary.csv" %in% resultsFiles)
  expect_true("es_cm_covariate_balance.csv" %in% resultsFiles)
  expect_true("es_cm_shared_covariate_balance.csv" %in% resultsFiles)
  expect_true("es_cm_covariate.csv" %in% resultsFiles)
  expect_true("es_sccs_result.csv" %in% resultsFiles)
  expect_true("es_sccs_diagnostics_summary.csv" %in% resultsFiles)
})

test_that("Skipped analyses as specified", {
  # We specified we didn't want cohort method analysis ID 2 in evidence synthesis ID 2:
  results <- CohortGenerator::readCsv(file.path(testResultsFolder, "EvidenceSynthesisModule", "es_cm_result.csv"))
  expect_false(any(results$evidenceSynthesisAnalysisId == 2 & results$analysisId == 2))

  results <- CohortGenerator::readCsv(file.path(testResultsFolder, "EvidenceSynthesisModule", "es_sccs_result.csv"))
  expect_false(any(results$evidenceSynthesisAnalysisId == 2 & results$analysisId == 2))
})

getApproximation <- function(setting) {
  tibble(
    evidenceSynthesisAnalysisId = setting$evidenceSynthesisAnalysisId,
    likelihoodApproximation = setting$evidenceSynthesisSource$likelihoodApproximation
  ) %>%
    return()
}

getDatabaseIds <- function(setting, databaseIds) {
  if (!is.null(setting$evidenceSynthesisSource$databaseIds)) {
    databaseIds <- setting$evidenceSynthesisSource$databaseIds
  }
  tibble(
    evidenceSynthesisAnalysisId = setting$evidenceSynthesisAnalysisId,
    databaseId = databaseIds
  ) %>%
    return()
}

test_that("Include only allowed CM estimates in meta-analysis", {
  # Should only include estimates in meta-analysis that are
  # 1. Unblinded (unblind_for_evidence_synthesis = 1)
  # 2. Has a valid estimate (normal approx) or LL profile (adaptive grid)
  # 3. Is not excluded in createEvidenceSynthesisSource()
  connection <- DatabaseConnector::connect(esTestDataConnectionDetails)
  on.exit(DatabaseConnector::disconnect(connection))

  esAnalysisSpecifications <- createEsModuleSpecs()
  esSettings <- esAnalysisSpecifications$moduleSpecifications[[1]]$settings

  # Determine if unblinded:
  sql <- "
    SELECT cm_target_comparator_outcome.target_comparator_id,
      cm_target_comparator_outcome.outcome_id,
      analysis_id,
      database_id,
      unblind_for_evidence_synthesis AS include_1
    FROM main.cm_target_comparator_outcome
    LEFT JOIN main.cm_diagnostics_summary
      ON cm_diagnostics_summary.target_comparator_id = cm_target_comparator_outcome.target_comparator_id
        AND cm_diagnostics_summary.outcome_id = cm_target_comparator_outcome.outcome_id;
  "
  criterion1 <- DatabaseConnector::querySql(connection, sql, snakeCaseToCamelCase = TRUE)
  # Must have some blinded results for this test to work:
  expect_gt(sum(criterion1$include1 == 0), 0)

  # Determine if valid estimate or LL profile:
  approximations <- bind_rows(lapply(esSettings$evidenceSynthesisAnalysisList, getApproximation))
  sql <- "
    SELECT cm_result.target_comparator_id,
      cm_result.outcome_id,
      cm_result.analysis_id,
      cm_result.database_id,
      CASE
        WHEN log_rr IS NOT NULL AND se_log_rr IS NOT NULL THEN 1
        ELSE 0
      END AS has_valid_estimate,
      CASE
        WHEN profiles.target_comparator_id IS NOT NULL THEN 1
        ELSE 0
      END AS has_ll_profile
    FROM main.cm_result
    LEFT JOIN (
      SELECT DISTINCT target_comparator_id,
        outcome_id,
        analysis_id,
        database_id
      FROM main.cm_likelihood_profile
      ) profiles
      ON cm_result.target_comparator_id = profiles.target_comparator_id
        AND cm_result.outcome_id = profiles.outcome_id
        AND cm_result.analysis_id = profiles.analysis_id
        AND cm_result.database_id = profiles.database_id
  "
  criterion2 <- DatabaseConnector::querySql(connection, sql, snakeCaseToCamelCase = TRUE) %>%
    cross_join(approximations) %>%
    mutate(include2 = if_else(likelihoodApproximation == "normal",
      hasValidEstimate,
      hasLlProfile
    ))

  # Determine if database was excluded in createEvidenceSynthesisSource():
  databaseIds <- unique(criterion2$databaseId)
  criterion3 <- bind_rows(lapply(esSettings$evidenceSynthesisAnalysisList, getDatabaseIds, databaseIds = databaseIds)) %>%
    mutate(include3 = 1)

  # Combine all criteria, and check if agree with results:
  allowed <- criterion1 %>%
    inner_join(criterion2,
      by = join_by(targetComparatorId, outcomeId, analysisId, databaseId),
      relationship = "one-to-many"
    ) %>%
    inner_join(criterion3, by = join_by(databaseId, evidenceSynthesisAnalysisId)) %>%
    mutate(include = include1 & include2 & include3) %>%
    group_by(targetComparatorId, outcomeId, analysisId, evidenceSynthesisAnalysisId) %>%
    summarize(nAllowed = sum(include), .groups = "drop")

  results <- CohortGenerator::readCsv(file.path(testResultsFolder, "EvidenceSynthesisModule", "es_cm_result.csv"))
  results <- results %>%
    left_join(allowed, by = join_by(targetComparatorId, outcomeId, analysisId, evidenceSynthesisAnalysisId))
  expect_true(all(results$nDatabases == results$nAllowed))
})

test_that("Include only allowed SCCS estimates in meta-analysis", {
  # Should only include estimates in meta-analysis that are
  # 1. Unblinded.
  # 2. Has a valid estimate (normal approx) or LL profile (adaptive grid)
  # 3. Is not excluded in createEvidenceSynthesisSource()
  connection <- DatabaseConnector::connect(esTestDataConnectionDetails)
  on.exit(DatabaseConnector::disconnect(connection))

  esAnalysisSpecifications <- createEsModuleSpecs()
  esSettings <- esAnalysisSpecifications$moduleSpecifications[[1]]$settings

  # Determine if unblinded or true effect size is known:
  sql <- "
    SELECT sccs_diagnostics_summary.exposures_outcome_set_id,
      sccs_diagnostics_summary.covariate_id,
      sccs_diagnostics_summary.analysis_id,
      sccs_diagnostics_summary.database_id,
      unblind_for_evidence_synthesis AS include_1
    FROM main.sccs_exposure
    INNER JOIN main.sccs_diagnostics_summary
      ON sccs_exposure.exposures_outcome_set_id = sccs_diagnostics_summary.exposures_outcome_set_id
    INNER JOIN main.sccs_covariate
      ON sccs_exposure.era_id = sccs_covariate.era_id
        AND sccs_covariate.covariate_id = sccs_diagnostics_summary.covariate_id
        AND sccs_covariate.exposures_outcome_set_id = sccs_diagnostics_summary.exposures_outcome_set_id
        AND sccs_covariate.analysis_id = sccs_diagnostics_summary.analysis_id
        AND sccs_covariate.database_id = sccs_diagnostics_summary.database_id;
  "
  criterion1 <- DatabaseConnector::querySql(connection, sql, snakeCaseToCamelCase = TRUE)
  # Must have some blinded results for this test to work:
  expect_gt(sum(criterion1$include1 == 0), 0)

  # Determine if valid estimate or LL profile:
  approximations <- bind_rows(lapply(esSettings$evidenceSynthesisAnalysisList, getApproximation))
  sql <- "
    SELECT sccs_result.exposures_outcome_set_id,
      sccs_result.covariate_id,
      sccs_result.analysis_id,
      sccs_result.database_id,
      CASE
        WHEN log_rr IS NOT NULL AND se_log_rr IS NOT NULL THEN 1
        ELSE 0
      END AS has_valid_estimate,
      CASE
        WHEN profiles.exposures_outcome_set_id IS NOT NULL THEN 1
        ELSE 0
      END AS has_ll_profile
    FROM main.sccs_result
    LEFT JOIN (
      SELECT DISTINCT exposures_outcome_set_id,
        covariate_id,
        analysis_id,
        database_id
      FROM main.sccs_likelihood_profile
      ) profiles
      ON sccs_result.exposures_outcome_set_id = profiles.exposures_outcome_set_id
        AND sccs_result.covariate_id = profiles.covariate_id
        AND sccs_result.analysis_id = profiles.analysis_id
        AND sccs_result.database_id = profiles.database_id
  "
  criterion2 <- DatabaseConnector::querySql(connection, sql, snakeCaseToCamelCase = TRUE) %>%
    cross_join(approximations) %>%
    mutate(include2 = if_else(likelihoodApproximation == "normal",
      hasValidEstimate,
      hasLlProfile
    ))

  # Determine if database was excluded in createEvidenceSynthesisSource():
  databaseIds <- unique(criterion2$databaseId)
  criterion3 <- bind_rows(lapply(esSettings$evidenceSynthesisAnalysisList, getDatabaseIds, databaseIds = databaseIds)) %>%
    mutate(include3 = 1)

  # Combine all criteria, and check if agree with results:
  allowed <- criterion1 %>%
    inner_join(criterion2,
      by = join_by(exposuresOutcomeSetId, covariateId, analysisId, databaseId),
      relationship = "one-to-many"
    ) %>%
    inner_join(criterion3, by = join_by(databaseId, evidenceSynthesisAnalysisId)) %>%
    mutate(include = include1 & include2 & include3) %>%
    group_by(exposuresOutcomeSetId, covariateId, analysisId, evidenceSynthesisAnalysisId) %>%
    summarize(nAllowed = sum(include), .groups = "drop")

  results <- CohortGenerator::readCsv(file.path(testResultsFolder, "EvidenceSynthesisModule", "es_sccs_result.csv"))
  results <- results %>%
    left_join(allowed, by = join_by(exposuresOutcomeSetId, covariateId, analysisId, evidenceSynthesisAnalysisId)) %>%
    filter(analysisId == 8)
  expect_true(all(results$nDatabases == results$nAllowed))
})

test_that("Output conforms to results model", {
  model <- CohortGenerator::readCsv(file.path(testResultsFolder, "EvidenceSynthesisModule", "resultsDataModelSpecification.csv"))
  tables <- unique(model$tableName)
  for (table in tables) {
    data <- readr::read_csv(file.path(testResultsFolder, "EvidenceSynthesisModule", sprintf("%s.csv", table)), show_col_types = FALSE)
    observed <- colnames(data)
    observed <- sort(observed)
    expected <- model$columnName[model$tableName == table]
    expected <- sort(expected)
    expect_equal(observed, expected)
  }
})

test_that("Check MDRR values", {
  # CohortMethod
  results <- CohortGenerator::readCsv(file.path(testResultsFolder, "EvidenceSynthesisModule", "es_cm_result.csv"))
  diagnostics <- CohortGenerator::readCsv(file.path(testResultsFolder, "EvidenceSynthesisModule", "es_cm_diagnostics_summary.csv"))
  combined <- results %>%
    inner_join(diagnostics, by = join_by(targetComparatorId, outcomeId, analysisId, evidenceSynthesisAnalysisId))
  noDbs <- combined %>%
    filter(nDatabases == 0)
  expect_true(all(is.infinite(noDbs$mdrr)))
  expect_true(all(noDbs$mdrrDiagnostic == "FAIL"))
  expect_true(all(noDbs$unblind == 0))

  oneDb <- combined %>%
    filter(nDatabases == 1)
  # All per-DB MDRRs were set to 2 in simulation code:
  expect_true(all(oneDb$mdrr == 2))
  expect_true(all(oneDb$mdrrDiagnostic == "PASS"))

  multiDbs <- combined %>%
    filter(nDatabases > 1, !is.na(seLogRr))

  expect_true(all(!is.na(multiDbs$mdrr)))

  # SCCS
  results <- CohortGenerator::readCsv(file.path(testResultsFolder, "EvidenceSynthesisModule", "es_sccs_result.csv"))
  diagnostics <- CohortGenerator::readCsv(file.path(testResultsFolder, "EvidenceSynthesisModule", "es_sccs_diagnostics_summary.csv"))
  combined <- results %>%
    inner_join(diagnostics, by = join_by(analysisId, exposuresOutcomeSetId, covariateId, evidenceSynthesisAnalysisId))
  noDbs <- combined %>%
    filter(nDatabases == 0)
  expect_true(all(is.infinite(noDbs$mdrr)))
  expect_true(all(noDbs$mdrrDiagnostic == "FAIL"))
  expect_true(all(noDbs$unblind == 0))

  oneDb <- combined %>%
    filter(nDatabases == 1)
  # All per-DB MDRRs were set to 2 in simulation code:
  expect_true(all(oneDb$mdrr == 2))
  expect_true(all(oneDb$mdrrDiagnostic == "PASS"))

  multiDbs <- combined %>%
    filter(nDatabases > 1, !is.na(seLogRr))

  expect_true(all(!is.na(multiDbs$mdrr)))
})

test_that("Check prediction intervals", {
  tables <- c("es_cm_result.csv", "es_sccs_result.csv")
  for (table in tables) {
    data <- readr::read_csv(file.path(testResultsFolder, "EvidenceSynthesisModule", table), show_col_types = FALSE) |>
      SqlRender::snakeCaseToCamelCaseNames()
    data <- data |>
      filter(!is.na(pi95Lb) & !is.na(pi95Ub)) |>
      mutate(
        seLogPi = (log(pi95Ub) - log(pi95Lb)) / 2 * qnorm(0.975),
        seLogCalPi = (log(calibratedPi95Ub) - log(calibratedPi95Lb)) / 2 * qnorm(0.975)
      )

    expect_true(nrow(data) > 0)

    # Prediction interval should be wider than meta-analysis:
    expect_true(all(data$ci95Lb >= data$pi95Lb))
    expect_true(all(data$ci95Ub <= data$pi95Ub))

    # Calibrated PI should be wider than uncalibrated PI (but may be shifted, so using SE):
    expect_true(all(data$seLogCalPi >= data$seLogPi, na.rm = TRUE))
    # (Test only works if most are not NA:)
    expect_true(mean(is.na(data$seLogCalPi)) < 0.1 & mean(is.na(data$seLogPi)) < 0.1)
  }
})

test_that("Check covariate balance", {
  diagnosticsSummary <- CohortGenerator::readCsv(file.path(testResultsFolder, "EvidenceSynthesisModule", "es_cm_diagnostics_summary.csv"))

  # No threshold was set in main test run, so all balance diagnostics should be "NOT EVALUATED":
  expect_true(all(diagnosticsSummary$balanceDiagnostic == "NOT EVALUATED"))
  expect_true(all(diagnosticsSummary$sharedBalanceDiagnostic == "NOT EVALUATED"))

  balance <- CohortGenerator::readCsv(file.path(testResultsFolder, "EvidenceSynthesisModule", "es_cm_covariate_balance.csv"))
  expect_true(!all(is.na(balance$stdDiffAfter)))

  sharedBalance <- CohortGenerator::readCsv(file.path(testResultsFolder, "EvidenceSynthesisModule", "es_cm_shared_covariate_balance.csv"))
  expect_true(!all(is.na(sharedBalance$stdDiffAfter)))

  # Rerun with threshold and alpha set:
  testResultsFolder2 <- tempfile("results")
  dir.create(testResultsFolder2)
  on.exit(unlink(testResultsFolder2))
  esModuleSettingsCreator <- EvidenceSynthesisModule$new()
  evidenceSynthesisSourceCmNormal <- esModuleSettingsCreator$createEvidenceSynthesisSource(
    sourceMethod = "CohortMethod",
    likelihoodApproximation = "normal"
  )
  randomEffectsMetaAnalysisCm <- esModuleSettingsCreator$createRandomEffectsMetaAnalysis(
    evidenceSynthesisAnalysisId = 1,
    evidenceSynthesisSource = evidenceSynthesisSourceCmNormal
  )
  evidenceSynthesisModuleSpecs <- esModuleSettingsCreator$createModuleSpecifications(
    evidenceSynthesisAnalysisList = list(randomEffectsMetaAnalysisCm),
    esDiagnosticThresholds = esModuleSettingsCreator$createEsDiagnosticThresholds(
      sdmThreshold = 0.1,
      sdmAlpha = 0.05
    )
  )
  esAnalysisSpecifications <- createEmptyAnalysisSpecifications() %>%
    addModuleSpecifications(evidenceSynthesisModuleSpecs)
  resultsExecutionSettings <- Strategus::createResultsExecutionSettings(
    resultsDatabaseSchema = "main",
    resultsFolder = testResultsFolder2,
    workFolder = workFolder
  )
  Strategus::execute(
    analysisSpecifications = esAnalysisSpecifications,
    executionSettings = resultsExecutionSettings,
    connectionDetails = esTestDataConnectionDetails
  )

  diagnosticsSummary <- CohortGenerator::readCsv(file.path(testResultsFolder2, "EvidenceSynthesisModule", "es_cm_diagnostics_summary.csv"))
  expect_true(!all(diagnosticsSummary$balanceDiagnostic == "NOT EVALUATED"))
  expect_true(!all(diagnosticsSummary$sharedBalanceDiagnostic == "NOT EVALUATED"))
})

test_that("Don't error when no negative controls present", {
  # Create dataset without negative controls
  tempFile <- tempfile(fileext = ".sqlite")
  file.copy(system.file("testdata/esmodule/results.sqlite", package = "Strategus"), tempFile)
  on.exit(unlink(tempFile))
  tempConnectionDetails <- DatabaseConnector::createConnectionDetails(
    dbms = "sqlite",
    server = tempFile
  )
  connection <- DatabaseConnector::connect(tempConnectionDetails)
  DatabaseConnector::renderTranslateExecuteSql(connection, "UPDATE cm_target_comparator_outcome SET true_effect_size = NULL;")
  DatabaseConnector::disconnect(connection)

  # tempJobContext <- jobContext
  # tempJobContext$settings$evidenceSynthesisAnalysisList <- list(tempJobContext$settings$evidenceSynthesisAnalysisList[[1]])
  # tempJobContext$moduleExecutionSettings$resultsConnectionDetails <- tempConnectionDetails
  # execute(tempJobContext)

  esAnalysisSpecifications <- createEsModuleSpecs()
  esAnalysisSpecifications$moduleSpecifications[[1]]$settings$evidenceSynthesisAnalysisList <- list(esAnalysisSpecifications$moduleSpecifications[[1]]$settings$evidenceSynthesisAnalysisList[[1]])
  resultsExecutionSettings <- Strategus::createResultsExecutionSettings(
    resultsDatabaseSchema = "main",
    resultsFolder = testResultsFolder,
    workFolder = workFolder
  )
  Strategus::execute(
    analysisSpecifications = esAnalysisSpecifications,
    executionSettings = resultsExecutionSettings,
    connectionDetails = tempConnectionDetails
  )

  estimates <- readr::read_csv(file.path(testResultsFolder, "EvidenceSynthesisModule", "es_cm_result.csv"), show_col_types = FALSE)
  expect_gt(nrow(estimates), 0)
  expect_true(all(is.na(estimates$calibrated_rr)))
})


# readr::write_csv(OhdsiRTools::createResultsSchemaStub(testResultsFolder), "resultsDataModelSpecification.csv")

unlink(workFolder)
unlink(testResultsFolder)
