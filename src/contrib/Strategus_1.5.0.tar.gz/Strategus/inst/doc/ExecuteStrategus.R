## ----setup, include=FALSE-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)

## ----eval=FALSE---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# library(Strategus)
# library(Eunomia)
# connectionDetails <- getEunomiaConnectionDetails()

## ----eval=FALSE---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# outputFolder <- tempfile("vignetteFolder")
# dir.create(outputFolder)
# executionSettings <- createCdmExecutionSettings(
#   workDatabaseSchema = "main",
#   cdmDatabaseSchema = "main",
#   cohortTableNames = CohortGenerator::getCohortTableNames("strategus_test"),
#   workFolder = file.path(outputFolder, "work_folder"),
#   resultsFolder = file.path(outputFolder, "results_folder"),
#   minCellCount = 5
# )

## ----eval=FALSE---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# ParallelLogger::saveSettingsToJson(
#   object = executionSettings,
#   file.path(outputFolder, "eunomiaExecutionSettings.json")
# )

## ----eval=FALSE---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# analysisSpecifications <- ParallelLogger::loadSettingsFromJson(
#   fileName = system.file("testdata/cdmModulesAnalysisSpecifications.json",
#     package = "Strategus"
#   )
# )
# 
# executionSettings <- ParallelLogger::loadSettingsFromJson(
#   fileName = file.path(outputFolder, "eunomiaExecutionSettings.json")
# )

## ----eval=FALSE---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# execute(
#   connectionDetails = connectionDetails,
#   analysisSpecifications = analysisSpecifications,
#   executionSettings = executionSettings
# )

## ----eval=F, echo=FALSE-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# unlink(outputFolder, recursive = TRUE)

