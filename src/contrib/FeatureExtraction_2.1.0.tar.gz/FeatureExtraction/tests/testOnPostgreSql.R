# library(testthat)
# library(FeatureExtraction)
# options(dbms = "postgresql")
# test_check("FeatureExtraction")
