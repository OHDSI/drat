ShinyAppBuilder v3.0.0
======================
- CM/SCCS/ES are now combined into Estimation 

ShinyAppBuilder v2.0.1
======================
- added css formatting file 
- set white-space: normal to dropdown lists


ShinyAppBuilder v1.2.0
======================
- revised config to simplify
- shiny modules now share resultDatabaseSettings
- added function for default resultDatabaseSettings
- requires OhdsiShinyModules 1.2.0

ShinyAppBuilder v1.1.3
======================
- Made simplification to API to allow calling `createShinyApp` with connectionDetails rather than a `ConnectionHandler`

ShinyAppBuilder v1.1.2
======================
- added package versions to footer
- fixed logo

ShinyAppBuilder v1.1.1
======================

Changes

- Ensuring documentation adheres to HADES standards.


ShinyAppBuilder v1.1.0
======================

Changes

- Updated for latest release of OhdsiShinyModules
- Now requires a shared connection between the models