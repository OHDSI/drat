ShinyAppBuilder v1.1.2
======================
- added package versions to footer
- fixed logo

ShinyAppBuilder v1.1.1
======================

Changes

- Ensuring documentation adheres to HADES standards.


ShinyAppBuilder v1.1.0
======================

Changes

- Updated for latest release of OhdsiShinyModules
- Now requires a shared connection between the models