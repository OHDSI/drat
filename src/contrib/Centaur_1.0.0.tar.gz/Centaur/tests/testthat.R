library(testthat)
library(Centaur)

test_check("Centaur")
