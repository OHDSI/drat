#' Centaur
#'
#' @docType package
#' @name Centaur
#' @import sm
#' @importFrom grDevices topo.colors
#' @importFrom graphics abline axis barplot boxplot legend mtext par plot points text title
#' @importFrom stats aggregate as.formula binomial coef complete.cases confint glm lm na.exclude predict qqplot quantile residuals var weighted.mean
NULL
